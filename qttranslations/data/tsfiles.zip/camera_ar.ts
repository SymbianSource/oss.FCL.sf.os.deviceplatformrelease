<?xml version="1.0" encoding="utf-8"?>
<TS xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" version="1.0" sourcelanguage="English-GB" language="ar">
  <extra-loc-extended xsi:type="xsd:boolean">true</extra-loc-extended>
  <defaultcodec />
  <extra-loc-feature xsi:type="xsd:string">camera@dfsxx.01</extra-loc-feature>
  <extra-loc-style xsi:type="xsd:string">ts</extra-loc-style>
  <context>
    <name>Prophet</name>
    <message numerus="no" id="txt_cam_button_cancel" marked="false">
      <extracomment />
      <location />
      <comment>Self-timer Cancel button</comment>
      <extra-loc-engineeringenglish>Cancel</extra-loc-engineeringenglish>
      <source>Cancel81</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="إلغاء">إلغاء</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_softkey_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_softkey_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>54</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>cam_17</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_button_color_tone" marked="false">
      <extracomment />
      <location />
      <comment>Item name in toolbar extension. The name is visible under an icon</comment>
      <extra-loc-engineeringenglish>Color tone</extra-loc-engineeringenglish>
      <source>Color tone82</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ar #Color tone</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_grid_applications_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_grid_applications_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>grid</extra-loc-positionid>
      <extra-loc-viewid>cam_06</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_button_contrast" marked="false">
      <extracomment />
      <location />
      <comment>Item name in toolbar extension. The name is visible under an icon</comment>
      <extra-loc-engineeringenglish>Contrast</extra-loc-engineeringenglish>
      <source>Contrast83</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ar #Contrast</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_grid_applications_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_grid_applications_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>grid</extra-loc-positionid>
      <extra-loc-viewid>cam_06</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_button_exposure_compensation" marked="false">
      <extracomment />
      <location />
      <comment>Item name in toolbar extension. The name is visible under an icon</comment>
      <extra-loc-engineeringenglish>Exposure compensation</extra-loc-engineeringenglish>
      <source>Exposure compensation84</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ar #Exposure compensation</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_grid_applications_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_grid_applications_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>grid</extra-loc-positionid>
      <extra-loc-viewid>cam_06</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_button_face_tracking" marked="false">
      <extracomment />
      <location />
      <comment>Item name in toolbar extension. The name is visible under an icon</comment>
      <extra-loc-engineeringenglish>Face tracking</extra-loc-engineeringenglish>
      <source>Face tracking85</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ar #Face tracking</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_grid_applications_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_grid_applications_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>grid</extra-loc-positionid>
      <extra-loc-viewid>cam_06</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_button_geotagging" marked="false">
      <extracomment />
      <location />
      <comment>Item name in toolbar extension. The name is visible under an icon</comment>
      <extra-loc-engineeringenglish>Geotagging</extra-loc-engineeringenglish>
      <source>Geotagging86</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ar #Geotagging</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_grid_applications_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_grid_applications_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>grid</extra-loc-positionid>
      <extra-loc-viewid>cam_06</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_button_iso" marked="false">
      <extracomment />
      <location />
      <comment>Item name in toolbar extension. The name is visible under an icon</comment>
      <extra-loc-engineeringenglish>ISO</extra-loc-engineeringenglish>
      <source>ISO87</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ar #ISO</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_grid_applications_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_grid_applications_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>grid</extra-loc-positionid>
      <extra-loc-viewid>cam_06</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_button_start" marked="false">
      <extracomment />
      <location />
      <comment>Self-timer start button</comment>
      <extra-loc-engineeringenglish>Start</extra-loc-engineeringenglish>
      <source>Start88</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="بدء">بدء</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_softkey_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_softkey_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>320</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>cam_17</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_button_white_balance" marked="false">
      <extracomment />
      <location />
      <comment>Item name in toolbar extension. The name is visible under an icon</comment>
      <extra-loc-engineeringenglish>White balance</extra-loc-engineeringenglish>
      <source>White balance89</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ar #White balance</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_grid_applications_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_grid_applications_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>grid</extra-loc-positionid>
      <extra-loc-viewid>cam_06</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_caption_camera" marked="false">
      <extracomment />
      <location />
      <comment>Camera caption string. Application name.</comment>
      <extra-loc-engineeringenglish>Camera</extra-loc-engineeringenglish>
      <source>Camera90</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ar #Camera</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>cell_tport_appsw_pane_t1</extra-loc-layout_id>
      <extra-loc-layout>cell_tport_appsw_pane_t1</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>caption</extra-loc-positionid>
      <extra-loc-viewid>cam</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="yes" id="txt_cam_dblist_hd_720p_val_ln_images_left" marked="false">
      <extracomment />
      <location />
      <comment>Image quality value in modal dialog, second row</comment>
      <extra-loc-engineeringenglish>%Ln images left</extra-loc-engineeringenglish>
      <source>%Ln images left91</source>
      <translation testresult="false" keep="false">
        <numerusform plurality="a" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="This Warning is ignored." originaltestercomment="" variants="no" originaltranslation="%Ln صورة متبقية">%Ln صورة متبقية</numerusform>
        <numerusform plurality="b" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="This Warning is ignored." originaltestercomment="" variants="no" originaltranslation="%Ln صورة متبقية">%Ln صورة متبقية</numerusform>
        <numerusform plurality="c" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="This Warning is ignored." originaltestercomment="" variants="no" originaltranslation="%Ln صورة متبقية">%Ln صورة متبقية</numerusform>
        <numerusform plurality="d" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="This Warning is ignored." originaltestercomment="" variants="no" originaltranslation="%Ln صور متبقية">%Ln صور متبقية</numerusform>
        <numerusform plurality="e" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="This Warning is ignored." originaltestercomment="" variants="no" originaltranslation="%Ln صورة متبقية">%Ln صورة متبقية</numerusform>
        <numerusform plurality="f" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="This Warning is ignored." originaltestercomment="" variants="no" originaltranslation="%Ln صورة متبقية">%Ln صورة متبقية</numerusform>
      </translation>
      <oldsource>%Ln image left</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>133</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dblist_1_val</extra-loc-positionid>
      <extra-loc-viewid>cam_11, cam_12</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="yes" id="txt_cam_dblist_ln_mpix" marked="false">
      <extracomment />
      <location />
      <comment>Amount of Mpix when image/video quality is Maximum</comment>
      <extra-loc-engineeringenglish>%Ln Mpix</extra-loc-engineeringenglish>
      <source>%Ln Mpix92</source>
      <translation testresult="false" keep="false">
        <numerusform plurality="a" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="This Warning is ignored." originaltestercomment="" variants="no" originaltranslation="%Ln ميجابكسل">%Ln ميجابكسل</numerusform>
        <numerusform plurality="b" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="This Warning is ignored." originaltestercomment="" variants="no" originaltranslation="%Ln ميجابكسل">%Ln ميجابكسل</numerusform>
        <numerusform plurality="c" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="This Warning is ignored." originaltestercomment="" variants="no" originaltranslation="%Ln ميجابكسل">%Ln ميجابكسل</numerusform>
        <numerusform plurality="d" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="This Warning is ignored. The numerus form for plural here is the same as the others for singular." originaltestercomment="" variants="no" originaltranslation="%Ln ميجابكسل">%Ln ميجابكسل</numerusform>
        <numerusform plurality="e" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="This Warning is ignored." originaltestercomment="" variants="no" originaltranslation="%Ln ميجابكسل">%Ln ميجابكسل</numerusform>
        <numerusform plurality="f" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="This Warning is ignored." originaltestercomment="" variants="no" originaltranslation="%Ln ميجابكسل">%Ln ميجابكسل</numerusform>
      </translation>
      <oldsource>%Ln Mpix</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dblist_1</extra-loc-positionid>
      <extra-loc-viewid>cam_11</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="yes" id="txt_cam_dblist_ln_mpix_widescreen" marked="false">
      <extracomment />
      <location />
      <comment>Amount of Mpix when image/video quality is maximum. Indicates that image is displayed in widescreen mode.</comment>
      <extra-loc-engineeringenglish>%Ln Mpix widescreen</extra-loc-engineeringenglish>
      <source>%Ln Mpix widescreen93</source>
      <translation testresult="false" keep="false">
        <numerusform plurality="a" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="شاشة %Ln ميجابكسل">شاشة %Ln ميجابكسل</numerusform>
        <numerusform plurality="b" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="شاشة %Ln ميجابكسل">شاشة %Ln ميجابكسل</numerusform>
        <numerusform plurality="c" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="شاشة %Ln ميجابكسل">شاشة %Ln ميجابكسل</numerusform>
        <numerusform plurality="d" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="شاشة %Ln ميجابكسل">شاشة %Ln ميجابكسل</numerusform>
        <numerusform plurality="e" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="شاشة %Ln ميجابكسل">شاشة %Ln ميجابكسل</numerusform>
        <numerusform plurality="f" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="شاشة %Ln ميجابكسل">شاشة %Ln ميجابكسل</numerusform>
      </translation>
      <oldsource>%Ln Mpix widescreen</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dblist_2</extra-loc-positionid>
      <extra-loc-viewid>cam_11</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_info_camera_already_in_use" marked="false">
      <extracomment />
      <location />
      <comment>Error note when camera is already in use by another application</comment>
      <extra-loc-engineeringenglish>Camera already in use</extra-loc-engineeringenglish>
      <source>Camera already in use94</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ar #Camera already in use</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri5</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri5</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>cam_33</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_info_camera_in_standby_mode" marked="false">
      <extracomment />
      <location />
      <comment>Info note. Camera is in stand by mode. Touching of screen starts view finder again.</comment>
      <extra-loc-engineeringenglish>Camera in stand-by mode</extra-loc-engineeringenglish>
      <source>Camera in stand-by mode95</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ar #Camera in stand-by mode</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri5</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri5</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>cam_04</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_info_captured_photos_and_videos_will_be_ta" marked="false">
      <extracomment />
      <location />
      <comment>Info note for the first time use of the camera application. The note gives a warning about the geotagging feature which is on by default.</comment>
      <extra-loc-engineeringenglish>Captured photos and videos will be tagged with your location. If photos or videos are shared, the location data may also be visible to third parties. Phone will use network to get the location data. Data transfer charges may apply. Location recording can be disabled in settings.</extra-loc-engineeringenglish>
      <source>Captured photos and videos will be tagged with your location. If photos or videos are shared, location data may also be visible to third parties. The phone will use network to get location data. Data transfer charges may apply. Location recording can be disabled in settings.96</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="سيتم وضع علامة الموقع على الصور ومقاطع الفيديو الملتقطة. وفي حالة مشاركة الصور ومقاطع الفيديو، فقد تظهر بيانات الموقع أيضًا للأطراف الثالثة. سيستخدم الهاتف الشبكة للحصول على بيانات الموقع. قد يتم تطبيق تكاليف نقل البيانات. يمكن تعطيل تسجيل الموقع في الضبط.">سيتم وضع علامة الموقع على الصور ومقاطع الفيديو الملتقطة. وفي حالة مشاركة الصور ومقاطع الفيديو، فقد تظهر بيانات الموقع أيضًا للأطراف الثالثة. سيستخدم الهاتف الشبكة للحصول على بيانات الموقع. قد يتم تطبيق تكاليف نقل البيانات. يمكن تعطيل تسجيل الموقع في الضبط.</translation>
      <oldsource>Captured photos and videos will be tagged with your location. If the photos or videos are shared, the location data may also be visible to third parties. The phone will use the network to get the location data. Data transfer charges may apply. Location recording can be disbaled in settings.</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>none</extra-loc-layout_id>
      <extra-loc-layout>none</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_76,543,NOT_544,228,NOT_492,290,NOT_291,360</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>cam_49</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_info_error" marked="false">
      <extracomment />
      <location />
      <comment>Info note. Error message.</comment>
      <extra-loc-engineeringenglish>Unexpected error occurred. Power off the device and restart</extra-loc-engineeringenglish>
      <source>Unexpected error occurred. Power off the device and restart97</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ar #Unexpected error occurred. Power off the device and restart</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri5</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri5</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>cam_32</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_info_no_memory_card_in_device_please_inse" marked="false">
      <extracomment />
      <location />
      <comment>Info note telling the user to insert memory card to be able to take photos.</comment>
      <extra-loc-engineeringenglish>No memory card in device. Please insert memory card in order to capture images.</extra-loc-engineeringenglish>
      <source>No memory card in device. Please insert memory card in order to capture images.98</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ar #No memory card in device. Please insert memory card in order to capture images.</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri5</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri5</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>cam_36</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_continuous_video" marked="false">
      <extracomment />
      <location />
      <comment>Value for 'Show captured video' modal dialog</comment>
      <extra-loc-engineeringenglish>Continuous</extra-loc-engineeringenglish>
      <source>Continuous99</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="مستمر">مستمر</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_landscape" marked="false">
      <extracomment />
      <location />
      <comment>List item. Scene mode for landscape photographing.</comment>
      <extra-loc-engineeringenglish>Landscape</extra-loc-engineeringenglish>
      <source>Landscape100</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ar #Landscape</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>HbRadioButtonList</extra-loc-layout_id>
      <extra-loc-layout>HbRadioButtonList</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_08</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_sec" marked="false">
      <extracomment />
      <location />
      <comment>List item for show captured image modal dialog: shows the image for 2 seconds after capturing</comment>
      <extra-loc-engineeringenglish>%Ln sec</extra-loc-engineeringenglish>
      <source>%Ln seconds101</source>
      <translation testresult="false" keep="false">
        <numerusform plurality="a" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="%Ln ثانية">%Ln ثانية</numerusform>
        <numerusform plurality="b" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="%Ln ثانية">%Ln ثانية</numerusform>
        <numerusform plurality="c" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="%Ln ثانية">%Ln ثانية</numerusform>
        <numerusform plurality="d" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="%Ln ثواني">%Ln ثواني</numerusform>
        <numerusform plurality="e" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="%Ln ثانية">%Ln ثانية</numerusform>
        <numerusform plurality="f" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="%Ln ثانية">%Ln ثانية</numerusform>
      </translation>
      <oldsource>%Ln second</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07, cam_28</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_sec_video" marked="false">
      <extracomment />
      <location />
      <comment>Value for 'Show captured video' modal dialog</comment>
      <extra-loc-engineeringenglish>%Ln sec</extra-loc-engineeringenglish>
      <source>%Ln seconds102</source>
      <translation testresult="false" keep="false">
        <numerusform plurality="a" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="%Ln ثانية">%Ln ثانية</numerusform>
        <numerusform plurality="b" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="%Ln ثانية">%Ln ثانية</numerusform>
        <numerusform plurality="c" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="%Ln ثانية">%Ln ثانية</numerusform>
        <numerusform plurality="d" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="%Ln ثواني">%Ln ثواني</numerusform>
        <numerusform plurality="e" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="%Ln ثانية">%Ln ثانية</numerusform>
        <numerusform plurality="f" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="%Ln ثانية">%Ln ثانية</numerusform>
      </translation>
      <oldsource>%Ln second</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_seconds" marked="false">
      <extracomment />
      <location />
      <comment>List item. Self timer period 2 seconds.</comment>
      <extra-loc-engineeringenglish>%Ln seconds</extra-loc-engineeringenglish>
      <source>%Ln seconds103</source>
      <translation testresult="false" keep="false">
        <numerusform plurality="a" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="%Ln ثانية">%Ln ثانية</numerusform>
        <numerusform plurality="b" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="%Ln ثانية">%Ln ثانية</numerusform>
        <numerusform plurality="c" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="%Ln ثانية">%Ln ثانية</numerusform>
        <numerusform plurality="d" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="%Ln ثواني">%Ln ثواني</numerusform>
        <numerusform plurality="e" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="%Ln ثانية">%Ln ثانية</numerusform>
        <numerusform plurality="f" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="%Ln ثانية">%Ln ثانية</numerusform>
      </translation>
      <oldsource>%Ln second</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_16</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_night_portrait" marked="false">
      <extracomment />
      <location />
      <comment>List item. Scene mode for portrait photographing in low light.</comment>
      <extra-loc-engineeringenglish>Night portrait</extra-loc-engineeringenglish>
      <source>Night portrait104</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ar #Night portrait</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>HbRadioButtonList</extra-loc-layout_id>
      <extra-loc-layout>HbRadioButtonList</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_08</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_not" marked="false">
      <extracomment />
      <location />
      <comment>List item for Show captured image modal dialog: doesn't show the captured image</comment>
      <extra-loc-engineeringenglish>&lt;![CDATA[]]&gt;</extra-loc-engineeringenglish>
      <source>No105</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="لا">لا</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>200</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid />
      <extra-loc-viewid />
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_not_video" marked="false">
      <extracomment />
      <location />
      <comment>Value for 'Show captured video' modal dialog</comment>
      <extra-loc-engineeringenglish>Not</extra-loc-engineeringenglish>
      <source>No106</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="لا">لا</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>200</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_portrait" marked="false">
      <extracomment />
      <location />
      <comment>List item. Scene mode for portrait photographing.</comment>
      <extra-loc-engineeringenglish>Portrait</extra-loc-engineeringenglish>
      <source>Portrait107</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ar #Portrait</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>HbRadioButtonList</extra-loc-layout_id>
      <extra-loc-layout>HbRadioButtonList</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_08</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_sports" marked="false">
      <extracomment />
      <location />
      <comment>List item. Scene mode for sports photographing.</comment>
      <extra-loc-engineeringenglish>Sports</extra-loc-engineeringenglish>
      <source>Sports108</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ar #Sports</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>HbRadioButtonList</extra-loc-layout_id>
      <extra-loc-layout>HbRadioButtonList</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_08</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_camera_settings" marked="false">
      <extracomment />
      <location />
      <comment>Camera settings item in options menu</comment>
      <extra-loc-engineeringenglish>Camera settings</extra-loc-engineeringenglish>
      <source>Camera settings109</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="ضبط الكاميرا">ضبط الكاميرا</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_53,290,NOT_291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_01, cam_05, cam_18</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_capture_tone" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item, in Options sub menu</comment>
      <extra-loc-engineeringenglish>Capture tone</extra-loc-engineeringenglish>
      <source>Capture tone110</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="درجة الالتقاط">درجة الالتقاط</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>55,NOT_422</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_01, cam_05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_default_image_name" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item. in options sub-menu</comment>
      <extra-loc-engineeringenglish>Default image name</extra-loc-engineeringenglish>
      <source>Default image name111</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="اسم صورة افتراضي">اسم صورة افتراضي</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>630,133</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_01, cam_05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_default_video_name" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item</comment>
      <extra-loc-engineeringenglish>Default video name</extra-loc-engineeringenglish>
      <source>Default video name112</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="اسم فيديو افتراضي">اسم فيديو افتراضي</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>630,360</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_18, cam_22</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_exposure_compensation" marked="false">
      <extracomment />
      <location />
      <comment>Options list item in camcorder</comment>
      <extra-loc-engineeringenglish>Exposure compensation</extra-loc-engineeringenglish>
      <source>Exposure compensation113</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="تعويض درجة الإضاءة">تعويض درجة الإضاءة</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_18</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_general_settings" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item</comment>
      <extra-loc-engineeringenglish>General settings</extra-loc-engineeringenglish>
      <source>Settings114</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="الضبط">الضبط</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>290,NOT_291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_01, cam_05, cam_18</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_geotagging" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item in camcorder</comment>
      <extra-loc-engineeringenglish>Geotagging</extra-loc-engineeringenglish>
      <source>Geotagging115</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="وضع علامات جغرافية">وضع علامات جغرافية</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_18</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_go_to_photos" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item. Opens Photos application,</comment>
      <extra-loc-engineeringenglish>Go to Photos</extra-loc-engineeringenglish>
      <source>Photos116</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="الصور">الصور</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>492</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_01, cam_05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_go_to_videos" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item in camcorder</comment>
      <extra-loc-engineeringenglish>Go to 'Videos'</extra-loc-engineeringenglish>
      <source>Video clips117</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="مقاطع الفيديو">مقاطع الفيديو</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>360</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_18</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_image_quality" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item. in Options sub-menu</comment>
      <extra-loc-engineeringenglish>Image quality</extra-loc-engineeringenglish>
      <source>Image quality118</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="جودة الصورة">جودة الصورة</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>133,136</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_01, cam_05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_image_rotation" marked="false">
      <extracomment />
      <location />
      <comment>Options mneu item, in Options sub menu under 'General settings'</comment>
      <extra-loc-engineeringenglish>Image rotation</extra-loc-engineeringenglish>
      <source>Image rotation119</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="تدوير الصورة">تدوير الصورة</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>133</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_01, cam_05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_memory_in_use" marked="false">
      <extracomment />
      <location />
      <comment>Options list item in camcorder</comment>
      <extra-loc-engineeringenglish>Memory in use</extra-loc-engineeringenglish>
      <source>Memory in use120</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="الذاكرة المستخدمة">الذاكرة المستخدمة</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>173</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_05, cam_18</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_restore_settings" marked="false">
      <extracomment />
      <location />
      <comment>Options list item in camera and camcorder</comment>
      <extra-loc-engineeringenglish>Restore settings</extra-loc-engineeringenglish>
      <source>Restore settings121</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="استعادة الضبط">استعادة الضبط</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>290,NOT_291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_01, cam_05, cam_18</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_self_timer" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item. Opens self timer selection list</comment>
      <extra-loc-engineeringenglish>Self timer</extra-loc-engineeringenglish>
      <source>Self-timer122</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="الموقت الذاتي">الموقت الذاتي</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_01, cam_05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_set_as_default_scene_mode" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item in camera</comment>
      <extra-loc-engineeringenglish>Set as default scene mode</extra-loc-engineeringenglish>
      <source>Set as default scene mode123</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="ضبط كوضع افتراضي">ضبط كوضع افتراضي</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>630,293</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_01, cam_18</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_settings" marked="false">
      <extracomment />
      <location />
      <comment>Options list item in camera and camcorder</comment>
      <extra-loc-engineeringenglish>Settings</extra-loc-engineeringenglish>
      <source>Settings124</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="الضبط">الضبط</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>290,NOT_291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_26</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_show_captured_image" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item. in Options sub-menu</comment>
      <extra-loc-engineeringenglish>Show captured image</extra-loc-engineeringenglish>
      <source>Show captured image125</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ar #Show captured image</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>133</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_01, cam_05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_show_captured_video" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item</comment>
      <extra-loc-engineeringenglish>Show captured video</extra-loc-engineeringenglish>
      <source>Show captured video126</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="إظهار الفيديو المصور">إظهار الفيديو المصور</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>360</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_18, cam_22</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_upload_settings" marked="false">
      <extracomment />
      <location />
      <comment>options menu item: Link to Ovi share application</comment>
      <extra-loc-engineeringenglish>Upload settings</extra-loc-engineeringenglish>
      <source>Upload settings127</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="تحميل الضبط">تحميل الضبط</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>290,NOT_291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_1, cam_5, cam_18, cam_22</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_video_quality" marked="false">
      <extracomment />
      <location />
      <comment>Options list item in camcorder</comment>
      <extra-loc-engineeringenglish>Video quality</extra-loc-engineeringenglish>
      <source>Video quality128</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="جودة الفيديو">جودة الفيديو</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>360</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_18</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_video_sound" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item</comment>
      <extra-loc-engineeringenglish>Video sound</extra-loc-engineeringenglish>
      <source>Video sound129</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="صوت الفيديو">صوت الفيديو</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_360</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_18, cam_22</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_video_stabilization" marked="false">
      <extracomment />
      <location />
      <comment>Video stab. Item in options menu</comment>
      <extra-loc-engineeringenglish>Video stabilization</extra-loc-engineeringenglish>
      <source>Video stabilisation130</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="ثبات صورة الفيديو">ثبات صورة الفيديو</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_360,483</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_18</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_white_balance" marked="false">
      <extracomment />
      <location />
      <comment>Options list item in camcorder</comment>
      <extra-loc-engineeringenglish>White balance</extra-loc-engineeringenglish>
      <source>White balance131</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="توازن اللون الأبيض">توازن اللون الأبيض</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_18</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_other_default_image_name" marked="false">
      <extracomment />
      <location />
      <comment>Title for user defined default image name text input popup. Genuinely unique string</comment>
      <extra-loc-engineeringenglish>Default image name</extra-loc-engineeringenglish>
      <source>Default image name132</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="اسم الصورة الافتراضي">اسم الصورة الافتراضي</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>630,133</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>formlabel_1</extra-loc-positionid>
      <extra-loc-viewid>cam_14</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_other_delete_image" marked="false">
      <extracomment />
      <location />
      <comment>Confirmation dialogue asking if the user wants to delete image after selecting 'delete'</comment>
      <extra-loc-engineeringenglish>Delete image?</extra-loc-engineeringenglish>
      <source>Delete image?133</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ar #Delete image?</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri5</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri5</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>cam_34</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="yes" id="txt_cam_other_delete_n_items" marked="false">
      <extracomment />
      <location />
      <comment>Confirmation dialogue asking if the user wants to delete multiple items after selecting 'delete'</comment>
      <extra-loc-engineeringenglish>Delete %Ln items?</extra-loc-engineeringenglish>
      <source>Delete %Ln items?134</source>
      <translation testresult="false" keep="false">
        <numerusform plurality="a" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="">ar #Delete %Ln items?</numerusform>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri5</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri5</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>cam_34</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_other_delete_video_clip" marked="false">
      <extracomment />
      <location />
      <comment>Confirmation dialogue asking if the user wants to delete a video clip after selecting 'delete'</comment>
      <extra-loc-engineeringenglish>Delete video clip?</extra-loc-engineeringenglish>
      <source>Delete video clip?135</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ar #Delete video clip?</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri5</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri5</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>cam_34</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_other_please_type_here" marked="false">
      <extracomment />
      <location />
      <comment>Hint text in user defined default image name popup input field</comment>
      <extra-loc-engineeringenglish>Please type here</extra-loc-engineeringenglish>
      <source>Type here136</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="اكتب هنا">اكتب هنا</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>formlabel_1_val</extra-loc-positionid>
      <extra-loc-viewid>cam_14</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_other_restore_settings" marked="false">
      <extracomment />
      <location />
      <comment>Confirmation dialogue asking if the user wants to restore settings. This appears after user has selected the 'Restore settings' in settings grid</comment>
      <extra-loc-engineeringenglish>Restore settings?</extra-loc-engineeringenglish>
      <source>Restore settings?137</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ar #Restore settings?</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri5</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri5</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>cam_35</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_slidervalue_l1_minus" marked="false">
      <extracomment />
      <location />
      <comment>Slider value. Exposure cmpensation value.</comment>
      <extra-loc-engineeringenglish>-%L1</extra-loc-engineeringenglish>
      <source>-%L1138</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="-%L1">-%L1</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_slider_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_slider_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>slidervalue</extra-loc-positionid>
      <extra-loc-viewid>cam_09</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_slidervalue_l1_plus" marked="false">
      <extracomment />
      <location />
      <comment>Slider value. Exposure cmpensation value.</comment>
      <extra-loc-engineeringenglish>+%L1</extra-loc-engineeringenglish>
      <source>+%L1139</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="+%L1">+%L1</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_slider_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_slider_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>slidervalue</extra-loc-positionid>
      <extra-loc-viewid>cam_09</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_capture_tone" marked="false">
      <extracomment />
      <location />
      <comment>List title. Capture tone modal dialog.</comment>
      <extra-loc-engineeringenglish>Capture tone</extra-loc-engineeringenglish>
      <source>Capture tone140</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="درجة الالتقاط">درجة الالتقاط</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>55,NOT_422</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_change_mode" marked="false">
      <extracomment />
      <location />
      <comment>Title for camera mode change modal dialog</comment>
      <extra-loc-engineeringenglish>Change mode</extra-loc-engineeringenglish>
      <source>Change mode141</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="تغيير الوضع">تغيير الوضع</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_color_tone" marked="false">
      <extracomment />
      <location />
      <comment>List title. Color tone selection list.</comment>
      <extra-loc-engineeringenglish>Color tone</extra-loc-engineeringenglish>
      <source>Colour tone142</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="درجة اللون">درجة اللون</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_422</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_contrast" marked="false">
      <extracomment />
      <location />
      <comment>Title for contrast slider</comment>
      <extra-loc-engineeringenglish>Contrast</extra-loc-engineeringenglish>
      <source>Contrast143</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="التباين">التباين</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_09</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_default_image_name" marked="false">
      <extracomment />
      <location />
      <comment>Title for default image name modal dialog</comment>
      <extra-loc-engineeringenglish>Default image name</extra-loc-engineeringenglish>
      <source>Default image name144</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="اسم الصورة الافتراضي">اسم الصورة الافتراضي</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>630,133</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_13</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_default_video_name" marked="false">
      <extracomment />
      <location />
      <comment>Modal dialog title</comment>
      <extra-loc-engineeringenglish>Default video name</extra-loc-engineeringenglish>
      <source>Default video name145</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="اسم الفيديو الافتراضي">اسم الفيديو الافتراضي</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>630,360</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_exposure_compensation" marked="false">
      <extracomment />
      <location />
      <comment>Slider title. Exposure compensation selection slider.</comment>
      <extra-loc-engineeringenglish>Exposure compensation</extra-loc-engineeringenglish>
      <source>Exposure compensation146</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="تعويض درجة الإضاءة">تعويض درجة الإضاءة</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_09</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_face_tracking" marked="false">
      <extracomment />
      <location />
      <comment>Title for Face tracking setting modal dialog</comment>
      <extra-loc-engineeringenglish>Face tracking</extra-loc-engineeringenglish>
      <source>Face detection147</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="اكتشاف الوجه">اكتشاف الوجه</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>772</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_10</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_flash_mode" marked="false">
      <extracomment />
      <location />
      <comment>List title. Flash mode selection list.</comment>
      <extra-loc-engineeringenglish>Flash mode</extra-loc-engineeringenglish>
      <source>Flash148</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="فلاش">فلاش</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_image_quality" marked="false">
      <extracomment />
      <location />
      <comment>Heading for imge quality selection list</comment>
      <extra-loc-engineeringenglish>Image quality</extra-loc-engineeringenglish>
      <source>Image quality149</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="جودة الصورة">جودة الصورة</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>133,136</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_11</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_image_rotation" marked="false">
      <extracomment />
      <location />
      <comment>List title. Image rotation modal dialog. Values for the dialog are yes/no</comment>
      <extra-loc-engineeringenglish>Image rotation</extra-loc-engineeringenglish>
      <source>Image rotation150</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="تدوير الصورة">تدوير الصورة</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>133</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_light_sensitivity" marked="false">
      <extracomment />
      <location />
      <comment>Heading for imge quality selection list</comment>
      <extra-loc-engineeringenglish>Light sensitivity</extra-loc-engineeringenglish>
      <source>Light sensitivity151</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="الحساسية للضوء">الحساسية للضوء</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_memory_in_use" marked="false">
      <extracomment />
      <location />
      <comment>Title for memory in use setting modal dialog</comment>
      <extra-loc-engineeringenglish>Memory in use</extra-loc-engineeringenglish>
      <source>Memory in use152</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="الذاكرة المستخدمة">الذاكرة المستخدمة</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>173</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_12</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_scene_mode" marked="false">
      <extracomment />
      <location />
      <comment>List title. Scene mode selection list.</comment>
      <extra-loc-engineeringenglish>Scene mode</extra-loc-engineeringenglish>
      <source>Scene mode153</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="وضع المنظر">وضع المنظر</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>293</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_08, cam_18, cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_self_timer" marked="false">
      <extracomment />
      <location />
      <comment>List title. Self timer selection list.</comment>
      <extra-loc-engineeringenglish>Self timer</extra-loc-engineeringenglish>
      <source>Self-timer154</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="الموقت الذاتي">الموقت الذاتي</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_16</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_set_as_default_scene_mode" marked="false">
      <extracomment />
      <location />
      <comment>Radio button list title</comment>
      <extra-loc-engineeringenglish>Set as default scene mode</extra-loc-engineeringenglish>
      <source>Set as default scene mode155</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="ضبط كوضع افتراضي">ضبط كوضع افتراضي</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>630,293</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_show_captured_image" marked="false">
      <extracomment />
      <location />
      <comment>List title. Show captured image selection modal dialog</comment>
      <extra-loc-engineeringenglish>Show captured image</extra-loc-engineeringenglish>
      <source>Show captured image156</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="عرض الصورة الملتقطة">عرض الصورة الملتقطة</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>133</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_07, cam_28</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_show_captured_video" marked="false">
      <extracomment />
      <location />
      <comment>Modal dialog title</comment>
      <extra-loc-engineeringenglish>Show captured video</extra-loc-engineeringenglish>
      <source>Show captured video157</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="إظهار الفيديو المصور">إظهار الفيديو المصور</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>360</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_video_quality" marked="false">
      <extracomment />
      <location />
      <comment>Title for video quality modal dialog</comment>
      <extra-loc-engineeringenglish>Video quality</extra-loc-engineeringenglish>
      <source>Video quality158</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="جودة الفيديو">جودة الفيديو</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>360</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_24</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_video_sound" marked="false">
      <extracomment />
      <location />
      <comment>Modal dialog title</comment>
      <extra-loc-engineeringenglish>Video sound</extra-loc-engineeringenglish>
      <source>Video sound159</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="صوت الفيديو">صوت الفيديو</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_360</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_video_stabilization" marked="false">
      <extracomment />
      <location />
      <comment>Title for modal dialog</comment>
      <extra-loc-engineeringenglish>Video stabilization</extra-loc-engineeringenglish>
      <source>Video stabilisation160</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="ثبات صورة الفيديو">ثبات صورة الفيديو</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_360,483</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_white_balance" marked="false">
      <extracomment />
      <location />
      <comment>List title. White balance selection list.</comment>
      <extra-loc-engineeringenglish>White balance</extra-loc-engineeringenglish>
      <source>White balance161</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="توازن اللون الأبيض">توازن اللون الأبيض</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_07, cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_long_caption_camera " marked="false">
      <extracomment />
      <location />
      <comment>Caption text. Application name.</comment>
      <extra-loc-engineeringenglish>Camera</extra-loc-engineeringenglish>
      <source>Camera162</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="الكاميرا">الكاميرا</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>53</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_short_caption_camera" marked="false">
      <extracomment />
      <location />
      <comment>Caption text. Application name.</comment>
      <extra-loc-engineeringenglish>Camera</extra-loc-engineeringenglish>
      <source>Camera163</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ar #Camera</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_grid_applications_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_grid_applications_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>grid</extra-loc-positionid>
      <extra-loc-viewid>cam</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
  </context>
</TS>