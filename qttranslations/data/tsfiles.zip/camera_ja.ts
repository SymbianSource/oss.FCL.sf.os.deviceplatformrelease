<?xml version="1.0" encoding="utf-8"?>
<TS xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" version="1.0" sourcelanguage="English-GB" language="ja">
  <extra-loc-extended xsi:type="xsd:boolean">true</extra-loc-extended>
  <defaultcodec />
  <extra-loc-feature xsi:type="xsd:string">camera@dfsxx.01</extra-loc-feature>
  <extra-loc-style xsi:type="xsd:string">ts</extra-loc-style>
  <context>
    <name>Prophet</name>
    <message numerus="no" id="txt_cam_button_cancel" marked="false">
      <extracomment />
      <location />
      <comment>Self-timer Cancel button</comment>
      <extra-loc-engineeringenglish>Cancel</extra-loc-engineeringenglish>
      <source>Cancel85</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Cancel</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_softkey_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_softkey_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>54</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>cam_17</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_button_color_tone" marked="false">
      <extracomment />
      <location />
      <comment>Item name in toolbar extension. The name is visible under an icon</comment>
      <extra-loc-engineeringenglish>Color tone</extra-loc-engineeringenglish>
      <source>Color tone86</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja #Color tone</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_grid_applications_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_grid_applications_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>grid</extra-loc-positionid>
      <extra-loc-viewid>cam_06</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_button_contrast" marked="false">
      <extracomment />
      <location />
      <comment>Item name in toolbar extension. The name is visible under an icon</comment>
      <extra-loc-engineeringenglish>Contrast</extra-loc-engineeringenglish>
      <source>Contrast87</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja #Contrast</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_grid_applications_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_grid_applications_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>grid</extra-loc-positionid>
      <extra-loc-viewid>cam_06</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_button_exposure_compensation" marked="false">
      <extracomment />
      <location />
      <comment>Item name in toolbar extension. The name is visible under an icon</comment>
      <extra-loc-engineeringenglish>Exposure compensation</extra-loc-engineeringenglish>
      <source>Exposure compensation88</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja #Exposure compensation</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_grid_applications_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_grid_applications_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>grid</extra-loc-positionid>
      <extra-loc-viewid>cam_06</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_button_face_tracking" marked="false">
      <extracomment />
      <location />
      <comment>Item name in toolbar extension. The name is visible under an icon</comment>
      <extra-loc-engineeringenglish>Face tracking</extra-loc-engineeringenglish>
      <source>Face tracking89</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja #Face tracking</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_grid_applications_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_grid_applications_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>grid</extra-loc-positionid>
      <extra-loc-viewid>cam_06</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_button_geotagging" marked="false">
      <extracomment />
      <location />
      <comment>Item name in toolbar extension. The name is visible under an icon</comment>
      <extra-loc-engineeringenglish>Geotagging</extra-loc-engineeringenglish>
      <source>Geotagging90</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja #Geotagging</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_grid_applications_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_grid_applications_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>grid</extra-loc-positionid>
      <extra-loc-viewid>cam_06</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_button_iso" marked="false">
      <extracomment />
      <location />
      <comment>Item name in toolbar extension. The name is visible under an icon</comment>
      <extra-loc-engineeringenglish>ISO</extra-loc-engineeringenglish>
      <source>ISO91</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja #ISO</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_grid_applications_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_grid_applications_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>grid</extra-loc-positionid>
      <extra-loc-viewid>cam_06</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_button_start" marked="false">
      <extracomment />
      <location />
      <comment>Self-timer start button</comment>
      <extra-loc-engineeringenglish>Start</extra-loc-engineeringenglish>
      <source>Start92</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Start</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_softkey_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_softkey_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>320</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>cam_17</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_button_white_balance" marked="false">
      <extracomment />
      <location />
      <comment>Item name in toolbar extension. The name is visible under an icon</comment>
      <extra-loc-engineeringenglish>White balance</extra-loc-engineeringenglish>
      <source>White balance93</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja #White balance</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_grid_applications_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_grid_applications_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>grid</extra-loc-positionid>
      <extra-loc-viewid>cam_06</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_caption_camera" marked="false">
      <extracomment />
      <location />
      <comment>Camera caption string. Application name.</comment>
      <extra-loc-engineeringenglish>Camera</extra-loc-engineeringenglish>
      <source>Camera94</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja #Camera</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>cell_tport_appsw_pane_t1</extra-loc-layout_id>
      <extra-loc-layout>cell_tport_appsw_pane_t1</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>caption</extra-loc-positionid>
      <extra-loc-viewid>cam</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_dblist_hd_720p_169_widescreen" marked="false">
      <extracomment />
      <location />
      <comment>Video quality value in modal dialog</comment>
      <extra-loc-engineeringenglish>HD 720p 16:9 widescreen</extra-loc-engineeringenglish>
      <source>HD 720p 16:9 widescreen95</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja HD 720p 16:9 widescreen</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dblist_1</extra-loc-positionid>
      <extra-loc-viewid>cam_24</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="yes" id="txt_cam_dblist_hd_720p_val_ln_images_left" marked="false">
      <extracomment />
      <location />
      <comment>Image quality value in modal dialog, second row</comment>
      <extra-loc-engineeringenglish>%Ln images left</extra-loc-engineeringenglish>
      <source>%Ln images left96</source>
      <translation testresult="false" keep="false">
        <numerusform plurality="a" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="">ja %Ln image left</numerusform>
      </translation>
      <oldsource>%Ln image left</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>133</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dblist_1_val</extra-loc-positionid>
      <extra-loc-viewid>cam_11, cam_12</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_dblist_hd_720p_val_ln_recording_time_left" marked="false">
      <extracomment />
      <location />
      <comment>Video quality value in modal dialog, second row</comment>
      <extra-loc-engineeringenglish>Recording time left: %L1</extra-loc-engineeringenglish>
      <source>Recording time left: %L197</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja %Ln recording time left</lengthvariant>
      </translation>
      <oldsource>%Ln recording times left</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dblist_1_val</extra-loc-positionid>
      <extra-loc-viewid>cam_24</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="yes" id="txt_cam_dblist_ln_mpix" marked="false">
      <extracomment />
      <location />
      <comment>Amount of Mpix when image/video quality is Maximum</comment>
      <extra-loc-engineeringenglish>%Ln Mpix</extra-loc-engineeringenglish>
      <source>%Ln Mpix98</source>
      <translation testresult="false" keep="false">
        <numerusform plurality="a" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="">ja %Ln Mpix</numerusform>
      </translation>
      <oldsource>%Ln Mpix</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dblist_1</extra-loc-positionid>
      <extra-loc-viewid>cam_11</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="yes" id="txt_cam_dblist_ln_mpix_widescreen" marked="false">
      <extracomment />
      <location />
      <comment>Amount of Mpix when image/video quality is maximum. Indicates that image is displayed in widescreen mode.</comment>
      <extra-loc-engineeringenglish>%Ln Mpix widescreen</extra-loc-engineeringenglish>
      <source>%Ln Mpix widescreen99</source>
      <translation testresult="false" keep="false">
        <numerusform plurality="a" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="">ja %Ln Mpix widescreen</numerusform>
      </translation>
      <oldsource>%Ln Mpix widescreen</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dblist_2</extra-loc-positionid>
      <extra-loc-viewid>cam_11</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_dblist_mass_memory" marked="false">
      <extracomment />
      <location />
      <comment>List item for memory in use modal dialog</comment>
      <extra-loc-engineeringenglish>Mass memory</extra-loc-engineeringenglish>
      <source>Mass memory100</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Mass memory</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>414,NOT_173</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dblist_2</extra-loc-positionid>
      <extra-loc-viewid>cam_12</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_dblist_memory_card" marked="false">
      <extracomment />
      <location />
      <comment>List item for memory in use modal dialog</comment>
      <extra-loc-engineeringenglish>Memory card</extra-loc-engineeringenglish>
      <source>Memory card101</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Memory card</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_173,174</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dblist_3</extra-loc-positionid>
      <extra-loc-viewid>cam_12</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_dblist_phone_memory" marked="false">
      <extracomment />
      <location />
      <comment>List item for memory in use modal dialog</comment>
      <extra-loc-engineeringenglish>Phone memory</extra-loc-engineeringenglish>
      <source>Phone memory102</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Phone memory</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_173,NOT_228,478</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dblist_1</extra-loc-positionid>
      <extra-loc-viewid>cam_12</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_dblist_qcif_sharing" marked="false">
      <extracomment />
      <location />
      <comment>Video quality value in modal dialog</comment>
      <extra-loc-engineeringenglish>QCIF Sharing</extra-loc-engineeringenglish>
      <source>QCIF sharing103</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja QCIF sharing</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dblist_3</extra-loc-positionid>
      <extra-loc-viewid>cam_24</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_dblist_vga" marked="false">
      <extracomment />
      <location />
      <comment>Image quality value in modal dialog</comment>
      <extra-loc-engineeringenglish>VGA</extra-loc-engineeringenglish>
      <source>VGA104</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja VGA</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dblist_3</extra-loc-positionid>
      <extra-loc-viewid>cam_11</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_dblist_vga_43" marked="false">
      <extracomment />
      <location />
      <comment>Video quality value in modal dialog</comment>
      <extra-loc-engineeringenglish>VGA 4:3</extra-loc-engineeringenglish>
      <source>VGA 4:3105</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja VGA 4:3</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dblist_2</extra-loc-positionid>
      <extra-loc-viewid>cam_24</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_info_camera_already_in_use" marked="false">
      <extracomment />
      <location />
      <comment>Error note when camera is already in use by another application</comment>
      <extra-loc-engineeringenglish>Camera already in use</extra-loc-engineeringenglish>
      <source>Camera already in use106</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja #Camera already in use</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri5</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri5</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>cam_33</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_info_camera_in_standby_mode" marked="false">
      <extracomment />
      <location />
      <comment>Info note. Camera is in stand by mode. Touching of screen starts view finder again.</comment>
      <extra-loc-engineeringenglish>Camera in stand-by mode</extra-loc-engineeringenglish>
      <source>Camera in stand-by mode107</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja #Camera in stand-by mode</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri5</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri5</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>cam_04</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_info_captured_photos_and_videos_will_be_ta" marked="false">
      <extracomment />
      <location />
      <comment>Info note for the first time use of the camera application. The note gives a warning about the geotagging feature which is on by default.</comment>
      <extra-loc-engineeringenglish>Captured photos and videos will be tagged with your location. If photos or videos are shared, the location data may also be visible to third parties. Phone will use network to get the location data. Data transfer charges may apply. Location recording can be disabled in settings.</extra-loc-engineeringenglish>
      <source>Captured photos and videos will be tagged with your location. If photos or videos are shared, location data may also be visible to third parties. The phone will use network to get location data. Data transfer charges may apply. Location recording can be disabled in settings.108</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Captured photos and videos will be tagged with your location. If photos or videos are shared, location data may also be visible to third parties. The phone will use network to get location data. Data transfer charges may apply. Location recording can be disabled in settings.</translation>
      <oldsource>Captured photos and videos will be tagged with your location. If the photos or videos are shared, the location data may also be visible to third parties. The phone will use the network to get the location data. Data transfer charges may apply. Location recording can be disbaled in settings.</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>none</extra-loc-layout_id>
      <extra-loc-layout>none</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_76,543,NOT_544,228,NOT_492,290,NOT_291,360</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>cam_49</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_info_error" marked="false">
      <extracomment />
      <location />
      <comment>Info note. Error message.</comment>
      <extra-loc-engineeringenglish>Unexpected error occurred. Power off the device and restart</extra-loc-engineeringenglish>
      <source>Unexpected error occurred. Power off the device and restart109</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja #Unexpected error occurred. Power off the device and restart</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri5</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri5</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>cam_32</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_info_no_memory_card_in_device_please_inse" marked="false">
      <extracomment />
      <location />
      <comment>Info note telling the user to insert memory card to be able to take photos.</comment>
      <extra-loc-engineeringenglish>No memory card in device. Please insert memory card in order to capture images.</extra-loc-engineeringenglish>
      <source>No memory card in device. Please insert memory card in order to capture images.110</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja #No memory card in device. Please insert memory card in order to capture images.</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri5</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri5</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>cam_36</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_flash" marked="false">
      <extracomment />
      <location />
      <comment>List item. Flash mode automatic. Flash used automatically when necessary.</comment>
      <extra-loc-engineeringenglish>Automatic</extra-loc-engineeringenglish>
      <source>Automatic111</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Automatic</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_lightsens" marked="false">
      <extracomment />
      <location />
      <comment>List item. Light sensitivity is selected automatically.</comment>
      <extra-loc-engineeringenglish>Automatic</extra-loc-engineeringenglish>
      <source>Automatic112</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Automatic</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_scene" marked="false">
      <extracomment />
      <location />
      <comment>List item. Scene mode is selected automatically.</comment>
      <extra-loc-engineeringenglish>Automatic</extra-loc-engineeringenglish>
      <source>Automatic113</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Automatic</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_08, cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_automatic_whitebal" marked="false">
      <extracomment />
      <location />
      <comment>List item. White balance value value</comment>
      <extra-loc-engineeringenglish>Automatic</extra-loc-engineeringenglish>
      <source>Automatic114</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Automatic</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07, cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_camcorder" marked="false">
      <extracomment />
      <location />
      <comment>List item name in modal dialog for changing the mode of the application</comment>
      <extra-loc-engineeringenglish>Camcorder</extra-loc-engineeringenglish>
      <source>Video camera115</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Video camera</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_53,NOT_360</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_camera" marked="false">
      <extracomment />
      <location />
      <comment>List item name in modal dialog for changing the mode of the application</comment>
      <extra-loc-engineeringenglish>Camera</extra-loc-engineeringenglish>
      <source>Camera116</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Camera</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_53</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_closeup" marked="false">
      <extracomment />
      <location />
      <comment>List item name for radio button list for changing the scene mode</comment>
      <extra-loc-engineeringenglish>Close-up</extra-loc-engineeringenglish>
      <source>Close-up117</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Close-up</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>64</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_08</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_cloudy" marked="false">
      <extracomment />
      <location />
      <comment>List item. White balance value:cloudy.</comment>
      <extra-loc-engineeringenglish>Cloudy</extra-loc-engineeringenglish>
      <source>Cloudy118</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Cloudy</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07, cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_continuous" marked="false">
      <extracomment />
      <location />
      <comment>List item for Show captured image modal dialog: image doesn't have a time out</comment>
      <extra-loc-engineeringenglish>Continuous</extra-loc-engineeringenglish>
      <source>Continuous119</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Continuous</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07, cam_28</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_continuous_video" marked="false">
      <extracomment />
      <location />
      <comment>Value for 'Show captured video' modal dialog</comment>
      <extra-loc-engineeringenglish>Continuous</extra-loc-engineeringenglish>
      <source>Continuous120</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Continuous</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_date" marked="false">
      <extracomment />
      <location />
      <comment>List item for default image name modal dialog</comment>
      <extra-loc-engineeringenglish>Date</extra-loc-engineeringenglish>
      <source>Date121</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Date</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_13</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_fluorescent" marked="false">
      <extracomment />
      <location />
      <comment>List item. White balance value:fluorescent. To be used indoors where fluorescent lamps ae used.</comment>
      <extra-loc-engineeringenglish>Fluorescent</extra-loc-engineeringenglish>
      <source>Fluorescent122</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Fluorescent</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>484</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07, cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_incandescent" marked="false">
      <extracomment />
      <location />
      <comment>List item. White balance value: incandescent. To be used indoors where glow lamps / incandescent lamps are used.</comment>
      <extra-loc-engineeringenglish>Incandescent</extra-loc-engineeringenglish>
      <source>Incandescent123</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Incandescent</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>485</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07, cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_landscape" marked="false">
      <extracomment />
      <location />
      <comment>List item. Scene mode for landscape photographing.</comment>
      <extra-loc-engineeringenglish>Landscape</extra-loc-engineeringenglish>
      <source>Landscape124</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja #Landscape</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>HbRadioButtonList</extra-loc-layout_id>
      <extra-loc-layout>HbRadioButtonList</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_08</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_sec" marked="false">
      <extracomment />
      <location />
      <comment>List item for show captured image modal dialog: shows the image for 2 seconds after capturing</comment>
      <extra-loc-engineeringenglish>%Ln sec</extra-loc-engineeringenglish>
      <source>%Ln seconds125</source>
      <translation testresult="false" keep="false">
        <numerusform plurality="a" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="">ja %Ln second</numerusform>
      </translation>
      <oldsource>%Ln second</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07, cam_28</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_sec_video" marked="false">
      <extracomment />
      <location />
      <comment>Value for 'Show captured video' modal dialog</comment>
      <extra-loc-engineeringenglish>%Ln sec</extra-loc-engineeringenglish>
      <source>%Ln seconds126</source>
      <translation testresult="false" keep="false">
        <numerusform plurality="a" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="">ja %Ln second</numerusform>
      </translation>
      <oldsource>%Ln second</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="yes" id="txt_cam_list_ln_seconds" marked="false">
      <extracomment />
      <location />
      <comment>List item. Self timer period 2 seconds.</comment>
      <extra-loc-engineeringenglish>%Ln seconds</extra-loc-engineeringenglish>
      <source>%Ln seconds127</source>
      <translation testresult="false" keep="false">
        <numerusform plurality="a" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="">ja %Ln second</numerusform>
      </translation>
      <oldsource>%Ln second</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_16</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_low_light" marked="false">
      <extracomment />
      <location />
      <comment>List item. Scene mode for filming video indoors.</comment>
      <extra-loc-engineeringenglish>Low light</extra-loc-engineeringenglish>
      <source>Low light128</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Low light</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>776</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_negative" marked="false">
      <extracomment />
      <location />
      <comment>List item. Color tone value: negative.</comment>
      <extra-loc-engineeringenglish>Negative</extra-loc-engineeringenglish>
      <source>Negative129</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Negative</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_night" marked="false">
      <extracomment />
      <location />
      <comment>List item. Scene mode for night time photographing</comment>
      <extra-loc-engineeringenglish>Night</extra-loc-engineeringenglish>
      <source>Night130</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Night</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>199</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_08</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_night_portrait" marked="false">
      <extracomment />
      <location />
      <comment>List item. Scene mode for portrait photographing in low light.</comment>
      <extra-loc-engineeringenglish>Night portrait</extra-loc-engineeringenglish>
      <source>Night portrait131</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja #Night portrait</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>HbRadioButtonList</extra-loc-layout_id>
      <extra-loc-layout>HbRadioButtonList</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_08</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_night_video" marked="false">
      <extracomment />
      <location />
      <comment>Value for camcorder scene mode selection modal dialog</comment>
      <extra-loc-engineeringenglish>Night</extra-loc-engineeringenglish>
      <source>Night132</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Night</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>199</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_no_image" marked="false">
      <extracomment />
      <location />
      <comment>Value for show captured image modal dialog</comment>
      <extra-loc-engineeringenglish>No</extra-loc-engineeringenglish>
      <source>No133</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja No</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>200</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07, cam_28</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_no_rotate" marked="false">
      <extracomment />
      <location />
      <comment>Image rotation value in radio button list</comment>
      <extra-loc-engineeringenglish>No</extra-loc-engineeringenglish>
      <source>No134</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja No</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>200</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_no_video" marked="false">
      <extracomment />
      <location />
      <comment>Value for show captured video modal dialog</comment>
      <extra-loc-engineeringenglish>No</extra-loc-engineeringenglish>
      <source>No135</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja No</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>200</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_normal" marked="false">
      <extracomment />
      <location />
      <comment>List item. Color tone value: normal.</comment>
      <extra-loc-engineeringenglish>Normal</extra-loc-engineeringenglish>
      <source>Normal136</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Normal</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>201</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_not" marked="false">
      <extracomment />
      <location />
      <comment>List item for Show captured image modal dialog: doesn't show the captured image</comment>
      <extra-loc-engineeringenglish>&lt;![CDATA[]]&gt;</extra-loc-engineeringenglish>
      <source>No137</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja No</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>200</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid />
      <extra-loc-viewid />
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_not_video" marked="false">
      <extracomment />
      <location />
      <comment>Value for 'Show captured video' modal dialog</comment>
      <extra-loc-engineeringenglish>Not</extra-loc-engineeringenglish>
      <source>No138</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja No</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>200</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_off_face" marked="false">
      <extracomment />
      <location />
      <comment>List item for Face tracking and video sound setting modal dialogs</comment>
      <extra-loc-engineeringenglish>Off</extra-loc-engineeringenglish>
      <source>Off139</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Off</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07, cam_10</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_off_flash" marked="false">
      <extracomment />
      <location />
      <comment>List item. Flash setting off</comment>
      <extra-loc-engineeringenglish>Off</extra-loc-engineeringenglish>
      <source>Off140</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Off</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07, cam_16</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_off_scene" marked="false">
      <extracomment />
      <location />
      <comment>Value for default scene mode setting modal dialog</comment>
      <extra-loc-engineeringenglish>Off</extra-loc-engineeringenglish>
      <source>Off141</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Off</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_off_stabil" marked="false">
      <extracomment />
      <location />
      <comment>Value for modal dialog</comment>
      <extra-loc-engineeringenglish>Off</extra-loc-engineeringenglish>
      <source>Off142</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Off</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_off_timer" marked="false">
      <extracomment />
      <location />
      <comment>Self timer off</comment>
      <extra-loc-engineeringenglish>Off</extra-loc-engineeringenglish>
      <source>Off143</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Off</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_16</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_off_video" marked="false">
      <extracomment />
      <location />
      <comment>Value in video sound modal dialog</comment>
      <extra-loc-engineeringenglish>Off</extra-loc-engineeringenglish>
      <source>Off144</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Off</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_on_face" marked="false">
      <extracomment />
      <location />
      <comment>List item for Face tracking setting and video sound modal dialogs</comment>
      <extra-loc-engineeringenglish>On</extra-loc-engineeringenglish>
      <source>On145</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja On</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07, cam_10</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_on_flash" marked="false">
      <extracomment />
      <location />
      <comment>List item. Flash mode always on.</comment>
      <extra-loc-engineeringenglish>On</extra-loc-engineeringenglish>
      <source>On146</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja On</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07, cam_16</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_on_scene" marked="false">
      <extracomment />
      <location />
      <comment>Value for default scene mode setting modal dialog</comment>
      <extra-loc-engineeringenglish>On</extra-loc-engineeringenglish>
      <source>On147</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja On</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_on_stabil" marked="false">
      <extracomment />
      <location />
      <comment>Value for modal dialog</comment>
      <extra-loc-engineeringenglish>On</extra-loc-engineeringenglish>
      <source>On148</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja On</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_on_video" marked="false">
      <extracomment />
      <location />
      <comment>Value in video sound modal dialog</comment>
      <extra-loc-engineeringenglish>On</extra-loc-engineeringenglish>
      <source>On149</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja On</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_portrait" marked="false">
      <extracomment />
      <location />
      <comment>List item. Scene mode for portrait photographing.</comment>
      <extra-loc-engineeringenglish>Portrait</extra-loc-engineeringenglish>
      <source>Portrait150</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja #Portrait</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>HbRadioButtonList</extra-loc-layout_id>
      <extra-loc-layout>HbRadioButtonList</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_08</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_reduce_red_eye" marked="false">
      <extracomment />
      <location />
      <comment>List item. Flash mode reduce red eye. Flash is used prior capture to minimize red eye occurrence.</comment>
      <extra-loc-engineeringenglish>Reduce red eye</extra-loc-engineeringenglish>
      <source>Red-eye reduction151</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Red-eye reduction</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>773</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_secondary_camcorder" marked="false">
      <extracomment />
      <location />
      <comment>List item name in modal dialog for changing the application's mode</comment>
      <extra-loc-engineeringenglish>Secondary camcorder</extra-loc-engineeringenglish>
      <source>Secondary video camera152</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Secondary video camera</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_53,NOT_360</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_secondary_camera" marked="false">
      <extracomment />
      <location />
      <comment>List item name in modal dialog for changing the application's mode</comment>
      <extra-loc-engineeringenglish>Secondary camera</extra-loc-engineeringenglish>
      <source>Secondary camera153</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Secondary camera</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_53,277</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_sepia" marked="false">
      <extracomment />
      <location />
      <comment>List item. Color tone value: sepia.</comment>
      <extra-loc-engineeringenglish>Sepia</extra-loc-engineeringenglish>
      <source>Sepia154</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Sepia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_sports" marked="false">
      <extracomment />
      <location />
      <comment>List item. Scene mode for sports photographing.</comment>
      <extra-loc-engineeringenglish>Sports</extra-loc-engineeringenglish>
      <source>Sports155</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja #Sports</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>HbRadioButtonList</extra-loc-layout_id>
      <extra-loc-layout>HbRadioButtonList</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_08</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_sunny" marked="false">
      <extracomment />
      <location />
      <comment>List item. White balance value:sunny.</comment>
      <extra-loc-engineeringenglish>Sunny</extra-loc-engineeringenglish>
      <source>Sunny156</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Sunny</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07, cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_user_defined" marked="false">
      <extracomment />
      <location />
      <comment>List item for default image name modal dialog</comment>
      <extra-loc-engineeringenglish>User defined</extra-loc-engineeringenglish>
      <source>User defined157</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja User defined</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_13</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_user_defined_scene" marked="false">
      <extracomment />
      <location />
      <comment>List item name for radio button list for scene modes</comment>
      <extra-loc-engineeringenglish>User defined</extra-loc-engineeringenglish>
      <source>User defined158</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja User defined</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_08</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_vivid" marked="false">
      <extracomment />
      <location />
      <comment>List item. Color tone value: vivid.</comment>
      <extra-loc-engineeringenglish>Vivid</extra-loc-engineeringenglish>
      <source>Vivid159</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Vivid</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_white" marked="false">
      <extracomment />
      <location />
      <comment>List item. Color tone value: black and white.</comment>
      <extra-loc-engineeringenglish>Black and white</extra-loc-engineeringenglish>
      <source>Black and white160</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Black and white</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_yes_image" marked="false">
      <extracomment />
      <location />
      <comment>Value for show captured image modal dialog</comment>
      <extra-loc-engineeringenglish>Yes</extra-loc-engineeringenglish>
      <source>Yes161</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Yes</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>395</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07, cam_28</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_yes_rotate" marked="false">
      <extracomment />
      <location />
      <comment>Image rotation value in radio button list</comment>
      <extra-loc-engineeringenglish>Yes</extra-loc-engineeringenglish>
      <source>Yes162</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Yes</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>395</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_list_yes_video" marked="false">
      <extracomment />
      <location />
      <comment>Value for show captured video modal dialog</comment>
      <extra-loc-engineeringenglish>Yes</extra-loc-engineeringenglish>
      <source>Yes163</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Yes</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_popup_sec_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_popup_sec_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>395</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_camera_settings" marked="false">
      <extracomment />
      <location />
      <comment>Camera settings item in options menu</comment>
      <extra-loc-engineeringenglish>Camera settings</extra-loc-engineeringenglish>
      <source>Camera settings164</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Camera settings</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_53,290,NOT_291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_01, cam_05, cam_18</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_capture_tone" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item, in Options sub menu</comment>
      <extra-loc-engineeringenglish>Capture tone</extra-loc-engineeringenglish>
      <source>Capture tone165</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Capture tone</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>55,NOT_422</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_01, cam_05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_default_image_name" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item. in options sub-menu</comment>
      <extra-loc-engineeringenglish>Default image name</extra-loc-engineeringenglish>
      <source>Default image name166</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Default image name</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>630,133</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_01, cam_05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_default_video_name" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item</comment>
      <extra-loc-engineeringenglish>Default video name</extra-loc-engineeringenglish>
      <source>Default video name167</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Default video name</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>630,360</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_18, cam_22</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_exposure_compensation" marked="false">
      <extracomment />
      <location />
      <comment>Options list item in camcorder</comment>
      <extra-loc-engineeringenglish>Exposure compensation</extra-loc-engineeringenglish>
      <source>Exposure compensation168</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Exposure compensation</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_18</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_general_settings" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item</comment>
      <extra-loc-engineeringenglish>General settings</extra-loc-engineeringenglish>
      <source>Settings169</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Settings</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>290,NOT_291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_01, cam_05, cam_18</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_geotagging" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item in camcorder</comment>
      <extra-loc-engineeringenglish>Geotagging</extra-loc-engineeringenglish>
      <source>Geotagging170</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Geotagging</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_18</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_go_to_photos" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item. Opens Photos application,</comment>
      <extra-loc-engineeringenglish>Go to Photos</extra-loc-engineeringenglish>
      <source>Photos171</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Photos</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>492</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_01, cam_05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_go_to_videos" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item in camcorder</comment>
      <extra-loc-engineeringenglish>Go to 'Videos'</extra-loc-engineeringenglish>
      <source>Video clips172</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Video clips</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>360</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_18</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_image_quality" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item. in Options sub-menu</comment>
      <extra-loc-engineeringenglish>Image quality</extra-loc-engineeringenglish>
      <source>Image quality173</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Image quality</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>133,136</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_01, cam_05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_image_rotation" marked="false">
      <extracomment />
      <location />
      <comment>Options mneu item, in Options sub menu under 'General settings'</comment>
      <extra-loc-engineeringenglish>Image rotation</extra-loc-engineeringenglish>
      <source>Image rotation174</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Image rotation</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>133</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_01, cam_05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_memory_in_use" marked="false">
      <extracomment />
      <location />
      <comment>Options list item in camcorder</comment>
      <extra-loc-engineeringenglish>Memory in use</extra-loc-engineeringenglish>
      <source>Memory in use175</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Memory in use</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>173</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_05, cam_18</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_restore_settings" marked="false">
      <extracomment />
      <location />
      <comment>Options list item in camera and camcorder</comment>
      <extra-loc-engineeringenglish>Restore settings</extra-loc-engineeringenglish>
      <source>Restore settings176</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Restore settings</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>290,NOT_291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_01, cam_05, cam_18</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_self_timer" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item. Opens self timer selection list</comment>
      <extra-loc-engineeringenglish>Self timer</extra-loc-engineeringenglish>
      <source>Self-timer177</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Self-timer</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_01, cam_05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_set_as_default_scene_mode" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item in camera</comment>
      <extra-loc-engineeringenglish>Set as default scene mode</extra-loc-engineeringenglish>
      <source>Set as default scene mode178</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Set as default scene mode</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>630,293</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_01, cam_18</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_settings" marked="false">
      <extracomment />
      <location />
      <comment>Options list item in camera and camcorder</comment>
      <extra-loc-engineeringenglish>Settings</extra-loc-engineeringenglish>
      <source>Settings179</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Settings</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>290,NOT_291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_26</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_show_captured_image" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item. in Options sub-menu</comment>
      <extra-loc-engineeringenglish>Show captured image</extra-loc-engineeringenglish>
      <source>Show captured image180</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja #Show captured image</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>133</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_01, cam_05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_show_captured_video" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item</comment>
      <extra-loc-engineeringenglish>Show captured video</extra-loc-engineeringenglish>
      <source>Show captured video181</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Show captured video</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>360</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_18, cam_22</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_upload_settings" marked="false">
      <extracomment />
      <location />
      <comment>options menu item: Link to Ovi share application</comment>
      <extra-loc-engineeringenglish>Upload settings</extra-loc-engineeringenglish>
      <source>Upload settings182</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Upload settings</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>290,NOT_291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_1, cam_5, cam_18, cam_22</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_video_quality" marked="false">
      <extracomment />
      <location />
      <comment>Options list item in camcorder</comment>
      <extra-loc-engineeringenglish>Video quality</extra-loc-engineeringenglish>
      <source>Video quality183</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Video quality</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>360</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_18</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_video_sound" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item</comment>
      <extra-loc-engineeringenglish>Video sound</extra-loc-engineeringenglish>
      <source>Video sound184</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Video sound</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_360</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_18, cam_22</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_video_stabilization" marked="false">
      <extracomment />
      <location />
      <comment>Video stab. Item in options menu</comment>
      <extra-loc-engineeringenglish>Video stabilization</extra-loc-engineeringenglish>
      <source>Video stabilisation185</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Video stabilisation</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_360,483</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_18</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_opt_white_balance" marked="false">
      <extracomment />
      <location />
      <comment>Options list item in camcorder</comment>
      <extra-loc-engineeringenglish>White balance</extra-loc-engineeringenglish>
      <source>White balance186</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja White balance</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>cam_18</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_other_default_image_name" marked="false">
      <extracomment />
      <location />
      <comment>Title for user defined default image name text input popup. Genuinely unique string</comment>
      <extra-loc-engineeringenglish>Default image name</extra-loc-engineeringenglish>
      <source>Default image name187</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Default image name</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>630,133</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>formlabel_1</extra-loc-positionid>
      <extra-loc-viewid>cam_14</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_other_delete_image" marked="false">
      <extracomment />
      <location />
      <comment>Confirmation dialogue asking if the user wants to delete image after selecting 'delete'</comment>
      <extra-loc-engineeringenglish>Delete image?</extra-loc-engineeringenglish>
      <source>Delete image?188</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja #Delete image?</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri5</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri5</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>cam_34</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="yes" id="txt_cam_other_delete_n_items" marked="false">
      <extracomment />
      <location />
      <comment>Confirmation dialogue asking if the user wants to delete multiple items after selecting 'delete'</comment>
      <extra-loc-engineeringenglish>Delete %Ln items?</extra-loc-engineeringenglish>
      <source>Delete %Ln items?189</source>
      <translation testresult="false" keep="false">
        <numerusform plurality="a" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="">ja #Delete %Ln items?</numerusform>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri5</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri5</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>cam_34</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_other_delete_video_clip" marked="false">
      <extracomment />
      <location />
      <comment>Confirmation dialogue asking if the user wants to delete a video clip after selecting 'delete'</comment>
      <extra-loc-engineeringenglish>Delete video clip?</extra-loc-engineeringenglish>
      <source>Delete video clip?190</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja #Delete video clip?</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri5</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri5</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>cam_34</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_other_please_type_here" marked="false">
      <extracomment />
      <location />
      <comment>Hint text in user defined default image name popup input field</comment>
      <extra-loc-engineeringenglish>Please type here</extra-loc-engineeringenglish>
      <source>Type here191</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Type here</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>formlabel_1_val</extra-loc-positionid>
      <extra-loc-viewid>cam_14</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_other_restore_settings" marked="false">
      <extracomment />
      <location />
      <comment>Confirmation dialogue asking if the user wants to restore settings. This appears after user has selected the 'Restore settings' in settings grid</comment>
      <extra-loc-engineeringenglish>Restore settings?</extra-loc-engineeringenglish>
      <source>Restore settings?192</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja #Restore settings?</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri5</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri5</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>cam_35</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_slidervalue_l1_minus" marked="false">
      <extracomment />
      <location />
      <comment>Slider value. Exposure cmpensation value.</comment>
      <extra-loc-engineeringenglish>-%L1</extra-loc-engineeringenglish>
      <source>-%L1193</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja -%L1</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_slider_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_slider_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>slidervalue</extra-loc-positionid>
      <extra-loc-viewid>cam_09</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_slidervalue_l1_plus" marked="false">
      <extracomment />
      <location />
      <comment>Slider value. Exposure cmpensation value.</comment>
      <extra-loc-engineeringenglish>+%L1</extra-loc-engineeringenglish>
      <source>+%L1194</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja +%L1</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_slider_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_slider_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>slidervalue</extra-loc-positionid>
      <extra-loc-viewid>cam_09</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_camera" marked="false">
      <extracomment />
      <location />
      <comment>Name of Camera application</comment>
      <extra-loc-engineeringenglish>Camera</extra-loc-engineeringenglish>
      <source>Camera195</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Camera</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_titlebar</extra-loc-layout_id>
      <extra-loc-layout>qtl_titlebar</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>53</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_01, cam_18, cam_25</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_capture_tone" marked="false">
      <extracomment />
      <location />
      <comment>List title. Capture tone modal dialog.</comment>
      <extra-loc-engineeringenglish>Capture tone</extra-loc-engineeringenglish>
      <source>Capture tone196</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Capture tone</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>55,NOT_422</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_change_mode" marked="false">
      <extracomment />
      <location />
      <comment>Title for camera mode change modal dialog</comment>
      <extra-loc-engineeringenglish>Change mode</extra-loc-engineeringenglish>
      <source>Change mode197</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Change mode</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_color_tone" marked="false">
      <extracomment />
      <location />
      <comment>List title. Color tone selection list.</comment>
      <extra-loc-engineeringenglish>Color tone</extra-loc-engineeringenglish>
      <source>Colour tone198</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Colour tone</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_422</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_contrast" marked="false">
      <extracomment />
      <location />
      <comment>Title for contrast slider</comment>
      <extra-loc-engineeringenglish>Contrast</extra-loc-engineeringenglish>
      <source>Contrast199</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Contrast</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_09</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_default_image_name" marked="false">
      <extracomment />
      <location />
      <comment>Title for default image name modal dialog</comment>
      <extra-loc-engineeringenglish>Default image name</extra-loc-engineeringenglish>
      <source>Default image name200</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Default image name</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>630,133</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_13</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_default_video_name" marked="false">
      <extracomment />
      <location />
      <comment>Modal dialog title</comment>
      <extra-loc-engineeringenglish>Default video name</extra-loc-engineeringenglish>
      <source>Default video name201</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Default video name</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>630,360</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_exposure_compensation" marked="false">
      <extracomment />
      <location />
      <comment>Slider title. Exposure compensation selection slider.</comment>
      <extra-loc-engineeringenglish>Exposure compensation</extra-loc-engineeringenglish>
      <source>Exposure compensation202</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Exposure compensation</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_09</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_face_tracking" marked="false">
      <extracomment />
      <location />
      <comment>Title for Face tracking setting modal dialog</comment>
      <extra-loc-engineeringenglish>Face tracking</extra-loc-engineeringenglish>
      <source>Face detection203</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Face detection</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>772</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_10</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_flash_mode" marked="false">
      <extracomment />
      <location />
      <comment>List title. Flash mode selection list.</comment>
      <extra-loc-engineeringenglish>Flash mode</extra-loc-engineeringenglish>
      <source>Flash204</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Flash</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_image_quality" marked="false">
      <extracomment />
      <location />
      <comment>Heading for imge quality selection list</comment>
      <extra-loc-engineeringenglish>Image quality</extra-loc-engineeringenglish>
      <source>Image quality205</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Image quality</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>133,136</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_11</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_image_rotation" marked="false">
      <extracomment />
      <location />
      <comment>List title. Image rotation modal dialog. Values for the dialog are yes/no</comment>
      <extra-loc-engineeringenglish>Image rotation</extra-loc-engineeringenglish>
      <source>Image rotation206</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Image rotation</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>133</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_light_sensitivity" marked="false">
      <extracomment />
      <location />
      <comment>Heading for imge quality selection list</comment>
      <extra-loc-engineeringenglish>Light sensitivity</extra-loc-engineeringenglish>
      <source>Light sensitivity207</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Light sensitivity</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_memory_in_use" marked="false">
      <extracomment />
      <location />
      <comment>Title for memory in use setting modal dialog</comment>
      <extra-loc-engineeringenglish>Memory in use</extra-loc-engineeringenglish>
      <source>Memory in use208</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Memory in use</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>173</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_12</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_scene_mode" marked="false">
      <extracomment />
      <location />
      <comment>List title. Scene mode selection list.</comment>
      <extra-loc-engineeringenglish>Scene mode</extra-loc-engineeringenglish>
      <source>Scene mode209</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Scene mode</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>293</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_08, cam_18, cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_self_timer" marked="false">
      <extracomment />
      <location />
      <comment>List title. Self timer selection list.</comment>
      <extra-loc-engineeringenglish>Self timer</extra-loc-engineeringenglish>
      <source>Self-timer210</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Self-timer</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_16</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_set_as_default_scene_mode" marked="false">
      <extracomment />
      <location />
      <comment>Radio button list title</comment>
      <extra-loc-engineeringenglish>Set as default scene mode</extra-loc-engineeringenglish>
      <source>Set as default scene mode211</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Set as default scene mode</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>630,293</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_show_captured_image" marked="false">
      <extracomment />
      <location />
      <comment>List title. Show captured image selection modal dialog</comment>
      <extra-loc-engineeringenglish>Show captured image</extra-loc-engineeringenglish>
      <source>Show captured image212</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Show captured image</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>133</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_07, cam_28</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_show_captured_video" marked="false">
      <extracomment />
      <location />
      <comment>Modal dialog title</comment>
      <extra-loc-engineeringenglish>Show captured video</extra-loc-engineeringenglish>
      <source>Show captured video213</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Show captured video</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>360</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_video_quality" marked="false">
      <extracomment />
      <location />
      <comment>Title for video quality modal dialog</comment>
      <extra-loc-engineeringenglish>Video quality</extra-loc-engineeringenglish>
      <source>Video quality214</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Video quality</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>360</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_24</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_video_sound" marked="false">
      <extracomment />
      <location />
      <comment>Modal dialog title</comment>
      <extra-loc-engineeringenglish>Video sound</extra-loc-engineeringenglish>
      <source>Video sound215</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Video sound</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_360</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_video_stabilization" marked="false">
      <extracomment />
      <location />
      <comment>Title for modal dialog</comment>
      <extra-loc-engineeringenglish>Video stabilization</extra-loc-engineeringenglish>
      <source>Video stabilisation216</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Video stabilisation</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_360,483</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cam_title_white_balance" marked="false">
      <extracomment />
      <location />
      <comment>List title. White balance selection list.</comment>
      <extra-loc-engineeringenglish>White balance</extra-loc-engineeringenglish>
      <source>White balance217</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja White balance</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>cam_07, cam_23</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_long_caption_camera " marked="false">
      <extracomment />
      <location />
      <comment>Caption text. Application name.</comment>
      <extra-loc-engineeringenglish>Camera</extra-loc-engineeringenglish>
      <source>Camera218</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja Camera</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>53</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>cam</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_short_caption_camera" marked="false">
      <extracomment />
      <location />
      <comment>Caption text. Application name.</comment>
      <extra-loc-engineeringenglish>Camera</extra-loc-engineeringenglish>
      <source>Camera219</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ja #Camera</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_grid_applications_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_grid_applications_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>grid</extra-loc-positionid>
      <extra-loc-viewid>cam</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
  </context>
</TS>