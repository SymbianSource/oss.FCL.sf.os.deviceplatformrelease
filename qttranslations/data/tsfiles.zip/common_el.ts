<?xml version="1.0" encoding="utf-8"?>
<TS xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" version="1.0" sourcelanguage="English-GB" language="el">
  <extra-loc-extended xsi:type="xsd:boolean">true</extra-loc-extended>
  <defaultcodec />
  <extra-loc-feature xsi:type="xsd:string">common@dfsxx.01</extra-loc-feature>
  <extra-loc-style xsi:type="xsd:string">ts</extra-loc-style>
  <context>
    <name>Prophet</name>
    <message numerus="no" id="txt_common_button_activate_object" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to take something into use (for example, activate a profile or music player Equalizer settings).</comment>
      <extra-loc-engineeringenglish>Activate</extra-loc-engineeringenglish>
      <source>Activate638</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ενεργοποίηση">Ενεργοποίηση</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>542</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_activate_process" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to start a process (for example, the countdown for the camera self-timer).</comment>
      <extra-loc-engineeringenglish>Activate</extra-loc-engineeringenglish>
      <source>Activate639</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ενεργοποίηση">Ενεργοποίηση</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>542</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_add" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to add an item, for example adding a song to playlist or a person into a chat group.</comment>
      <extra-loc-engineeringenglish>Add</extra-loc-engineeringenglish>
      <source>Add640</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Προσθήκη">Προσθήκη</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_answer" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the dialog. Allows the user to answer an incoming call.</comment>
      <extra-loc-engineeringenglish>Answer</extra-loc-engineeringenglish>
      <source>Answer641</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Απάντηση">Απάντηση</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_softkey_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_softkey_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_answer_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to answer an incoming call.</comment>
      <extra-loc-engineeringenglish>Answer</extra-loc-engineeringenglish>
      <source>Answer642</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">el #Answer</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_back" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Returns the user to the previous view.</comment>
      <extra-loc-engineeringenglish>Back</extra-loc-engineeringenglish>
      <source>Back643</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Πίσω">Πίσω</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>30</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_call" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. This string only refers to the verb "to call". Allows the user to start a call by pressing the button.</comment>
      <extra-loc-engineeringenglish>Call</extra-loc-engineeringenglish>
      <source>Call644</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Κλήση">Κλήση</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_43,402</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_cancel" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the dialog. Allows the user to cancel the action or process.</comment>
      <extra-loc-engineeringenglish>Cancel</extra-loc-engineeringenglish>
      <source>Cancel645</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Άκυρο">Άκυρο</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_softkey_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_softkey_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>54</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_cancel_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to cancel the action or process.</comment>
      <extra-loc-engineeringenglish>Cancel</extra-loc-engineeringenglish>
      <source>Cancel646</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">el #Cancel</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_change" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to change the selected item.</comment>
      <extra-loc-engineeringenglish>Change</extra-loc-engineeringenglish>
      <source>Change647</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Αλλαγή">Αλλαγή</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_clear" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the dialog. Allows the user to clear text from an editing field.</comment>
      <extra-loc-engineeringenglish>Clear</extra-loc-engineeringenglish>
      <source>Clear648</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Σβήσιμο">Σβήσιμο</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_softkey_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_softkey_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>60</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_clear_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to clear text from an editing field.</comment>
      <extra-loc-engineeringenglish>Clear</extra-loc-engineeringenglish>
      <source>Clear649</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">el #Clear</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_close" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to close e.g. a window.</comment>
      <extra-loc-engineeringenglish>Close</extra-loc-engineeringenglish>
      <source>Close650</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Κλείσιμο">Κλείσιμο</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>62</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_collapse" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to for example collapse a sorted list.</comment>
      <extra-loc-engineeringenglish>Collapse</extra-loc-engineeringenglish>
      <source>Collapse651</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Σύμπτυξη">Σύμπτυξη</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_connect" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to connect to a service.</comment>
      <extra-loc-engineeringenglish>Connect</extra-loc-engineeringenglish>
      <source>Connect652</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Σύνδεση">Σύνδεση</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_continue" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Displayed for example when the user is recording or playing a video or audio track or a slideshow and has paused the activity. When the user presses this button the recording or playing will continue.</comment>
      <extra-loc-engineeringenglish>Continue</extra-loc-engineeringenglish>
      <source>Continue653</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Συνέχεια">Συνέχεια</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>72</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_copy" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to copy and add the selected item into the clipboard.</comment>
      <extra-loc-engineeringenglish>Copy</extra-loc-engineeringenglish>
      <source>Copy654</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Αντιγραφή">Αντιγραφή</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>722</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_deactivate" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to deactivate the focused item.</comment>
      <extra-loc-engineeringenglish>Deactivate</extra-loc-engineeringenglish>
      <source>Deactivate655</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Απενεργοπ.">Απενεργοπ.</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>403</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_define" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to define a value.</comment>
      <extra-loc-engineeringenglish>Define</extra-loc-engineeringenglish>
      <source>Define656</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ορισμός">Ορισμός</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_delete" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the dialog. Allows the user to delete an item. Note that deleting removes the item permanently from memory.</comment>
      <extra-loc-engineeringenglish>Delete</extra-loc-engineeringenglish>
      <source>Delete657</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Διαγραφή">Διαγραφή</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_softkey_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_softkey_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>77</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_delete_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to delete an item. Note that deleting removes the item permanently from memory.</comment>
      <extra-loc-engineeringenglish>Delete</extra-loc-engineeringenglish>
      <source>Delete658</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">el #Delete</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_details" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. With this command the user can view the details of the selected item.</comment>
      <extra-loc-engineeringenglish>Details</extra-loc-engineeringenglish>
      <source>Details659</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Στοιχεία">Στοιχεία</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>79</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_disable" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to disable the selected item or function.</comment>
      <extra-loc-engineeringenglish>Disable</extra-loc-engineeringenglish>
      <source>Disable660</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Απενεργοπ.">Απενεργοπ.</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_disconnect" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to disconnect from an existing connection.</comment>
      <extra-loc-engineeringenglish>Disconnect</extra-loc-engineeringenglish>
      <source>Disconnect661</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Αποσύνδεση">Αποσύνδεση</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_edit" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to edit an item, for example a filename or a message.</comment>
      <extra-loc-engineeringenglish>Edit</extra-loc-engineeringenglish>
      <source>Edit662</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Επεξεργασία">Επεξεργασία</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>88</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_enable" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to enable the selected item or function.</comment>
      <extra-loc-engineeringenglish>Enable</extra-loc-engineeringenglish>
      <source>Enable663</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ενεργοποίηση">Ενεργοποίηση</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_exit" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. With the exit button, the user can close the currently active application and return to the Home screen.</comment>
      <extra-loc-engineeringenglish>Exit</extra-loc-engineeringenglish>
      <source>Exit664</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Έξοδος">Έξοδος</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>97</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_expand" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to for example expand a collapsed sorted list.</comment>
      <extra-loc-engineeringenglish>Expand</extra-loc-engineeringenglish>
      <source>Expand665</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ανάπτυξη">Ανάπτυξη</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_find" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to begin a search in the current application or view.</comment>
      <extra-loc-engineeringenglish>Find</extra-loc-engineeringenglish>
      <source>Find666</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Εύρεση">Εύρεση</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>101</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_finish" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. This button allows the user to finish the operation, for example to confirm and save changed settings.</comment>
      <extra-loc-engineeringenglish>Finish</extra-loc-engineeringenglish>
      <source>Finish667</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Τέλος">Τέλος</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_handset" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to change the audio (music, a call) from e.g. a loudspeaker to the handset.</comment>
      <extra-loc-engineeringenglish>Handset</extra-loc-engineeringenglish>
      <source>Activate handset668</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ενεργοπ. ακουστικού">Ενεργοπ. ακουστικού</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>542,NOT_121,490</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_help" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to open Help.</comment>
      <extra-loc-engineeringenglish>Help</extra-loc-engineeringenglish>
      <source>User guide669</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Οδηγίες χρήσης">Οδηγίες χρήσης</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>758</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_hide" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the dialog. Allows the user to hide an item.</comment>
      <extra-loc-engineeringenglish>Hide</extra-loc-engineeringenglish>
      <source>Hide670</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Απόκρυψη">Απόκρυψη</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_softkey_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_softkey_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_hide_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to hide an item.</comment>
      <extra-loc-engineeringenglish>Hide</extra-loc-engineeringenglish>
      <source>Hide671</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">el #Hide</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_insert" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to insert an item. This can be used for example for inserting a file into a presentation.</comment>
      <extra-loc-engineeringenglish>Insert</extra-loc-engineeringenglish>
      <source>Insert672</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Εισαγωγή">Εισαγωγή</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>143</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_install" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to install a file or files.</comment>
      <extra-loc-engineeringenglish>Install</extra-loc-engineeringenglish>
      <source>Install673</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Εγκατάσταση">Εγκατάσταση</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_join" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to join the selected chat group.</comment>
      <extra-loc-engineeringenglish>Join</extra-loc-engineeringenglish>
      <source>Join674</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Συμμετοχή">Συμμετοχή</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_listen" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to listen to for example messages in voice mailbox.</comment>
      <extra-loc-engineeringenglish>Listen</extra-loc-engineeringenglish>
      <source>Listen675</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ακρόαση">Ακρόαση</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_loudspeaker_off" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to turn the loudspeaker off.</comment>
      <extra-loc-engineeringenglish>Loudsp. off</extra-loc-engineeringenglish>
      <source>Loudspeaker off676</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Απενεργοπ. μεγαφώνου">Απενεργοπ. μεγαφώνου</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>161</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_loudspeaker_on" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to turn the loudspeaker on.</comment>
      <extra-loc-engineeringenglish>Loudsp. on</extra-loc-engineeringenglish>
      <source>Loudspeaker on677</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ενεργοπ. μεγαφώνου">Ενεργοπ. μεγαφώνου</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>161</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_mark" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to mark an item for further action. For example selecting file to be sent or deleting it.</comment>
      <extra-loc-engineeringenglish>Mark</extra-loc-engineeringenglish>
      <source>Mark678</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Επιλογή">Επιλογή</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>167</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_menu" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to open a menu.</comment>
      <extra-loc-engineeringenglish>Menu</extra-loc-engineeringenglish>
      <source>Menu679</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Μενού">Μενού</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>175</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_move" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to move the selected item.</comment>
      <extra-loc-engineeringenglish>Move</extra-loc-engineeringenglish>
      <source>Move680</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Μετακίνηση">Μετακίνηση</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>184</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_mute" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to mute the phone's microphones.</comment>
      <extra-loc-engineeringenglish>Mute</extra-loc-engineeringenglish>
      <source>Mute681</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Σίγαση">Σίγαση</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_no" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the dialog. Pressing this button rejects the selected operation.</comment>
      <extra-loc-engineeringenglish>No</extra-loc-engineeringenglish>
      <source>No682</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Όχι">Όχι</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_softkey_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_softkey_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_no_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Pressing this button rejects the selected operation.</comment>
      <extra-loc-engineeringenglish>No</extra-loc-engineeringenglish>
      <source>No683</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">el #No</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_ok" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the dialog. When this button is pressed, the focused item or operation will be selected or accepted.</comment>
      <extra-loc-engineeringenglish>OK</extra-loc-engineeringenglish>
      <source>OK684</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Εντάξει">Εντάξει</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_softkey_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_softkey_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>208</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_ok_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. When this button is pressed, the focused item or operation will be selected or accepted.</comment>
      <extra-loc-engineeringenglish>OK</extra-loc-engineeringenglish>
      <source>OK685</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">el #OK</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_open" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to open the selected item; for example, a file.</comment>
      <extra-loc-engineeringenglish>Open</extra-loc-engineeringenglish>
      <source>Open686</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Άνοιγμα">Άνοιγμα</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>210</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_options" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Pressing this button will open the options menu.</comment>
      <extra-loc-engineeringenglish>Options</extra-loc-engineeringenglish>
      <source>Options687</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Επιλογές">Επιλογές</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>211</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_paste" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to add the contents of clipboard to the selected place.</comment>
      <extra-loc-engineeringenglish>Paste</extra-loc-engineeringenglish>
      <source>Paste688</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Επικόλληση">Επικόλληση</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>723</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_pause" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to pause the current action. For example, pausing a song or a video.</comment>
      <extra-loc-engineeringenglish>Pause</extra-loc-engineeringenglish>
      <source>Pause689</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Παύση">Παύση</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_play_audio" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to play a music track or other audio.</comment>
      <extra-loc-engineeringenglish>Play</extra-loc-engineeringenglish>
      <source>Play690</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Αναπαρ.">Αναπαρ.</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_play_video" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to play video.</comment>
      <extra-loc-engineeringenglish>Play</extra-loc-engineeringenglish>
      <source>Play691</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Αναπαρ.">Αναπαρ.</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_preview_audio" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to preview the focused music track or other audio item.</comment>
      <extra-loc-engineeringenglish>Preview</extra-loc-engineeringenglish>
      <source>Preview692</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Προεπισκόπη­ση">Προεπισκόπη­ση</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_preview_video" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to preview the focused video item.</comment>
      <extra-loc-engineeringenglish>Preview</extra-loc-engineeringenglish>
      <source>Preview693</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Προεπισκόπη­ση">Προεπισκόπη­ση</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_quit" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Pressing this button will interrupt the current action and return to the previous state or view.</comment>
      <extra-loc-engineeringenglish>Quit</extra-loc-engineeringenglish>
      <source>Quit694</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Έξοδος">Έξοδος</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>545</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_read" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to read the message, e-mail etc.</comment>
      <extra-loc-engineeringenglish>Read</extra-loc-engineeringenglish>
      <source>Read695</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ανάγνωση">Ανάγνωση</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_record_audio" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to record audio (music, speech etc.).</comment>
      <extra-loc-engineeringenglish>Record</extra-loc-engineeringenglish>
      <source>Record696</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Εγγραφή">Εγγραφή</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_record_video" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to record video.</comment>
      <extra-loc-engineeringenglish>Record</extra-loc-engineeringenglish>
      <source>Record697</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Εγγραφή">Εγγραφή</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_reject" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the dialog. Allows the user to reject the suggested operation.</comment>
      <extra-loc-engineeringenglish>Reject</extra-loc-engineeringenglish>
      <source>Reject698</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Απόρριψη">Απόρριψη</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_softkey_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_softkey_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_263,404</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_reject_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to reject the suggested operation.</comment>
      <extra-loc-engineeringenglish>Reject</extra-loc-engineeringenglish>
      <source>Reject699</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">el #Reject</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_remove" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to remove the selected item (e.g. from a playlist). This does not permanently delete the item from memory.</comment>
      <extra-loc-engineeringenglish>Remove</extra-loc-engineeringenglish>
      <source>Remove700</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Αφαίρεση">Αφαίρεση</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>266</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_replace" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to replace text.</comment>
      <extra-loc-engineeringenglish>Replace</extra-loc-engineeringenglish>
      <source>Replace701</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Αντικατάστα­ση">Αντικατάστα­ση</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_reply" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to reply to a message (SMS, e-mail etc.)</comment>
      <extra-loc-engineeringenglish>Reply</extra-loc-engineeringenglish>
      <source>Reply702</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Απάντηση">Απάντηση</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_reset" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to reset a timer or clock.</comment>
      <extra-loc-engineeringenglish>Reset</extra-loc-engineeringenglish>
      <source>Reset703</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Μηδενισμός">Μηδενισμός</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_resume" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Pressing this button resumes the interrupted or paused operation.</comment>
      <extra-loc-engineeringenglish>Resume</extra-loc-engineeringenglish>
      <source>Resume704</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Συνέχιση">Συνέχιση</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_retry" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to try an interrupted or failed action or operation again.</comment>
      <extra-loc-engineeringenglish>Retry</extra-loc-engineeringenglish>
      <source>Retry705</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Επανάληψη">Επανάληψη</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_save" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to save e.g. a file or settings.</comment>
      <extra-loc-engineeringenglish>Save</extra-loc-engineeringenglish>
      <source>Save706</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Αποθήκευση">Αποθήκευση</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>273</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_select" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to select an item or option.</comment>
      <extra-loc-engineeringenglish>Select</extra-loc-engineeringenglish>
      <source>Select707</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Επιλογή">Επιλογή</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>280</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_send" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the dialog. Allows the user to send a message or an item.</comment>
      <extra-loc-engineeringenglish>Send</extra-loc-engineeringenglish>
      <source>Send708</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Αποστολή">Αποστολή</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_softkey_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_softkey_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>281</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_send_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to send a message or an item.</comment>
      <extra-loc-engineeringenglish>Send</extra-loc-engineeringenglish>
      <source>Send709</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">el #Send</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_settings" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Pressing this button opens Settings view.</comment>
      <extra-loc-engineeringenglish>Settings</extra-loc-engineeringenglish>
      <source>Settings710</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ρυθμίσεις">Ρυθμίσεις</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>290,NOT_291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_show" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Pressing this button shows a hidden item or items.</comment>
      <extra-loc-engineeringenglish>Show</extra-loc-engineeringenglish>
      <source>Show711</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Εμφάνιση">Εμφάνιση</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_start" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to start an operation.</comment>
      <extra-loc-engineeringenglish>Start</extra-loc-engineeringenglish>
      <source>Start712</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Έναρξη">Έναρξη</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>320</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_stop" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to stop an operation.</comment>
      <extra-loc-engineeringenglish>Stop</extra-loc-engineeringenglish>
      <source>Stop713</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Διακοπή">Διακοπή</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>324</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_uninstall" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to uninstall files or programs.</comment>
      <extra-loc-engineeringenglish>Uninstall</extra-loc-engineeringenglish>
      <source>Uninstall714</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Απεγκατάστα­ση">Απεγκατάστα­ση</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_unmark" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to unmark marked files.</comment>
      <extra-loc-engineeringenglish>Unmark</extra-loc-engineeringenglish>
      <source>Unmark715</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Εξαίρεση">Εξαίρεση</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>348</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_unmute" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to unmute a muted phone's microphones.</comment>
      <extra-loc-engineeringenglish>Unmute</extra-loc-engineeringenglish>
      <source>Unmute716</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Επαναφορά ήχου">Επαναφορά ήχου</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_yes" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the dialog. Pressing this button confirms the selected operation.</comment>
      <extra-loc-engineeringenglish>Yes</extra-loc-engineeringenglish>
      <source>Yes717</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ναι">Ναι</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_softkey_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_softkey_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>395</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_yes_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Pressing this button confirms the selected operation.</comment>
      <extra-loc-engineeringenglish>Yes</extra-loc-engineeringenglish>
      <source>Yes718</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">el #Yes</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_address" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter (work, home etc.) address.</comment>
      <extra-loc-engineeringenglish>Address:</extra-loc-engineeringenglish>
      <source>Address:719</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Διεύθυνση:">Διεύθυνση:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_384</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_bookmark_name" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter bookmark name.</comment>
      <extra-loc-engineeringenglish>Bookmark name:</extra-loc-engineeringenglish>
      <source>Bookmark name:720</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Όνομα σελιδοδείκτη:">Όνομα σελιδοδείκτη:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>39</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_current_password" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter current password.</comment>
      <extra-loc-engineeringenglish>Current password:</extra-loc-engineeringenglish>
      <source>Current password:721</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ισχύων κωδικός πρόσβασης:">Ισχύων κωδικός πρόσβασης:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>223</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_date" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter date.</comment>
      <extra-loc-engineeringenglish>Date:</extra-loc-engineeringenglish>
      <source>Date:722</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ημερομηνία:">Ημερομηνία:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_duration" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to duration.</comment>
      <extra-loc-engineeringenglish>Duration:</extra-loc-engineeringenglish>
      <source>Duration:723</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Διάρκεια:">Διάρκεια:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_end_date" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter end date.</comment>
      <extra-loc-engineeringenglish>End date:</extra-loc-engineeringenglish>
      <source>End date:724</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ημερομηνία λήξης:">Ημερομηνία λήξης:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_expires" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter expiration date and time.</comment>
      <extra-loc-engineeringenglish>Expires:</extra-loc-engineeringenglish>
      <source>Expires:725</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Λήξη:">Λήξη:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_file_name" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter file name.</comment>
      <extra-loc-engineeringenglish>File name:</extra-loc-engineeringenglish>
      <source>File name:726</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Όνομα αρχείου:">Όνομα αρχείου:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_first_name" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter last name (of a person).</comment>
      <extra-loc-engineeringenglish>Last name:</extra-loc-engineeringenglish>
      <source>Last name:727</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Επώνυμο:">Επώνυμο:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_folder_name" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter folder name.</comment>
      <extra-loc-engineeringenglish>Folder name:</extra-loc-engineeringenglish>
      <source>Folder name:728</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Όνομα φακέλου:">Όνομα φακέλου:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_from" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter the time from which something is on.</comment>
      <extra-loc-engineeringenglish>From:</extra-loc-engineeringenglish>
      <source>From:729</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Από: ">Από: </lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_from_name1" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter a person's (for instance a contact's) name.</comment>
      <extra-loc-engineeringenglish>Name:</extra-loc-engineeringenglish>
      <source>Name:730</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Όνομα:">Όνομα:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_from_name2" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter name of a file, folder, playlist etc.</comment>
      <extra-loc-engineeringenglish>Name:</extra-loc-engineeringenglish>
      <source>Name:731</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Όνομα:">Όνομα:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_new_name1" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter new name for a person (for instance a contact)</comment>
      <extra-loc-engineeringenglish>New name:</extra-loc-engineeringenglish>
      <source>New name:732</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Νέο όνομα:">Νέο όνομα:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_new_name2" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter new name for a file, folder, playlist etc.</comment>
      <extra-loc-engineeringenglish>New name:</extra-loc-engineeringenglish>
      <source>New name:733</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Νέο όνομα:">Νέο όνομα:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_new_password" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter a new password.</comment>
      <extra-loc-engineeringenglish>New password:</extra-loc-engineeringenglish>
      <source>New password:734</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Νέος κωδικός πρόσβασης:">Νέος κωδικός πρόσβασης:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>223</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_password" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter password.</comment>
      <extra-loc-engineeringenglish>Password:</extra-loc-engineeringenglish>
      <source>Password:735</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Κωδικός πρόσβασης:">Κωδικός πρόσβασης:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>223</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_phone_number" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter phone number.</comment>
      <extra-loc-engineeringenglish>Phone number:</extra-loc-engineeringenglish>
      <source>Phone number:736</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Αριθμός τηλεφώνου:">Αριθμός τηλεφώνου:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>228</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_time" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter time value (for instance for a timer).</comment>
      <extra-loc-engineeringenglish>Time:</extra-loc-engineeringenglish>
      <source>Time:737</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ώρα:">Ώρα:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_title" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter title for an e.g. album, music track or video.</comment>
      <extra-loc-engineeringenglish>Title:</extra-loc-engineeringenglish>
      <source>Title:738</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Τίτλος:">Τίτλος:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_to" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter the time until which something is on. </comment>
      <extra-loc-engineeringenglish>To:</extra-loc-engineeringenglish>
      <source>To:739</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Έως:">Έως:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_user_id" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter user ID.</comment>
      <extra-loc-engineeringenglish>User ID:</extra-loc-engineeringenglish>
      <source>User ID:740</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Αναγνωριστικό χρήστη:">Αναγνωριστικό χρήστη:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_user_name" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter user name.</comment>
      <extra-loc-engineeringenglish>User name:</extra-loc-engineeringenglish>
      <source>User name:741</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Όνομα χρήστη:">Όνομα χρήστη:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>356</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_web_address" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter web address.</comment>
      <extra-loc-engineeringenglish>Web address:</extra-loc-engineeringenglish>
      <source>Web address:742</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Διεύθυνση Ιστού:">Διεύθυνση Ιστού:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_383,384</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_advanced_settings" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Opens a view where the user can edit advanced settings.</comment>
      <extra-loc-engineeringenglish>Advanced settings</extra-loc-engineeringenglish>
      <source>Advanced settings743</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Προχωρημένες ρυθμ.">Προχωρημένες ρυθμ.</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>290,NOT_291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_fit_to_screen" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Image is sized to fit to the screen.</comment>
      <extra-loc-engineeringenglish>Fit to screen</extra-loc-engineeringenglish>
      <source>Fit to screen744</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Προσαρμ. στην οθόνη">Προσαρμ. στην οθόνη</translation>
      <oldsource>Fit to screen</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_save_to_contacts" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Saves the selected item to Contacts.</comment>
      <extra-loc-engineeringenglish>Save to Contacts</extra-loc-engineeringenglish>
      <source>Save to Contacts745</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Αποθήκ. στις Επαφές">Αποθήκ. στις Επαφές</translation>
      <oldsource>Save to Contacts</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_70,71,273</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_title_details" marked="false">
      <extracomment />
      <location />
      <comment>Heading. Note! Only use this text ID if there are no icons. For a details popup note.</comment>
      <extra-loc-engineeringenglish>Details:</extra-loc-engineeringenglish>
      <source>Details:746</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Στοιχεία:">Στοιχεία:</lengthvariant>
      </translation>
      <oldsource>Details:</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>79</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_title_select_address" marked="false">
      <extracomment />
      <location />
      <comment>Heading. Note! Only use this text ID if there are no icons. Allows user to select a (web, work, home etc.) address from the list below this heading.</comment>
      <extra-loc-engineeringenglish>Select address:</extra-loc-engineeringenglish>
      <source>Select address:747</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Επιλέξτε διεύθυνση:">Επιλέξτε διεύθυνση:</lengthvariant>
      </translation>
      <oldsource>Select address:</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>280,NOT_384</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_title_select_file" marked="false">
      <extracomment />
      <location />
      <comment>Heading. Note! Only use this text ID if there are no icons. Allows user to select a file from the list below this heading.</comment>
      <extra-loc-engineeringenglish>Select file:</extra-loc-engineeringenglish>
      <source>Select file:748</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Επιλέξτε αρχείο:">Επιλέξτε αρχείο:</lengthvariant>
      </translation>
      <oldsource>Select file:</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>280</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_title_select_folder" marked="false">
      <extracomment />
      <location />
      <comment>Heading. Note! Only use this text ID if there are no icons. Allows user to select a folder from the list below this heading.</comment>
      <extra-loc-engineeringenglish>Select folder:</extra-loc-engineeringenglish>
      <source>Select folder:749</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Επιλέξτε φάκελο:">Επιλέξτε φάκελο:</lengthvariant>
      </translation>
      <oldsource>Select folder:</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>280</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_title_select_language" marked="false">
      <extracomment />
      <location />
      <comment>Heading. Note! Only use this text ID if there are no icons. Allows user to select a language from the list below this heading.</comment>
      <extra-loc-engineeringenglish>Select language:</extra-loc-engineeringenglish>
      <source>Select language:750</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Επιλέξτε γλώσσα:">Επιλέξτε γλώσσα:</lengthvariant>
      </translation>
      <oldsource>Select language:</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>280</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_title_select_memory" marked="false">
      <extracomment />
      <location />
      <comment>Heading. Note! Only use this text ID if there are no icons. Allows user to select a memory to be used for a particular operation (phone memory, memory card etc.)</comment>
      <extra-loc-engineeringenglish>Select memory:</extra-loc-engineeringenglish>
      <source>Select memory:751</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Επιλέξτε μνήμη:">Επιλέξτε μνήμη:</lengthvariant>
      </translation>
      <oldsource>Select memory:</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_173,280</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_title_select_tone1" marked="false">
      <extracomment />
      <location />
      <comment>Heading. Note! Only use this text ID if there are no icons. Allows user to select a clock alarm tone from the list below this heading.</comment>
      <extra-loc-engineeringenglish>Select tone:</extra-loc-engineeringenglish>
      <source>Select tone:752</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Επιλέξτε ήχο:">Επιλέξτε ήχο:</lengthvariant>
      </translation>
      <oldsource>Select tone:</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_422,280</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_title_select_tone2" marked="false">
      <extracomment />
      <location />
      <comment>Heading. Note! Only use this text ID if there are no icons. Allows user to select a calendar alarm tone from the list below this heading.</comment>
      <extra-loc-engineeringenglish>Select tone:</extra-loc-engineeringenglish>
      <source>Select tone:753</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Επιλέξτε ήχο:">Επιλέξτε ήχο:</lengthvariant>
      </translation>
      <oldsource>Select tone:</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_422,280</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_title_select_tone3" marked="false">
      <extracomment />
      <location />
      <comment>Heading. Note! Only use this text ID if there are no icons. Allows user to select a ringing tone from the list below this heading.</comment>
      <extra-loc-engineeringenglish>Select tone:</extra-loc-engineeringenglish>
      <source>Select tone:754</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Επιλέξτε ήχο:">Επιλέξτε ήχο:</lengthvariant>
      </translation>
      <oldsource>Select tone:</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>422,280</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_title_web_address" marked="false">
      <extracomment />
      <location />
      <comment>Heading. Note! Only use this text ID if there are no icons. Allows user to select a web address from the list below this heading.</comment>
      <extra-loc-engineeringenglish>Web address:</extra-loc-engineeringenglish>
      <source>Select web address:755</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Επιλέξτε δ/νση Ιστού:">Επιλέξτε δ/νση Ιστού:</lengthvariant>
      </translation>
      <oldsource>Select web address:</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>280,384</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_title_writing_language" marked="false">
      <extracomment />
      <location />
      <comment>Heading. Note! Only use this text ID if there are no icons. Allows user to select writing language from the list below this heading.</comment>
      <extra-loc-engineeringenglish>Writing language:</extra-loc-engineeringenglish>
      <source>Writing language:756</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Γλώσσα γραφής:">Γλώσσα γραφής:</lengthvariant>
      </translation>
      <oldsource>Writing language:</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>394</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
  </context>
</TS>