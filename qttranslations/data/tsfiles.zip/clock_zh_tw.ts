<?xml version="1.0" encoding="utf-8"?>
<TS xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" version="1.0" sourcelanguage="English-GB" language="zh_tw">
  <extra-loc-extended xsi:type="xsd:boolean">true</extra-loc-extended>
  <defaultcodec />
  <extra-loc-feature xsi:type="xsd:string">clock@dfsxx.01</extra-loc-feature>
  <extra-loc-style xsi:type="xsd:string">ts</extra-loc-style>
  <context>
    <name>Prophet</name>
    <message numerus="no" id="txt_clk_button_cityname_countryname" marked="false">
      <extracomment />
      <location />
      <comment>Tapping on this button opens City list to select city.</comment>
      <extra-loc-engineeringenglish>&lt;cityname, countryname&gt;</extra-loc-engineeringenglish>
      <source>Select city176</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="選取城市">選取城市</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>280</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_button_date" marked="false">
      <extracomment />
      <location />
      <comment>Tapping on this button opens date picker as a popup to edit time</comment>
      <extra-loc-engineeringenglish>&lt;date&gt;</extra-loc-engineeringenglish>
      <source>Select date177</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="選取日期">選取日期</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>280</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_button_regional_date_time_settings" marked="false">
      <extracomment />
      <location />
      <comment>Tapping on this button opens advanced date and time view</comment>
      <extra-loc-engineeringenglish>Regional date &amp; time settings</extra-loc-engineeringenglish>
      <source>Advanced settings178</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="進階設定">進階設定</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_groupbox_simple_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_groupbox_simple_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>290,NOT_291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_button_time" marked="false">
      <extracomment />
      <location />
      <comment>Tapping on this button opens time picker as a popup for editing the time</comment>
      <extra-loc-engineeringenglish>&lt;time&gt;</extra-loc-engineeringenglish>
      <source>Time179</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="時間">時間</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_caption_clock" marked="false">
      <extracomment />
      <location />
      <comment>Caption for Clock in Task switcher</comment>
      <extra-loc-engineeringenglish>Clock</extra-loc-engineeringenglish>
      <source>Clock180</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">zh_tw Clock</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>cell_tport_appsw_pane_t1</extra-loc-layout_id>
      <extra-loc-layout>cell_tport_appsw_pane_t1</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>61</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>caption</extra-loc-positionid>
      <extra-loc-viewid>Clock</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_formlabel_description" marked="false">
      <extracomment />
      <location />
      <comment>Label for Description in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Description</extra-loc-engineeringenglish>
      <source>Description181</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="內容說明">內容說明</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>formlabel_1</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_formlabel_place" marked="false">
      <extracomment />
      <location />
      <comment>5th label for Place in Clock settings view</comment>
      <extra-loc-engineeringenglish>Place:</extra-loc-engineeringenglish>
      <source>Location:182</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="位置：">位置：</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_heading_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_heading_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>543,NOT_544</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>formlabel_1</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_formlabel_time_format" marked="false">
      <extracomment />
      <location />
      <comment>Time format:</comment>
      <extra-loc-engineeringenglish>Time format:</extra-loc-engineeringenglish>
      <source>Time format:183</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="時間格式：">時間格式：</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_heading_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_heading_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_3</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_formlabel_val_alarm" marked="false">
      <extracomment />
      <location />
      <comment>Default value for Description label in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Alarm</extra-loc-engineeringenglish>
      <source>Alarm184</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="鬧鈴">鬧鈴</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_description_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_description_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_15,410</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>formlabel_1_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="yes" id="txt_clk_grid_lnln" marked="false">
      <extracomment />
      <location />
      <comment>When a city is added to the World Clock one line grid view in landscape mode, its relative time offset is displayed with respect to homecity.</comment>
      <extra-loc-engineeringenglish>&lt;-/+&gt;%Ln:%Ln</extra-loc-engineeringenglish>
      <source>&lt;-/+&gt;%Ln:%Ln185</source>
      <translation testresult="false" keep="false">
        <numerusform plurality="a" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="">zh_tw #&lt;-/+&gt;%Ln:%Ln</numerusform>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id />
      <extra-loc-layout />
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>1-line grid</extra-loc-positionid>
      <extra-loc-viewid>Clock_World clock_L05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_line_grid_cityname" marked="false">
      <extracomment />
      <location />
      <comment>When a city is added to the World Clock one line grid view in landscape mode, its name is displayed.</comment>
      <extra-loc-engineeringenglish>&lt;cityname&gt;</extra-loc-engineeringenglish>
      <source>Add city186</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="加入城市">加入城市</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>1-line grid</extra-loc-positionid>
      <extra-loc-viewid>Clock_World clock_L05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_line_grid_date" marked="false">
      <extracomment />
      <location />
      <comment>When a city is added to the World Clock one line grid view in landscape mode, its date is displayed</comment>
      <extra-loc-engineeringenglish>&lt;date&gt;</extra-loc-engineeringenglish>
      <source>Date187</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="日期">日期</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>1-line grid</extra-loc-positionid>
      <extra-loc-viewid>Clock_World clock_L05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_abidjan_cotedIvoire" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Abidjan, Cote d'Ivoire</extra-loc-engineeringenglish>
      <source>Abidjan, Côte d'Ivoire188</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="阿必尚，科特迪瓦">阿必尚，科特迪瓦</lengthvariant>
      </translation>
      <oldsource>Abidjan, Cote d'Ivoire</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_abu_dhabi_uae" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Abu Dhabi, United Arab Emirates</extra-loc-engineeringenglish>
      <source>Abu Dhabi, United Arab Emirates189</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="阿布達比，阿拉伯聯合大公國">阿布達比，阿拉伯聯合大公國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_abuja_nigeria" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Abuja, Nigeria</extra-loc-engineeringenglish>
      <source>Abuja, Nigeria190</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="阿布加，奈及利亞">阿布加，奈及利亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_accra_ghana" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Accra, Ghana</extra-loc-engineeringenglish>
      <source>Accra, Ghana191</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="阿克拉，迦納">阿克拉，迦納</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_acre_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Acre, Brazil</extra-loc-engineeringenglish>
      <source>Acre, Brazil192</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="阿克里，巴西">阿克里，巴西</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_adak_ak_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Adak, AK, United States of America</extra-loc-engineeringenglish>
      <source>Adak, AK, United States of America193</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="艾達克，AK，美國">艾達克，AK，美國</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Adak, AK, United States of America</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_adamstown_pitcairn_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Adamstown, Pitcairn Islands</extra-loc-engineeringenglish>
      <source>Adamstown, Pitcairn Islands194</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="亞當鎮，皮特克恩島">亞當鎮，皮特克恩島</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Adamstown, Pitcairn Islands</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_addis _ababa_ethiopia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Addis Ababa, Ethiopia</extra-loc-engineeringenglish>
      <source>Addis Ababa, Ethiopia195</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="阿迪斯阿貝巴，衣索比亞">阿迪斯阿貝巴，衣索比亞</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Addis Ababa, Ethiopia</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_adelaide_aus" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Adelaide, Australia</extra-loc-engineeringenglish>
      <source>Adelaide, Australia196</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="阿得雷德，澳大利亞">阿得雷德，澳大利亞</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Adelaide, Australia</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_agana, guam" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Agana, Guam</extra-loc-engineeringenglish>
      <source>Agana, Guam197</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="阿加納，關島">阿加納，關島</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Agana, Guam</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_aktau_kaz" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Aktau, Kazakhstan</extra-loc-engineeringenglish>
      <source>Aktau, Kazakhstan198</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="阿克陶，哈薩克">阿克陶，哈薩克</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Aktau, Kazakhstan</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_albuquerque_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Albuquerque, United States of America</extra-loc-engineeringenglish>
      <source>Albuquerque, United States of America199</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="阿布奎基，美國">阿布奎基，美國</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Albuquerque, United States of America</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_algiers_algeria" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Algiers, Algeria</extra-loc-engineeringenglish>
      <source>Algiers, Algeria200</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="阿爾及爾，阿爾及利亞">阿爾及爾，阿爾及利亞</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Algiers, Algeria</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_alofi_niue" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Alofi, Niue</extra-loc-engineeringenglish>
      <source>Alofi, Niue201</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="亞羅菲，紐威">亞羅菲，紐威</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Alofi, Niue</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_amman_jordan" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Amman, Jordan</extra-loc-engineeringenglish>
      <source>Amman, Jordan202</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="安曼，約旦">安曼，約旦</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Amman, Jordan</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_amsterdam_netherlands" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Amsterdam, Netherlands</extra-loc-engineeringenglish>
      <source>Amsterdam, Netherlands203</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="阿姆斯特丹，荷蘭">阿姆斯特丹，荷蘭</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Amsterdam, Netherlands</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_anadyr_russia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Anadyr, Russia</extra-loc-engineeringenglish>
      <source>Anadyr, Russia204</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="阿納德爾，俄羅斯">阿納德爾，俄羅斯</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Anadyr, Russia</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_andorra_la_vella_andorra" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Andorra La Vella, Andorra</extra-loc-engineeringenglish>
      <source>Andorra La Vella, Andorra205</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="安道爾市，安道爾">安道爾市，安道爾</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Andorra La Vella, Andorra</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_ankara_turkey" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Ankara, Turkey</extra-loc-engineeringenglish>
      <source>Ankara, Turkey206</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="安卡拉，土耳其">安卡拉，土耳其</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Ankara, TurkeyAnkara, Turkey</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_antananarivo_madagascar" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Antananarivo, Madagascar</extra-loc-engineeringenglish>
      <source>Antananarivo, Madagascar207</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="安塔那利佛，馬達加斯加">安塔那利佛，馬達加斯加</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_apia samoa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Apia, Samoa</extra-loc-engineeringenglish>
      <source>Apia, Samoa208</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="阿比亞，薩摩亞">阿比亞，薩摩亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_aracaju_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Aracaju, Brazil</extra-loc-engineeringenglish>
      <source>Aracaju, Brazil209</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="阿拉卡茹，巴西">阿拉卡茹，巴西</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_araguaina_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Araguaina, Brazil</extra-loc-engineeringenglish>
      <source>Araguaina, Brazil210</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="阿拉瓜依納，巴西">阿拉瓜依納，巴西</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_ashgabat_turkmenistan" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Ashgabat, Turkmenistan</extra-loc-engineeringenglish>
      <source>Ashgabat, Turkmenistan211</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="阿什哈巴德，土庫曼">阿什哈巴德，土庫曼</lengthvariant>
      </translation>
      <oldsource>Ashgabat. Turkmenistan</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_asmara_eritrea" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Asmara, Eritrea</extra-loc-engineeringenglish>
      <source>Asmara, Eritrea212</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="阿斯馬拉，厄立特利亞">阿斯馬拉，厄立特利亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_astana_kaz" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Astana, Kazakhstan</extra-loc-engineeringenglish>
      <source>Astana, Kazakhstan213</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="阿斯坦納，哈薩克">阿斯坦納，哈薩克</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_asuncion_paraguay" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Asuncion, Paraguay</extra-loc-engineeringenglish>
      <source>Asunción, Paraguay214</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="亞松森，巴拉圭">亞松森，巴拉圭</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_atikokan_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Atikokan, Canada</extra-loc-engineeringenglish>
      <source>Atikokan, Canada215</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="阿蒂科卡恩，加拿大">阿蒂科卡恩，加拿大</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_atlanta_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Atlanta, United States of America</extra-loc-engineeringenglish>
      <source>Atlanta, GA, United States of America216</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="亞特蘭大，GA，美國">亞特蘭大，GA，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_auckland_nz" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Auckland, Newzealand</extra-loc-engineeringenglish>
      <source>Auckland, New Zealand217</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="奧克蘭，紐西蘭">奧克蘭，紐西蘭</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_augusta_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Augusta, United States of America</extra-loc-engineeringenglish>
      <source>Augusta, ME, United States of America218</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="奧古斯塔，ME，美國">奧古斯塔，ME，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_avarua_cook_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Avarua, Cook Islands</extra-loc-engineeringenglish>
      <source>Avarua, Cook Islands219</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="阿瓦魯阿，庫克群島">阿瓦魯阿，庫克群島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_baghdad_iraq" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Baghdad, Iraq</extra-loc-engineeringenglish>
      <source>Baghdad, Iraq220</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="巴格達，伊拉克">巴格達，伊拉克</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_baku_azerb" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Baku, Azerbaijan</extra-loc-engineeringenglish>
      <source>Baku, Azerbaijan221</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="巴庫，亞塞拜然">巴庫，亞塞拜然</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_baltimore_md_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Baltimore, MD, United States of America</extra-loc-engineeringenglish>
      <source>Baltimore, MD, United States of America222</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="巴爾的摩，MD，美國">巴爾的摩，MD，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_bamako_mali" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Bamako, Mali</extra-loc-engineeringenglish>
      <source>Bamako, Mali223</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="巴馬科，馬利">巴馬科，馬利</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_bandar_seri_begawan_brunei" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Bandar Seri Begawan, Brunei</extra-loc-engineeringenglish>
      <source>Bandar Seri Begawan, Brunei224</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="斯里巴卡旺，汶萊">斯里巴卡旺，汶萊</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_bangkok_thai" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Bangkok, Thailand</extra-loc-engineeringenglish>
      <source>Bangkok, Thailand225</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="曼谷，泰國">曼谷，泰國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_bangui_car" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Bangui, Central African Republic</extra-loc-engineeringenglish>
      <source>Bangul, Central African Republic226</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="班基，中非共和國">班基，中非共和國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_banjul_gambia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Banjul, Gambia</extra-loc-engineeringenglish>
      <source>Banjul, Gambia227</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="斑竹，甘比亞">斑竹，甘比亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_basse_terre_guadeloupe" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Basse-Terre, Guadeloupe</extra-loc-engineeringenglish>
      <source>Basse-Terre, Guadeloupe228</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="巴士地，瓜德魯普">巴士地，瓜德魯普</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_beijing_china" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Beijing, China</extra-loc-engineeringenglish>
      <source>Beijing, China229</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="北京，中國">北京，中國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_beirut_lebanon" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Beirut, Lebanon</extra-loc-engineeringenglish>
      <source>Beirut, Lebanon230</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="貝魯特，黎巴嫩">貝魯特，黎巴嫩</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_belem_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Belem, Brazil</extra-loc-engineeringenglish>
      <source>Belem, Brazil231</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="貝倫，巴西">貝倫，巴西</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_belfast_ireland" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Belfast, Ireland</extra-loc-engineeringenglish>
      <source>Belfast, Northern Ireland232</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="貝爾法斯特，愛爾蘭">貝爾法斯特，愛爾蘭</lengthvariant>
      </translation>
      <oldsource>Belfast, Ireland</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_belgrade_serbia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Belgrade, Serbia</extra-loc-engineeringenglish>
      <source>Belgrade, Serbia233</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="貝爾格萊德，塞爾維亞">貝爾格萊德，塞爾維亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_belmopan_belize" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Belmopan, Belize</extra-loc-engineeringenglish>
      <source>Belmopan, Belize234</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="貝爾墨邦，貝里斯">貝爾墨邦，貝里斯</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_belo_horizonte_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Belo Horizonte, Brazil</extra-loc-engineeringenglish>
      <source>Belo Horizonte, Brazil235</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="貝洛奧里藏特，巴西">貝洛奧里藏特，巴西</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_berlin_germany" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Berlin, Germany</extra-loc-engineeringenglish>
      <source>Berlin, Germany236</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="柏林，德國">柏林，德國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_bern_switz" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Bern, Switzerland</extra-loc-engineeringenglish>
      <source>Bern, Switzerland237</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="伯恩，瑞士">伯恩，瑞士</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_billings_mt_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Billings, MT, United States of America</extra-loc-engineeringenglish>
      <source>Billings, MT, United States of America238</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="比林斯，MT，美國">比林斯，MT，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_birmingham_al_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Birmingham, AL, United States of America</extra-loc-engineeringenglish>
      <source>Birmingham, AL, United States of America239</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="伯明罕，AL，美國">伯明罕，AL，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_bishkek_kyrgyzstan" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Bishkek, Kyrgyzstan</extra-loc-engineeringenglish>
      <source>Bishkek, Kyrgyzstan240</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="畢斯凱，吉爾吉斯">畢斯凱，吉爾吉斯</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_bismarck_nd_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Bismarck, ND, United States of America</extra-loc-engineeringenglish>
      <source>Bismarck, ND, United States of America241</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="俾斯麥，ND，美國">俾斯麥，ND，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_bissau_guinea_bissau" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Bissau, Guinea-Bissau</extra-loc-engineeringenglish>
      <source>Bissau, Guinea-Bissau242</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="比索，幾內亞比索">比索，幾內亞比索</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_blanc_sablon_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Blanc-Sablon, Canada</extra-loc-engineeringenglish>
      <source>Blanc-Sablon, Canada243</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="白朗薩布隆，加拿大">白朗薩布隆，加拿大</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_boa_vista_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Boa Vista, Brazil</extra-loc-engineeringenglish>
      <source>Boa Vista, Brazil244</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="保維斯塔，巴西">保維斯塔，巴西</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_bogota_colombia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Bogota, Colombia</extra-loc-engineeringenglish>
      <source>Bogotá, Colombia245</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="波哥大，哥倫比亞">波哥大，哥倫比亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_boise_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Boise, United States of America</extra-loc-engineeringenglish>
      <source>Boise, ID, United States of America246</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="樹城，ID，美國">樹城，ID，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_boston_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Boston, United States of America</extra-loc-engineeringenglish>
      <source>Boston, MA, Untied States of America247</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="波士頓，MA，美國">波士頓，MA，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_brasilia_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Brasilia, Brazil</extra-loc-engineeringenglish>
      <source>Brasilia, Brazil248</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="巴西利亞，巴西">巴西利亞，巴西</lengthvariant>
      </translation>
      <oldsource>Brasilia. Brazil</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_bratislava_slovakia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Bratislava, Slovakia</extra-loc-engineeringenglish>
      <source>Bratislava, Slovakia249</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="布拉提斯拉瓦，斯洛伐克">布拉提斯拉瓦，斯洛伐克</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_brazzaville_drc" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Brazzaville, Democratic Republic of the Congo</extra-loc-engineeringenglish>
      <source>Brazzaville, Congo, Republic of the250</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="布拉薩市, 剛果共和國">布拉薩市, 剛果共和國</lengthvariant>
      </translation>
      <oldsource>Brazzaville, Congo, Democratic Republic of the</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_bridgetown_barbados" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Bridgetown, Barbados</extra-loc-engineeringenglish>
      <source>Bridgetown, Barbados251</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="橋鎮，巴貝多">橋鎮，巴貝多</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_brisbane_aus" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Brisbane, Australia</extra-loc-engineeringenglish>
      <source>Brisbane, Australia252</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="布里斯本，澳大利亞">布里斯本，澳大利亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_brussels_belgium" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Brussels, Belgium</extra-loc-engineeringenglish>
      <source>Brussels, Belgium253</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="布魯塞爾，比利時">布魯塞爾，比利時</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_bucharest_romania" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Bucharest, Romania</extra-loc-engineeringenglish>
      <source>Bucharest, Romania254</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="布加勒斯特，羅馬尼亞">布加勒斯特，羅馬尼亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_budapest_hungary" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Budapest, Hungary</extra-loc-engineeringenglish>
      <source>Budapest, Hungary255</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="布達佩斯，匈牙利">布達佩斯，匈牙利</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_buenos_aires_argen" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Buenos Aires, Argentina</extra-loc-engineeringenglish>
      <source>Buenos Aires, Argentina256</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="布宜諾斯艾利斯，阿根廷">布宜諾斯艾利斯，阿根廷</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_bujumbura_burundi" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Bujumbura, Burundi</extra-loc-engineeringenglish>
      <source>Bujumbura, Burundi257</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="布松布拉，浦隆地">布松布拉，浦隆地</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_cairo_egypt" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Cairo, Egypt</extra-loc-engineeringenglish>
      <source>Cairo, Egypt258</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="開羅，埃及">開羅，埃及</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_calgary_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Calgary, Canada</extra-loc-engineeringenglish>
      <source>Calgary, Canada259</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="卡加利，加拿大">卡加利，加拿大</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_cambridge_bay_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Cambridge Bay, Canada</extra-loc-engineeringenglish>
      <source>Cambridge Bay, Canada260</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="劍橋灣，加拿大">劍橋灣，加拿大</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_campo_grande_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Campo Grande, Brazil</extra-loc-engineeringenglish>
      <source>Campo Grande, Brazil261</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="大坎普，巴西">大坎普，巴西</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_canberra_aus" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Canberra, Australia</extra-loc-engineeringenglish>
      <source>Canberra, Australia262</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="坎培拉，澳大利亞">坎培拉，澳大利亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_caracas_venezuela" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Caracas, Venezuela</extra-loc-engineeringenglish>
      <source>Caracas, Venezuela263</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="卡拉卡斯，委內瑞拉">卡拉卡斯，委內瑞拉</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_cardiff_uk" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Cardiff, United Kingdom</extra-loc-engineeringenglish>
      <source>Cardiff, United Kingdom264</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="卡地夫，英國">卡地夫，英國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_casablanca_morocco" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Casablanca, Morocco</extra-loc-engineeringenglish>
      <source>Casablanca, Morocco265</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="卡薩布蘭卡，摩洛哥">卡薩布蘭卡，摩洛哥</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_castries_st_lucia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Castries, St. Lucia</extra-loc-engineeringenglish>
      <source>Castries, St. Lucia266</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="卡斯翠，聖露西亞">卡斯翠，聖露西亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_cayenne_french_guiana" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Cayenne, French Guiana</extra-loc-engineeringenglish>
      <source>Cayenne, French Guiana267</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="開雲，法屬圭亞那">開雲，法屬圭亞那</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_charleston_wv_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Charleston, WV, United States of America</extra-loc-engineeringenglish>
      <source>Charleston, WV, United States of America268</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="查理斯敦，WV，美國">查理斯敦，WV，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_charlotte_amalie_vi_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Charlotte Amalie, VI, United States of America</extra-loc-engineeringenglish>
      <source>Charlotte Amalie, VI, United States of America269</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="沙洛阿馬略，VI，美國">沙洛阿馬略，VI，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_charlotte_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Charlotte, United States of America</extra-loc-engineeringenglish>
      <source>Charlotte, NC, United States of America270</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="夏洛特，NC，美國">夏洛特，NC，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_charlottetown_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Charlottetown, Canada</extra-loc-engineeringenglish>
      <source>Charlottetown, Canada271</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="沙洛鎮，加拿大">沙洛鎮，加拿大</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_chatham_newz" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Chatham, Newzealand</extra-loc-engineeringenglish>
      <source>Chatham, New Zealand272</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="查塔姆，紐西蘭">查塔姆，紐西蘭</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_chennai_india" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Chennai, India</extra-loc-engineeringenglish>
      <source>Chennai, India273</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="清奈，印度">清奈，印度</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_cheyenne_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Cheyenne, United States of America</extra-loc-engineeringenglish>
      <source>Cheyenne, WY, United States of America274</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="夏延，WY，美國">夏延，WY，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_chicago_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Chicago, United States of America</extra-loc-engineeringenglish>
      <source>Chicago, IL, United States of America275</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="芝加哥，IL，美國">芝加哥，IL，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_chihuahua_mexico" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Chihuahua, Mexico</extra-loc-engineeringenglish>
      <source>Chihuahua, Mexico276</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="奇瓦瓦，墨西哥">奇瓦瓦，墨西哥</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_chisinau_moldova" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Chisinau, Moldova</extra-loc-engineeringenglish>
      <source>Chisinau, Moldova277</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="基希納烏，摩爾多瓦">基希納烏，摩爾多瓦</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_choibalsan_mongolia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Choibalsan, Mongolia</extra-loc-engineeringenglish>
      <source>Choybalsan, Mongolia278</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="喬巴山，蒙古">喬巴山，蒙古</lengthvariant>
      </translation>
      <oldsource>Choybalsan, Mongolia&lt;TR-PLACEHOLDER&gt;</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_city_name_country_name" marked="false">
      <extracomment />
      <location />
      <comment>After user adds a city to the World clock list view, the city name and country name is displayed.</comment>
      <extra-loc-engineeringenglish>&lt;city name, country name&gt;</extra-loc-engineeringenglish>
      <source>Add city279</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="加入城市">加入城市</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_World clock_P05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_cockburn_town_turks_and_caicos_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Cockburn Town, </extra-loc-engineeringenglish>
      <source>Cockburn Town, Turks and Caicos Islands280</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="科伯恩城，特克斯和凱科斯群島">科伯恩城，特克斯和凱科斯群島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_colombo_srilanka" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Colombo, Srilanka</extra-loc-engineeringenglish>
      <source>Colombo, Sri Lanka281</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="可倫坡，斯里蘭卡">可倫坡，斯里蘭卡</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_colonia_micronesia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Colonia, Micronesia</extra-loc-engineeringenglish>
      <source>Colonia, Micronesia282</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="科隆尼亞，密克羅尼西亞">科隆尼亞，密克羅尼西亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_columbia_sc_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Columbia, SC, United States of America</extra-loc-engineeringenglish>
      <source>Columbia, SC, United States of America283</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="哥倫比亞，SC，美國">哥倫比亞，SC，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_columbus_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Columbus, United States of America</extra-loc-engineeringenglish>
      <source>Columbus, OH, United States of America284</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="哥倫布市，OH，美國">哥倫布市，OH，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_conakry_guinea" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Conakry, Guinea</extra-loc-engineeringenglish>
      <source>Conakry, Guinea285</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="柯那克里，幾內亞">柯那克里，幾內亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_concord_nh_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Concord, NH, United States of America</extra-loc-engineeringenglish>
      <source>Concord, NH, United States of America286</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="康科特，NH，美國">康科特，NH，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_copenhagen_denmark" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Copenhagen, Denmark</extra-loc-engineeringenglish>
      <source>Copenhagen, Denmark287</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="哥本哈根，丹麥">哥本哈根，丹麥</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_coral_harbour_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Coral Harbour, Canada</extra-loc-engineeringenglish>
      <source>Coral Harbour, Canada288</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="珊瑚港，加拿大">珊瑚港，加拿大</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_cranbrook_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Cranbrook, Canada</extra-loc-engineeringenglish>
      <source>Cranbrook, Canada289</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="克蘭布魯，加拿大">克蘭布魯，加拿大</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_creighton_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Creighton, Canada</extra-loc-engineeringenglish>
      <source>Creighton, Canada290</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="克萊頓，加拿大">克萊頓，加拿大</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_cuiaba_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Cuiaba, Brazil</extra-loc-engineeringenglish>
      <source>Cuiaba, Brazil291</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="古雅巴，巴西">古雅巴，巴西</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_curitiba_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Curitiba, Brazil</extra-loc-engineeringenglish>
      <source>Curitiba, Brazil292</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="古里提巴，巴西">古里提巴，巴西</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_dakar_senegal" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Dakar, Senegal</extra-loc-engineeringenglish>
      <source>Dakar, Senegal293</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="達卡，塞內加爾">達卡，塞內加爾</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_dallas_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Dallas, United States of America</extra-loc-engineeringenglish>
      <source>Dallas, TX, United States of America294</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="達拉斯，TX，美國">達拉斯，TX，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_damascus_syria" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Damascus, Syria</extra-loc-engineeringenglish>
      <source>Damascus, Syria295</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="大馬士革，敘利亞">大馬士革，敘利亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_danmarkshavn_greenland" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Danmarkshavn, Greenland</extra-loc-engineeringenglish>
      <source>Danmarkshavn, Greenland296</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="丹馬沙，格陵蘭">丹馬沙，格陵蘭</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_dar_es_salaam_tanzania" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Dar es Salaam, Tanzania</extra-loc-engineeringenglish>
      <source>Dar es Salaam, Tanzania297</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="達里斯薩蘭，坦尚尼亞">達里斯薩蘭，坦尚尼亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_darwin_aus" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Darwin, Australia</extra-loc-engineeringenglish>
      <source>Darwin, Australia298</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="達爾文，澳大利亞">達爾文，澳大利亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_date" marked="false">
      <extracomment />
      <location />
      <comment>When a city is added to the World Clock list view, the city's current date is displayed.</comment>
      <extra-loc-engineeringenglish>&lt;date&gt;</extra-loc-engineeringenglish>
      <source>Date299</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="日期">日期</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_World clock_P05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_dawson_creek_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Dawson Creek, Canada</extra-loc-engineeringenglish>
      <source>Dawson Creek, Canada300</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="道生克里克，加拿大">道生克里克，加拿大</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_denver_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Denver, United States of America</extra-loc-engineeringenglish>
      <source>Denver, CO, United States of America301</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="丹佛，CO，美國">丹佛，CO，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_des_moines_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Des Moines, United States of America</extra-loc-engineeringenglish>
      <source>Des Moines, IA, United States of America302</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="得梅因，IA，美國">得梅因，IA，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_detroit_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Detroit, United States of America</extra-loc-engineeringenglish>
      <source>Detroit, United States of America303</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="底特律，美國">底特律，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_dhaka_bangla" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Dhaka, Bangladesh</extra-loc-engineeringenglish>
      <source>Dhaka, Bangladesh304</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="達卡，孟加拉">達卡，孟加拉</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_diego_garcia_chagos_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Diego Garcia, Chagos Islands</extra-loc-engineeringenglish>
      <source>Diego Garcia, Chagos Archipelago305</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="地牙哥加西亞，查戈斯群島">地牙哥加西亞，查戈斯群島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_dili_east_timor" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Dili, East Timor</extra-loc-engineeringenglish>
      <source>Dili, East Timor306</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="狄力，東帝汶">狄力，東帝汶</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_djibouti_djibouti" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Djibouti, Djibouti</extra-loc-engineeringenglish>
      <source>Djibouti, Djibouti307</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="吉布地，吉布地">吉布地，吉布地</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_doha_qatar" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Doha, Qatar</extra-loc-engineeringenglish>
      <source>Doha, Qatar308</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="多哈，卡達">多哈，卡達</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_dover_de_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Dover, DE, United States of America</extra-loc-engineeringenglish>
      <source>Dover, DE, United States of America309</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="多佛，DE，美國">多佛，DE，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_dublin_ireland" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Dublin, Ireland</extra-loc-engineeringenglish>
      <source>Dublin, Ireland310</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="都柏林，愛爾蘭">都柏林，愛爾蘭</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_dushanbe_tajikistan" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Dushanbe, Tajikistan</extra-loc-engineeringenglish>
      <source>Dushanbe, Tajikistan311</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="杜尚貝，塔吉克">杜尚貝，塔吉克</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_edinburgh_uk" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Edinburgh, United Kingdom</extra-loc-engineeringenglish>
      <source>Edinburgh, United Kingdom312</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="愛丁堡，英國">愛丁堡，英國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_edmonton_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Edmonton, Canada</extra-loc-engineeringenglish>
      <source>Edmonton, Canada313</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="艾德蒙吞，加拿大">艾德蒙吞，加拿大</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_eucla_aus" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Eucla, Australia</extra-loc-engineeringenglish>
      <source>Eucla, Australia314</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="尤克拉，澳大利亞">尤克拉，澳大利亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_evansville_in_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Evansville, IN, United States of America</extra-loc-engineeringenglish>
      <source>Evansville, IN, United States of America315</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="艾凡士維，IN，美國">艾凡士維，IN，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_fakaofo_tokelau" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Fakaofo, Tokelau</extra-loc-engineeringenglish>
      <source>Fakaofo, Tokelau316</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="法克奧佛，托克勞群島">法克奧佛，托克勞群島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_fernando_de_noronha_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Fernando de Noronha, Brazil</extra-loc-engineeringenglish>
      <source>Fernando de Noronha, Brazil317</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="費南杜洛羅尼亞，巴西">費南杜洛羅尼亞，巴西</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_fort_de_france_martinique" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Fort-de-France, Martinique</extra-loc-engineeringenglish>
      <source>Fort-de-France, Martinique318</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="法蘭西堡，馬丁尼克">法蘭西堡，馬丁尼克</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_fortaleza_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Fortaleza, Brazil</extra-loc-engineeringenglish>
      <source>Fortaleza, Brazil319</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="福塔力沙，巴西">福塔力沙，巴西</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_freetown_sierra_leone" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Freetown, Sierra Leone</extra-loc-engineeringenglish>
      <source>Freetown, Sierra Leone320</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="自由城，獅子山">自由城，獅子山</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_funafuti_tuvalu" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Funafuti, Tuvalu</extra-loc-engineeringenglish>
      <source>Funafuti, Tuvalu321</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="富納富提，吐瓦魯">富納富提，吐瓦魯</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_funchal_madeira" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Funchal, Madeira</extra-loc-engineeringenglish>
      <source>Funchal, Madeira322</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="芳夏爾，馬迪拉">芳夏爾，馬迪拉</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_gaborone_botswana" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Gaborone, Botswana</extra-loc-engineeringenglish>
      <source>Gaborone, Botswana323</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="嘉柏隆里，波札那">嘉柏隆里，波札那</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_gambier_isl_french_polynesia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Gambier Islands, French Polynesia</extra-loc-engineeringenglish>
      <source>Gambier Islands, French Polynesia324</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="甘比爾群島，法屬玻里尼西亞">甘比爾群島，法屬玻里尼西亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_gary_in_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Gary, IN, United States of America</extra-loc-engineeringenglish>
      <source>Gary, IN, United States of America325</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="加利，IN，美國">加利，IN，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_george_town_cayman_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>George Town, Cayman Islands</extra-loc-engineeringenglish>
      <source>George Town, Cayman Islands326</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="喬治城，開曼群島">喬治城，開曼群島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_georgetown_guyana" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Georgetown, Guyana</extra-loc-engineeringenglish>
      <source>Georgetown, Guyana327</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="喬治城，蓋亞納">喬治城，蓋亞納</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_gibraltar_gibraltar" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Gibraltar, Gibraltar</extra-loc-engineeringenglish>
      <source>Gibraltar, Gibraltar328</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="直布羅陀，直布羅陀">直布羅陀，直布羅陀</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_goiania_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Goiania, Brazil</extra-loc-engineeringenglish>
      <source>Goiania, Brazil329</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="哥亞尼亞，巴西">哥亞尼亞，巴西</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_greece_athens" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Athens, Greece</extra-loc-engineeringenglish>
      <source>Athens, Greece330</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="雅典，希臘">雅典，希臘</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_grytviken_south_georgia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Grytviken, South Georgia</extra-loc-engineeringenglish>
      <source>Grytviken, South Georgia331</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="格力維肯港，南喬治亞">格力維肯港，南喬治亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_guam_mp_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Guam, MP, United States of America</extra-loc-engineeringenglish>
      <source>Guam, MP, United States of America332</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="關島，MP，美國">關島，MP，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_guatemala_guatemala" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Guatemala, Guatemala</extra-loc-engineeringenglish>
      <source>Guatemala, Guatemala333</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="瓜地馬拉，瓜地馬拉">瓜地馬拉，瓜地馬拉</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_hagatna_guam" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Hagatna, Guam</extra-loc-engineeringenglish>
      <source>Hagatna, Guam334</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="亞加納，關島">亞加納，關島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_halifax_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Halifax, Canada</extra-loc-engineeringenglish>
      <source>Halifax, Canada335</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="哈利法克斯，加拿大">哈利法克斯，加拿大</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_hamilton_bermuda" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Hamilton, Bermuda</extra-loc-engineeringenglish>
      <source>Hamilton, Bermuda336</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="漢米頓，百慕達">漢米頓，百慕達</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_hanga_roa_easter_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Hanga Roa, Easter Island</extra-loc-engineeringenglish>
      <source>Hanga Roa, Easter Island337</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="漢加羅亞，復活節島">漢加羅亞，復活節島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_hanoi_vietnam" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Hanoi, Vietnam</extra-loc-engineeringenglish>
      <source>Hanoi, Vietnam338</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="河內，越南">河內，越南</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_harare_zimbabwe" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Harare, Zimbabwe</extra-loc-engineeringenglish>
      <source>Harare, Zimbabwe339</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="哈拉雷，辛巴威">哈拉雷，辛巴威</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_hartford_ct_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Hartford, CT, United States of America</extra-loc-engineeringenglish>
      <source>Hartford, CT, United States of America340</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="哈特福，CT，美國">哈特福，CT，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_havana_cuba" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Havana, Cuba</extra-loc-engineeringenglish>
      <source>Havana, Cuba341</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="哈瓦納，古巴">哈瓦納，古巴</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_helsinki_finland" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Helsinki, Finland</extra-loc-engineeringenglish>
      <source>Helsinki, Finland342</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="赫爾辛基，芬蘭">赫爾辛基，芬蘭</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_hobart_aus" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Hobart, Australia</extra-loc-engineeringenglish>
      <source>Hobart, Australia343</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="霍伯特，澳大利亞">霍伯特，澳大利亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_holy_see_vatican_city" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Holy See, Vatican City</extra-loc-engineeringenglish>
      <source>Holy See, Vatican City344</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="教廷，梵蒂岡城">教廷，梵蒂岡城</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_hong_kong_victoria" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Hong kong, Victoria</extra-loc-engineeringenglish>
      <source>Hong Kong, Victoria345</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="香港特別行政區，維多利亞">香港特別行政區，維多利亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_honiara_solomon_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Honiara, Solomon Islands</extra-loc-engineeringenglish>
      <source>Honiara, Solomon Islands346</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="荷尼阿拉，所羅門群島">荷尼阿拉，所羅門群島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_honolulu_hi_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Honolulu, HI, United States of America</extra-loc-engineeringenglish>
      <source>Honolulu, HI, United States of America347</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="檀香山，HI，美國">檀香山，HI，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_hovd_mongolia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Hovd, Mongolia</extra-loc-engineeringenglish>
      <source>Hovd, Mongolia348</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="科布多，蒙古">科布多，蒙古</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_indianapolis_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Indianapolis, United States of America</extra-loc-engineeringenglish>
      <source>Indianapolis, IN, United States of America349</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="印地那波里，IN，美國">印地那波里，IN，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_iqaluit_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Iqaluit, Canada</extra-loc-engineeringenglish>
      <source>Iqaluit, Canada350</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="伊卡魯伊特，加拿大">伊卡魯伊特，加拿大</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_irkutsk_russia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Irkutsk, Russia</extra-loc-engineeringenglish>
      <source>Irkutsk, Russia351</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="伊爾庫次克，俄羅斯">伊爾庫次克，俄羅斯</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_islamabad_pak" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Islamabad, Pakistan</extra-loc-engineeringenglish>
      <source>Islamabad, Pakistan352</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="伊斯蘭馬巴德，巴基斯坦">伊斯蘭馬巴德，巴基斯坦</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_istanbul_turkey" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Istanbul, Turkey</extra-loc-engineeringenglish>
      <source>Istanbul, Turkey353</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="伊斯坦堡，土耳其">伊斯坦堡，土耳其</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_jakarta_indonesia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Jakarta, Indonesia</extra-loc-engineeringenglish>
      <source>Jakarta, Indonesia354</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="雅加達，印尼">雅加達，印尼</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_jamestown_st_helena" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Jamestown, St. Helena</extra-loc-engineeringenglish>
      <source>Jamestown, Saint Helena355</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="詹姆斯鎮，聖赫勒拿">詹姆斯鎮，聖赫勒拿</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_jayapura_indonesia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Jayapura, Indonesia</extra-loc-engineeringenglish>
      <source>Jayapura, Indonesia356</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="加亞布拉，印尼">加亞布拉，印尼</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_jerusalem_israel" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Jerusalem, Israel</extra-loc-engineeringenglish>
      <source>Jerusalem, Israel357</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="耶路撒冷，以色列">耶路撒冷，以色列</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_joao_pessoa_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Joao Pessoa, Brazil</extra-loc-engineeringenglish>
      <source>Joao Pessoa, Brazil358</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="川佩索 ，巴西">川佩索 ，巴西</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_johannesburg_safrica" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Johannesburg, South Africa</extra-loc-engineeringenglish>
      <source>Johannesburg, South Africa359</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="約翰尼斯堡，南非">約翰尼斯堡，南非</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_joinville_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Joinville, Brazil</extra-loc-engineeringenglish>
      <source>Joinville, Brazil360</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="壯維，巴西">壯維，巴西</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kabul_afghan" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kabul, Afghanistan</extra-loc-engineeringenglish>
      <source>Kabul, Afghanistan361</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="喀布爾，阿富汗">喀布爾，阿富汗</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kaliningrad_russia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kaliningrad, Russia</extra-loc-engineeringenglish>
      <source>Kaliningrad, Russia362</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="加里寧格勒，俄羅斯">加里寧格勒，俄羅斯</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kampala_uganda" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kampala, Uganda</extra-loc-engineeringenglish>
      <source>Kampala, Uganda363</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="坎帕拉，烏干達">坎帕拉，烏干達</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kanton_isl_phoenix_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kanton Island, Phoenix Islands</extra-loc-engineeringenglish>
      <source>Kanton Island, Phoenix Islands364</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="康頓島，費尼克斯群島">康頓島，費尼克斯群島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_karachi_pakistan" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Karachi, Pakistan</extra-loc-engineeringenglish>
      <source>Karachi, Pakistan365</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="喀拉蚩，巴基斯坦">喀拉蚩，巴基斯坦</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kathmandu_nepal" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kathmandu, Nepal</extra-loc-engineeringenglish>
      <source>Kathmandu, Nepal366</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="加德滿都，尼泊爾">加德滿都，尼泊爾</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_khartoum_sudan" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Khartoum, Sudan</extra-loc-engineeringenglish>
      <source>Khartoum, Sudan367</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="卡土穆，蘇丹">卡土穆，蘇丹</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kigali_rwanda" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kigali, Rwanda</extra-loc-engineeringenglish>
      <source>Kigali, Rwanda368</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="吉佳利，盧安達">吉佳利，盧安達</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kingston_jamaica" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kingston, Jamaica</extra-loc-engineeringenglish>
      <source>Kingston, Jamaica369</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="京斯敦，牙買加">京斯敦，牙買加</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kingston_norfolk_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kingston, Norfolk Island</extra-loc-engineeringenglish>
      <source>Kingston, Norfolk Island370</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="京斯敦，諾福克島">京斯敦，諾福克島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kingstown_st_vincent" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kingstown, St. Vincent</extra-loc-engineeringenglish>
      <source>Kingstown, Saint Vincent and Grenadines371</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="金斯敦，聖文森及格瑞那丁">金斯敦，聖文森及格瑞那丁</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kinshasa_drc" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kinshasa, Democratic Republic of the Congo</extra-loc-engineeringenglish>
      <source>Kinshasa, Congo, Democratic Republic of the372</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="金夏沙，剛果民主共和國">金夏沙，剛果民主共和國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kolkata_india" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kolkata, India</extra-loc-engineeringenglish>
      <source>Kolkata, India373</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="加爾各答，印度">加爾各答，印度</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_krasnoyarsk_russia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Krasnoyarsk, Russia</extra-loc-engineeringenglish>
      <source>Krasnoyarsk, Russia374</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="克拉斯諾亞斯克，俄羅斯">克拉斯諾亞斯克，俄羅斯</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kuala_lumpur_malaysia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kuala Lumpur, Malaysia</extra-loc-engineeringenglish>
      <source>Kuala Lumpur, Malaysia375</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="吉隆坡，馬來西亞">吉隆坡，馬來西亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kuwait_city_kuwait" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kuwait City, Kuwait</extra-loc-engineeringenglish>
      <source>Kuwait City, Kuwait376</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="科威特市，科威特">科威特市，科威特</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kyiv_ukraine" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kyiv, Ukraine</extra-loc-engineeringenglish>
      <source>Kyiv, Ukraine377</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="基輔，烏克蘭">基輔，烏克蘭</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_la_paz_bolivia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>La Paz, Bolivia</extra-loc-engineeringenglish>
      <source>La Paz, Bolivia378</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="拉帕斯，玻利維亞">拉帕斯，玻利維亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_laayoune_west_sahara" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Laayoune, Western Sahara</extra-loc-engineeringenglish>
      <source>Laayoune, Western Sahara379</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="阿尤恩，西撒哈拉">阿尤恩，西撒哈拉</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_las_palmas_canary_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Las Palmas, Canary Islands</extra-loc-engineeringenglish>
      <source>Las Palmas, Canary Islands380</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="拉斯帕爾馬斯，加那利群島">拉斯帕爾馬斯，加那利群島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_las_vegas_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Las Vegas, United States of America</extra-loc-engineeringenglish>
      <source>Las Vegas, NV, United States of America381</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="拉斯維加斯，NV，美國">拉斯維加斯，NV，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_libreville_gabon" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Libreville, Gabon</extra-loc-engineeringenglish>
      <source>Libreville, Gabon382</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="自由市，加彭">自由市，加彭</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_lilongwe_malawi" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Lilongwe, Malawi</extra-loc-engineeringenglish>
      <source>Lilongwe, Malawi383</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="里朗威，馬拉威">里朗威，馬拉威</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_lima_peru" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Lima, Peru</extra-loc-engineeringenglish>
      <source>Lima, Peru384</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="利馬，祕魯">利馬，祕魯</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_lisbon_portugal" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Lisbon, Portugal</extra-loc-engineeringenglish>
      <source>Lisbon, Portugal385</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="里斯本，葡萄牙">里斯本，葡萄牙</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_ljubljana_slovenia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Ljubljana, Slovenia</extra-loc-engineeringenglish>
      <source>Ljubljana, Slovenia386</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="盧布爾雅那，斯洛維尼亞">盧布爾雅那，斯洛維尼亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="yes" id="txt_clk_list_ln_hrsln_mins" marked="false">
      <extracomment />
      <location />
      <comment>When a city is added to the World Clock list view, its relative time offset is displayed with respect to Homecity.</comment>
      <extra-loc-engineeringenglish>&lt;+/-&gt;%Ln hrs,%Ln mins</extra-loc-engineeringenglish>
      <source>&lt;+/-&gt;%Ln hrs,%Ln mins387</source>
      <translation testresult="false" keep="false">
        <numerusform plurality="a" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="">zh_tw #&lt;+/-&gt;%Ln hrs,%Ln mins</numerusform>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id />
      <extra-loc-layout />
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_World clock_P05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_lomé_togo" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Lomé, Togo</extra-loc-engineeringenglish>
      <source>Lomé, Togo388</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="洛美，多哥">洛美，多哥</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_london_christmas_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>London, Christmas Island</extra-loc-engineeringenglish>
      <source>London, Christmas Island389</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="倫敦，聖誕島">倫敦，聖誕島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_london_uk" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>London, United Kingdom</extra-loc-engineeringenglish>
      <source>London, United Kingdom390</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="倫敦，英國">倫敦，英國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_lord_howe_isl_aus" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Lord Howe Island, Australia</extra-loc-engineeringenglish>
      <source>Lord Howe Island, Australia391</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="豪勛爵島，澳大利亞">豪勛爵島，澳大利亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_los_angeles_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Los Angeles, United States of America</extra-loc-engineeringenglish>
      <source>Los Angeles, CA, United States of America392</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="洛杉磯，CA，美國">洛杉磯，CA，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_louisville_ky_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Louisville, KY, United States of America</extra-loc-engineeringenglish>
      <source>Louisville, KY, United States of America393</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="路易斯維爾，KY，美國">路易斯維爾，KY，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_luanda_angola" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Luanda, Angola</extra-loc-engineeringenglish>
      <source>Luanda, Angola394</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="羅安達，安哥拉">羅安達，安哥拉</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_lubumbashi_drc" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Lubumbashi, Democratic Republic of the Congo</extra-loc-engineeringenglish>
      <source>Lubumbashi, Congo, Democratic Republic of the395</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="羅彭巴布，剛果民主共和國">羅彭巴布，剛果民主共和國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_lusaka_zambia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Lusaka, Zambia</extra-loc-engineeringenglish>
      <source>Lusaka, Zambia396</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="路沙卡，尚比亞">路沙卡，尚比亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_luxembourg_city_luxembourg" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Luxembourg City, Luxembourg</extra-loc-engineeringenglish>
      <source>Luxembourg, Luxembourg397</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="盧森堡，盧森堡">盧森堡，盧森堡</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_macapa_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Macapa, Brazil</extra-loc-engineeringenglish>
      <source>Macapa, Brazil398</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="馬卡帕，巴西">馬卡帕，巴西</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_macau_macau" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Macau, Macau</extra-loc-engineeringenglish>
      <source>Macau, Macau399</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="澳門，澳門特別行政區">澳門，澳門特別行政區</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_maceio_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Maceio, Brazil</extra-loc-engineeringenglish>
      <source>Maceio, Brazil400</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="馬瑟歐，巴西">馬瑟歐，巴西</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_madrid_spain" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Madrid, Spain</extra-loc-engineeringenglish>
      <source>Madrid, Spain401</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="馬德里，西班牙">馬德里，西班牙</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_magadan_russia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Magadan, Russia</extra-loc-engineeringenglish>
      <source>Magadan, Russia402</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="馬加丹，俄羅斯">馬加丹，俄羅斯</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_majuro_marshall_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Majuro, Marshall Islands</extra-loc-engineeringenglish>
      <source>Majuro, Marshall Islands403</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="馬久羅，馬紹爾群島">馬久羅，馬紹爾群島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_makassar_indonesia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Makassar, Indonesia</extra-loc-engineeringenglish>
      <source>Makassar, Indonesia404</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="錫江，印尼">錫江，印尼</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_malabo_eq_guinea" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Malabo, Equatorial Guinea</extra-loc-engineeringenglish>
      <source>Malabo, Equatorial Guinea405</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="馬拉博，赤道幾內亞">馬拉博，赤道幾內亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_male_maldives" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Male, Maldives</extra-loc-engineeringenglish>
      <source>Male, Maldives406</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="馬烈，馬爾地夫">馬烈，馬爾地夫</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_mamoudzou_mayotte" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Mamoudzou, Mayotte</extra-loc-engineeringenglish>
      <source>Mamoudzou, Mayotte407</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="馬慕索，馬約特">馬慕索，馬約特</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_managua_nicaragua" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Managua, Nicaragua</extra-loc-engineeringenglish>
      <source>Managua, Nicaragua408</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="馬那瓜，尼加拉瓜">馬那瓜，尼加拉瓜</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_manama_bahrain" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Manama, Bahrain</extra-loc-engineeringenglish>
      <source>Manama, Bahrain409</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="麥納瑪，巴林">麥納瑪，巴林</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_manaus_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Manaus, Brazil</extra-loc-engineeringenglish>
      <source>Manaus, Brazil410</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="瑪瑙斯，巴西">瑪瑙斯，巴西</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_manila_philippines" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Manila, Philippines</extra-loc-engineeringenglish>
      <source>Manila, Philippines411</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="馬尼拉，菲律賓">馬尼拉，菲律賓</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_maputo_mozambique" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Maputo, Mozambique</extra-loc-engineeringenglish>
      <source>Maputo, Mozambique412</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="馬布多，莫三比克">馬布多，莫三比克</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_maseru_lesotho" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Maseru, Lesotho</extra-loc-engineeringenglish>
      <source>Maseru, Lesotho413</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="馬塞魯，賴索托">馬塞魯，賴索托</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_mata_utu_wallis_futuna_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Mata_Utu, Wallis and Futuna Islands</extra-loc-engineeringenglish>
      <source>Mata-Utu, Wallis and Futuna Islands414</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="馬塔烏圖，瓦利斯及福杜納群島">馬塔烏圖，瓦利斯及福杜納群島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_mbabane_swaziland" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Mbabane, Swaziland</extra-loc-engineeringenglish>
      <source>Mbabane, Swaziland415</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="墨巴本，史瓦濟蘭">墨巴本，史瓦濟蘭</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_melbourne_aus" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Melbourne, Australia</extra-loc-engineeringenglish>
      <source>Melbourne, Australia416</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="墨爾本，澳大利亞">墨爾本，澳大利亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_melekeok_palau" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Melekeok, Palau</extra-loc-engineeringenglish>
      <source>Melekeok, Palau417</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="美力克州，帛琉">美力克州，帛琉</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_memphis_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Memphis, United States of America</extra-loc-engineeringenglish>
      <source>Memphis, TN, United States of America418</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="孟斐斯，TN，美國">孟斐斯，TN，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_mexico_city_mexico" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Mexico City, Mexico</extra-loc-engineeringenglish>
      <source>Mexico City, Mexico419</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="墨西哥市，墨西哥">墨西哥市，墨西哥</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_miami_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Miami, United States of America</extra-loc-engineeringenglish>
      <source>Miami, FL, United States of America420</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="邁阿密，FL，美國">邁阿密，FL，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_milwaukee_wi_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Milwaukee, WI, United States of America</extra-loc-engineeringenglish>
      <source>Milwaukee, WI, United States of America421</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="密爾瓦基，WI，美國">密爾瓦基，WI，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_minneapolis_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Minneapolis, United States of America</extra-loc-engineeringenglish>
      <source>Minneapolis, MN, United States of America422</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="明尼亞波里，MN，美國">明尼亞波里，MN，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_minsk_belarus" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Minsk, Belarus</extra-loc-engineeringenglish>
      <source>Minsk, Belarus423</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="明斯克，白俄羅斯">明斯克，白俄羅斯</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_mogadishu_somalia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Mogadishu, Somalia</extra-loc-engineeringenglish>
      <source>Mogadishu, Somalia424</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="摩加迪休，索馬利亞">摩加迪休，索馬利亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_monaco_monaco" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Monaco, Monaco</extra-loc-engineeringenglish>
      <source>Monaco, Monaco425</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="摩納哥，摩納哥">摩納哥，摩納哥</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_monrovia_liberia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Monrovia, Liberia</extra-loc-engineeringenglish>
      <source>Monrovia, Liberia426</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="蒙羅維亞，賴比瑞亞">蒙羅維亞，賴比瑞亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_montevideo_uruguay" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Montevideo, Uruguay</extra-loc-engineeringenglish>
      <source>Montevideo, Uruguay427</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="蒙特維多，烏拉圭">蒙特維多，烏拉圭</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_montpelier_vt_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Montpelier, VT, United States of America</extra-loc-engineeringenglish>
      <source>Montpelier, VT, United States of America428</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="蒙特佩利爾，VT，美國">蒙特佩利爾，VT，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_montreal_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Montreal, Canada</extra-loc-engineeringenglish>
      <source>Montreal, Canada429</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="蒙特婁，加拿大">蒙特婁，加拿大</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_moroni_comoros" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Moroni, Comoros</extra-loc-engineeringenglish>
      <source>Moroni, Comoros430</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="莫洛尼，葛摩">莫洛尼，葛摩</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_moscow_russia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Moscow, Russia</extra-loc-engineeringenglish>
      <source>Moscow, Russia431</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="莫斯科，俄羅斯">莫斯科，俄羅斯</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_mumbai_india" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Mumbai, India</extra-loc-engineeringenglish>
      <source>Mumbai, India432</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="孟買，印度">孟買，印度</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_muscat_oman" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Muscat, Oman</extra-loc-engineeringenglish>
      <source>Muscat, Oman433</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="慕斯卡，阿曼">慕斯卡，阿曼</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_nairobi_kenya" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Nairobi, Kenya</extra-loc-engineeringenglish>
      <source>Nairobi, Kenya434</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="奈若比，肯亞">奈若比，肯亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_nassau_bahamas" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Nassau, Bahamas</extra-loc-engineeringenglish>
      <source>Nassau, Bahamas435</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="拿索，巴哈馬">拿索，巴哈馬</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_new_delhi_india" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>New Delhi, India</extra-loc-engineeringenglish>
      <source>New Delhi, India436</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="新德里，印度">新德里，印度</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_new_orleans_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>New Orleans, United States of America</extra-loc-engineeringenglish>
      <source>New Orleans, LA, United States of America437</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="紐奧良，LA，美國">紐奧良，LA，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_new_york_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>New York, United States of America</extra-loc-engineeringenglish>
      <source>New York, NY, United States of America438</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="紐約，NY，美國">紐約，NY，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_niamey_niger" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Niamey, Niger</extra-loc-engineeringenglish>
      <source>Niamey, Niger439</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="尼阿美，尼日">尼阿美，尼日</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_nicosia_cyprus" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Nicosia, Cyprus</extra-loc-engineeringenglish>
      <source>Nicosia, Cyprus440</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="尼古西亞，賽普勒斯">尼古西亞，賽普勒斯</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_nouakchott_mauritania" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Nouakchott, Mauritania</extra-loc-engineeringenglish>
      <source>Nouakchott, Mauritania441</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="諾克少，茅利塔尼亞">諾克少，茅利塔尼亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_noumea_new_caledonia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Noumea, New Caledonia</extra-loc-engineeringenglish>
      <source>Noumea, New Caledonia442</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="諾美亞，新喀里多尼亞">諾美亞，新喀里多尼亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_novosibirsk_russia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Novosibirsk, Russia</extra-loc-engineeringenglish>
      <source>Novosibirsk, Russia443</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="新西伯利亞，俄羅斯">新西伯利亞，俄羅斯</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_nuku_alofa_tonga" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Nuku’alofa, Tonga</extra-loc-engineeringenglish>
      <source>Nuku’alofa, Tonga444</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="努庫阿洛法，東加">努庫阿洛法，東加</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_nuuk_greenland" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Nuuk, Greenland</extra-loc-engineeringenglish>
      <source>Nuuk, Greenland445</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="努克，格陵蘭">努克，格陵蘭</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_oklahoma_city_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Oklahoma City, United States of America</extra-loc-engineeringenglish>
      <source>Oklahoma City, OK, United States of America446</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="奧克拉荷馬市，OK，美國">奧克拉荷馬市，OK，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_omaha_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Omaha, United States of America</extra-loc-engineeringenglish>
      <source>Omaha, NE, United States of America447</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="奧馬哈，NE，美國">奧馬哈，NE，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_oranjestad_aruba" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Oranjestad, Aruba</extra-loc-engineeringenglish>
      <source>Oranjestad, Aruba448</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="奧蘭葉斯塔，阿魯巴">奧蘭葉斯塔，阿魯巴</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_osaka_japan" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Osaka, Japan</extra-loc-engineeringenglish>
      <source>Osaka, Japan449</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="大阪，日本">大阪，日本</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_oslo_norway" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Oslo, Norway</extra-loc-engineeringenglish>
      <source>Oslo, Norway450</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="奧斯陸，挪威">奧斯陸，挪威</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_ottawa_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Ottawa, Canada</extra-loc-engineeringenglish>
      <source>Ottawa, Canada451</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="渥太華，加拿大">渥太華，加拿大</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_ouagadougou_bf" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Ouagadougou, Burkina Faso</extra-loc-engineeringenglish>
      <source>Ouagadougou, Burkina Faso452</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="瓦加杜古，布吉納法索">瓦加杜古，布吉納法索</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_pago_pago_as_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Pago Pago, AS, United States of America</extra-loc-engineeringenglish>
      <source>Pago Pago, AS, United States of America453</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="帕果帕果，AS，美國">帕果帕果，AS，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_palikir_micronesia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Palikir, Micronesia</extra-loc-engineeringenglish>
      <source>Palikir, Micronesia454</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="帕利奇，密克羅尼西亞">帕利奇，密克羅尼西亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_palmas_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Palmas, Brazil</extra-loc-engineeringenglish>
      <source>Palmas, Brazil455</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="帕馬斯，巴西">帕馬斯，巴西</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_panama_city_panama" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Panama City, Panama</extra-loc-engineeringenglish>
      <source>Panama City, Panama456</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="巴拿馬市，巴拿馬">巴拿馬市，巴拿馬</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_papeete_tahiti" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Papeete, Tahiti</extra-loc-engineeringenglish>
      <source>Papeete, Tahiti457</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="巴比堤，大溪地">巴比堤，大溪地</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_paramaribo_suriname" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Paramaribo, Suriname</extra-loc-engineeringenglish>
      <source>Paramaribo, Suriname458</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="巴拉馬利波，蘇利南">巴拉馬利波，蘇利南</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_paris_france" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Paris, France</extra-loc-engineeringenglish>
      <source>Paris, France459</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="巴黎，法國">巴黎，法國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_pbm_galapagos_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Puerto Baquerizo Moreno, Galapagos Islands</extra-loc-engineeringenglish>
      <source>Puerto Baquerizo Moreno, Galapagos Islands460</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="黑巴克里索港，加拉巴哥群島">黑巴克里索港，加拉巴哥群島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_pensacola_fl_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Pensacola, FL, United States of America</extra-loc-engineeringenglish>
      <source>Pensacola, FL, United States of America461</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="朋沙科拉，FL，美國">朋沙科拉，FL，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_perth_aus" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Perth, Australia</extra-loc-engineeringenglish>
      <source>Perth, Australia462</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="柏斯，澳大利亞">柏斯，澳大利亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_philadelphia_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Philadelphia, United States of America</extra-loc-engineeringenglish>
      <source>Philadelphia, PA, United States of America463</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="費城，PA，美國">費城，PA，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_phnom_penh_cambodia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Phnom Penh, Cambodia</extra-loc-engineeringenglish>
      <source>Phnom Penh, Cambodia464</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="金邊，柬埔寨">金邊，柬埔寨</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_phoenix_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Phoenix, United States of America</extra-loc-engineeringenglish>
      <source>Phoenix, AZ, United States of America465</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="鳳凰城，AZ，美國">鳳凰城，AZ，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_podgorica_montenegro" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Podgorica, Montenegro</extra-loc-engineeringenglish>
      <source>Podgorica, Montenegro466</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="波德戈里察，蒙特尼哥羅">波德戈里察，蒙特尼哥羅</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_ponta_delgada_azores" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Ponta Delgada, Azores</extra-loc-engineeringenglish>
      <source>Ponta Delgada, Azores467</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="蓬塔德爾加達，亞速群島">蓬塔德爾加達，亞速群島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_port_louis_mauritius" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Port Louis, Mauritius</extra-loc-engineeringenglish>
      <source>Port Louis, Mauritius468</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="路易士港，模里西斯">路易士港，模里西斯</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_port_moresby_png" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Port Moresby, Papua New Guinea</extra-loc-engineeringenglish>
      <source>Port Moresby, Papua New Guinea469</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="莫士比港，巴布亞紐幾內亞">莫士比港，巴布亞紐幾內亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_port_of_spain_trinidad" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Port of Spain, Trinidad</extra-loc-engineeringenglish>
      <source>Port of Spain, Trinidad470</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="西班牙港，千里達">西班牙港，千里達</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_port_vila_vanuatu" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Port Vila, Vanuatu</extra-loc-engineeringenglish>
      <source>Port Vila, Vanuatu471</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="維拉港，萬那杜">維拉港，萬那杜</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_portland_or_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Portland, OR, United States of America</extra-loc-engineeringenglish>
      <source>Portland, OR, United States of America472</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="波特蘭，OR，美國">波特蘭，OR，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_porto_alegre_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Porto Alegre, Brazil</extra-loc-engineeringenglish>
      <source>Porto Alegre, Brazil473</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="阿雷格港，巴西">阿雷格港，巴西</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_porto_au_prince_haiti" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Port-au-Prince, Haiti</extra-loc-engineeringenglish>
      <source>Port-au-Prince, Haiti474</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="太子港，海地">太子港，海地</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_porto_aux_francais_kerguelen" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Port-aux-Francais, Kerguelen</extra-loc-engineeringenglish>
      <source>Port-aux-Francais, Kerguelen Islands475</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="奧斯法蘭西斯港，克格連群島">奧斯法蘭西斯港，克格連群島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_porto_novo_benin" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Porto-Novo, Benin</extra-loc-engineeringenglish>
      <source>Porto-Novo, Benin476</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="波多諾伏，貝南">波多諾伏，貝南</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_porto_velho_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Porto Velho, Brazil</extra-loc-engineeringenglish>
      <source>Porto Velho, Brazil477</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="維留港，巴西">維留港，巴西</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_prague_czech" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Prague, Czechoslovakia</extra-loc-engineeringenglish>
      <source>Prague, Czech Republic478</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="布拉格，捷克">布拉格，捷克</lengthvariant>
      </translation>
      <oldsource>Prague, Czechoslovakia</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_praia_cape_verde" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Praia, Cape Verde</extra-loc-engineeringenglish>
      <source>Praia, Cape Verde479</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="培亞，維德角">培亞，維德角</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_pretoria_safrica" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Pretoria, South Africa</extra-loc-engineeringenglish>
      <source>Pretoria, South Africa480</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="比勒陀利亞，南非">比勒陀利亞，南非</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_providence_ri_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Providence, RI, United States of America</extra-loc-engineeringenglish>
      <source>Providence, RI, United States of America481</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="普羅維丹斯，RI，美國">普羅維丹斯，RI，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_pyongyang_north_korea" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Pyongyang, North Korea</extra-loc-engineeringenglish>
      <source>Pyongyang, North Korea482</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="平壤，北韓">平壤，北韓</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_quito_equador" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Quito, Equador</extra-loc-engineeringenglish>
      <source>Quito, Equador483</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="基多，厄瓜多">基多，厄瓜多</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_rabat_morocco" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Rabat, Morocco</extra-loc-engineeringenglish>
      <source>Rabat, Morocco484</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="拉巴特，摩洛哥">拉巴特，摩洛哥</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_rainy_river_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Rainy River, Canada</extra-loc-engineeringenglish>
      <source>Rainy River, Canada485</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="雨河，加拿大">雨河，加拿大</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_rangoon_myanmar" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Rangoon, Myanmar</extra-loc-engineeringenglish>
      <source>Rangoon, Myanmar486</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="仰光，緬甸">仰光，緬甸</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_rankin_inlet_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Rankin Inlet, Canada</extra-loc-engineeringenglish>
      <source>Rankin Inlet, Canada487</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="蘭金灣，加拿大">蘭金灣，加拿大</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_recife_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Recife, Brazil</extra-loc-engineeringenglish>
      <source>Recife, Brazil488</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="勒西菲，巴西">勒西菲，巴西</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_regina_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Regina, Canada</extra-loc-engineeringenglish>
      <source>Regina, Canada489</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="雷吉納，加拿大">雷吉納，加拿大</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_reykjavik_iceland" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Reykjavik, Iceland</extra-loc-engineeringenglish>
      <source>Reykjavik, Iceland490</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="雷克雅維克，冰島">雷克雅維克，冰島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_richmond_va_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Richmond, VA, United States of America</extra-loc-engineeringenglish>
      <source>Richmond, VA, United States of America491</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="里奇蒙，VA，美國">里奇蒙，VA，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_riga_latvia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Riga, Latvia</extra-loc-engineeringenglish>
      <source>Riga, Latvia492</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="里加，拉脫維亞">里加，拉脫維亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_rio_de_jan_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Rio de Janeiro, Brazil</extra-loc-engineeringenglish>
      <source>Rio de Janeiro, Brazil493</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="里約熱內盧，巴西">里約熱內盧，巴西</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_riyadh_saudi_arabia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Riyadh, Saudi Arabia</extra-loc-engineeringenglish>
      <source>Riyadh, Saudi Arabia494</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="利雅得，沙烏地阿拉伯">利雅得，沙烏地阿拉伯</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_road_town_british_virgin_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Road Town, British Virgin Islands</extra-loc-engineeringenglish>
      <source>Road Town, British Virgin Islands495</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="洛德鎮，英屬維京群島">洛德鎮，英屬維京群島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_rome_italy" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Rome, Italy</extra-loc-engineeringenglish>
      <source>Rome, Italy496</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="羅馬，義大利">羅馬，義大利</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_roseau_dominica" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Roseau, Dominica</extra-loc-engineeringenglish>
      <source>Roseau, Dominica497</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="羅梭，多米尼克">羅梭，多米尼克</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_saint_denis_reunion" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Saint-Denis, Reunion</extra-loc-engineeringenglish>
      <source>Saint-Denis, Reunion498</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="聖德尼，雷尼旺島">聖德尼，雷尼旺島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_saint_georges_grenada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Saint George's, </extra-loc-engineeringenglish>
      <source>Saint George's, Grenada499</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="聖喬治，格瑞那達">聖喬治，格瑞那達</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_saint_johns_ab" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Saint John's, Antigua and Barbuda</extra-loc-engineeringenglish>
      <source>Saint John's, Antigua and Barbuda500</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="聖約翰，安地卡及巴布達">聖約翰，安地卡及巴布達</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_saint_pierre_miquelon" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Saint-Pierre, Miquelon</extra-loc-engineeringenglish>
      <source>Saint-Pierre, Miquelon501</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="聖彼德，密啟倫群島">聖彼德，密啟倫群島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_saipan_mariana_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Saipan, Mariana Islands</extra-loc-engineeringenglish>
      <source>Saipan, Mariana Islands502</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="塞班島，馬里亞納群島">塞班島，馬里亞納群島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_saipan_mp_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Saipan, MP, United States of America</extra-loc-engineeringenglish>
      <source>Saipan, MP, United States of America503</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="塞班島，MP，美國">塞班島，MP，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_salt_lake_city_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Salt Lake City, United States of America</extra-loc-engineeringenglish>
      <source>Salt Lake City, UT, United States of America504</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="鹽湖城，UT，美國">鹽湖城，UT，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_salvador_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Salvador, Brazil</extra-loc-engineeringenglish>
      <source>Salvador, Brazil505</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="薩爾瓦多，巴西">薩爾瓦多，巴西</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_samara_russia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Samara, Russia</extra-loc-engineeringenglish>
      <source>Samara, Russia506</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="薩馬拉，俄羅斯">薩馬拉，俄羅斯</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_san_francisco_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>San Francisco, United States of America</extra-loc-engineeringenglish>
      <source>San Francisco, CA, United States of America507</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="舊金山，CA，美國">舊金山，CA，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_san_jose_costa_rica" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>San Jose, Costa Rica</extra-loc-engineeringenglish>
      <source>San Jose, Costa Rica508</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="聖荷西，哥斯大黎加">聖荷西，哥斯大黎加</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_san_juan_puerto_rico" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>San Juan, Puerto Rico</extra-loc-engineeringenglish>
      <source>San Juan, Puerto Rico509</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="聖璜，波多黎各">聖璜，波多黎各</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_san_marino_city_san_marino" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>San Marino City, San Marino</extra-loc-engineeringenglish>
      <source>San Marino City, San Marino510</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="聖馬利諾市，聖馬利諾">聖馬利諾市，聖馬利諾</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_san_salvador_el_salvador" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>San Salvador, El Salvador</extra-loc-engineeringenglish>
      <source>San Salvador, El Salvador511</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="聖薩爾瓦多，薩爾瓦多">聖薩爾瓦多，薩爾瓦多</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_sanaa_yemen" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Sanaa, Yemen</extra-loc-engineeringenglish>
      <source>Sanaa, Yemen512</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="薩那，葉門">薩那，葉門</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_santiago_chile" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Santiago, Chile</extra-loc-engineeringenglish>
      <source>Santiago, Chile513</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="聖地牙哥，智利">聖地牙哥，智利</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_santo_domingo_dominican_rep" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Santo Domingo, Dominican Republic</extra-loc-engineeringenglish>
      <source>Santo Domingo, Dominican Republic514</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="聖多明哥，多明尼加共和國">聖多明哥，多明尼加共和國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_sao_luis_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Sao Luis, Brazil</extra-loc-engineeringenglish>
      <source>Sao Luis, Brazil515</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="聖盧伊斯，巴西">聖盧伊斯，巴西</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_sao_paulo_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Sao Paulo, Brazil</extra-loc-engineeringenglish>
      <source>Sao Paulo, Brazil516</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="聖保羅，巴西">聖保羅，巴西</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_sao_tome_principe" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>São Tomé, Príncipe</extra-loc-engineeringenglish>
      <source>São Tomé, São Tomé and Príncipe517</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="聖多美，聖多美普林西比">聖多美，聖多美普林西比</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_sapporo_japan" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Sapporo, Japan</extra-loc-engineeringenglish>
      <source>Sapporo, Japan518</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="札幌，日本">札幌，日本</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_scoresbysund_greenland" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Scoresbysund, Greenland</extra-loc-engineeringenglish>
      <source>Scoresbysund, Greenland519</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="斯科斯比松，格陵蘭">斯科斯比松，格陵蘭</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_seattle_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Seattle, United States of America</extra-loc-engineeringenglish>
      <source>Seattle, WA, United States of America520</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="西雅圖，WA，美國">西雅圖，WA，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_seoul_skorea" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Seoul, South Korea</extra-loc-engineeringenglish>
      <source>Seoul, South Korea521</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="首爾，南韓">首爾，南韓</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_singapore_city_singapore" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Singapore City, Singapore</extra-loc-engineeringenglish>
      <source>Singapore, Singapore522</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="新加坡，新加坡">新加坡，新加坡</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_sioux_falls_sd_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Sioux Falls, SD, United States of America</extra-loc-engineeringenglish>
      <source>Sioux Falls, SD, United States of America523</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="秀佛斯，SD，美國">秀佛斯，SD，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_skopje_macedonia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Skopje, Macedonia</extra-loc-engineeringenglish>
      <source>Skopje, Macedonia524</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="斯高彼亞，馬其頓">斯高彼亞，馬其頓</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_sofia_bulgaria" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Sofia, Bulgaria</extra-loc-engineeringenglish>
      <source>Sofia, Bulgaria525</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="索菲亞，保加利亞">索菲亞，保加利亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_sonora_mexico" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Sonora, Mexico</extra-loc-engineeringenglish>
      <source>Sonora, Mexico526</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="索諾拉，墨西哥">索諾拉，墨西哥</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_st_loius_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>St. Louis, United States of America</extra-loc-engineeringenglish>
      <source>St. Louis, MO, United States of America527</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="聖路易斯，MO，美國">聖路易斯，MO，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_st_petersburg_russia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>St. Petersburg, Russia</extra-loc-engineeringenglish>
      <source>St. Petersburg, Russia528</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="聖彼得堡，俄羅斯">聖彼得堡，俄羅斯</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_stanley_falkland_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Stanley, Falkland Islands</extra-loc-engineeringenglish>
      <source>Stanley, Falkland Islands529</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="史坦雷，福克蘭群島">史坦雷，福克蘭群島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_stockholm_sweden" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Stockholm, Sweden</extra-loc-engineeringenglish>
      <source>Stockholm, Sweden530</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="斯德哥爾摩，瑞典">斯德哥爾摩，瑞典</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_suva_fiji" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Suva, Fiji</extra-loc-engineeringenglish>
      <source>Suva, Fiji531</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="蘇瓦，斐濟">蘇瓦，斐濟</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_taiohae_marquesas_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Taiohae, Marquesas Islands</extra-loc-engineeringenglish>
      <source>Taiohae, Marquesas Islands532</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="泰奧開，馬克沙斯群島">泰奧開，馬克沙斯群島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_taipei_taiwan" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Taipei, Taiwan</extra-loc-engineeringenglish>
      <source>Taipei, Taiwan533</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="台北，台灣">台北，台灣</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_tallinn_estonia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Tallinn, Estonia</extra-loc-engineeringenglish>
      <source>Tallinn, Estonia534</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="塔林，愛沙尼亞">塔林，愛沙尼亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_tarawa_kiribati" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Tarawa, Kiribati</extra-loc-engineeringenglish>
      <source>Tarawa, Kiribati535</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="塔拉瓦，吉里巴斯">塔拉瓦，吉里巴斯</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_taskhkent_uzbekistan" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Tashkent, Uzbekistan</extra-loc-engineeringenglish>
      <source>Tashkent, Uzbekistan536</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="塔什干，烏茲別克">塔什干，烏茲別克</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_tbilisi_georgia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Tbilisi, Georgia</extra-loc-engineeringenglish>
      <source>Tbilisi, Georgia537</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="第比利斯，喬治亞">第比利斯，喬治亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_tegucigalpa_honduras" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Tegucigalpa, Honduras</extra-loc-engineeringenglish>
      <source>Tegucigalpa, Honduras538</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="德古斯加巴，宏都拉斯">德古斯加巴，宏都拉斯</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_tehran_iran" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Tehran, Iran</extra-loc-engineeringenglish>
      <source>Tehran, Iran539</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="德黑蘭，伊朗">德黑蘭，伊朗</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_tel_aviv_israel" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Tel Aviv, Israel</extra-loc-engineeringenglish>
      <source>Tel Aviv, Israel540</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="台拉維夫，以色列">台拉維夫，以色列</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_teresina_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Teresina, Brazil</extra-loc-engineeringenglish>
      <source>Teresina, Brazil541</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="特拉辛納，巴西">特拉辛納，巴西</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_the_settlement_christmas_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>The Settlement, Christmas Island.</extra-loc-engineeringenglish>
      <source>The Settlement, Christmas Island542</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="塞特門，聖誕島">塞特門，聖誕島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_the_valley_anguilla" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>The Valley, Anguilla</extra-loc-engineeringenglish>
      <source>The Valley, Anguilla543</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="維利，安圭拉">維利，安圭拉</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_thimpu_bhutan" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Thimpu, Bhutan</extra-loc-engineeringenglish>
      <source>Thimpu, Bhutan544</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="辛布，不丹">辛布，不丹</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_thule_greenland" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Thule, Greenland</extra-loc-engineeringenglish>
      <source>Thule, Greenland545</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="杜里，格陵蘭">杜里，格陵蘭</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_tijuana_mexico" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Tijuana, Mexico</extra-loc-engineeringenglish>
      <source>Tijuana, Mexico546</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="堤華納，墨西哥">堤華納，墨西哥</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_time" marked="false">
      <extracomment />
      <location />
      <comment>When a city is added to the World Clock listview, its time is displayed.</comment>
      <extra-loc-engineeringenglish>&lt;time&gt;</extra-loc-engineeringenglish>
      <source>Time547</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="時間">時間</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_World clock_P05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_tirana_albania" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Tirana, Albania</extra-loc-engineeringenglish>
      <source>Tirana, Albania548</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="地拉那，阿爾巴尼亞">地拉那，阿爾巴尼亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_tokya_japan" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Tokya, Japan</extra-loc-engineeringenglish>
      <source>Tokyo, Japan549</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="東京，日本">東京，日本</lengthvariant>
      </translation>
      <oldsource>Tokya, Japan</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_toronto_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Toronto, Canada</extra-loc-engineeringenglish>
      <source>Toronto, Canada550</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="多倫多，加拿大">多倫多，加拿大</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_tórshavn_faroe_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Tórshavn, Faroe Islands</extra-loc-engineeringenglish>
      <source>Tórshavn, Faroe Islands551</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">zh_tw Tórshavn, Faroe Islands</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_tripoli_libya" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Tripoli, Libya</extra-loc-engineeringenglish>
      <source>Tripoli, Libya552</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="的黎波里，利比亞">的黎波里，利比亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_tunis_tunisia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Tunis, Tunisia</extra-loc-engineeringenglish>
      <source>Tunis, Tunisia553</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="突尼斯，突尼西亞">突尼斯，突尼西亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_ulaanbaatar_mongolia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Ulaanbaatar, Mongolia</extra-loc-engineeringenglish>
      <source>Ulaanbaatar, Mongolia554</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="烏蘭巴托，蒙古">烏蘭巴托，蒙古</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_vaduz_lichtenstein" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Vaduz, Lichtenstein</extra-loc-engineeringenglish>
      <source>Vaduz, Lichtenstein555</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="瓦都茲，列支敦斯登">瓦都茲，列支敦斯登</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_valletta_malta" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Valletta, Malta</extra-loc-engineeringenglish>
      <source>Valletta, Malta556</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="瓦列塔，馬爾他">瓦列塔，馬爾他</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_vancouver_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Vancouver, Canada</extra-loc-engineeringenglish>
      <source>Vancouver, Canada557</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="溫哥華，加拿大">溫哥華，加拿大</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_victoria_seychelles" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Victoria, Seychelles</extra-loc-engineeringenglish>
      <source>Victoria, Seychelles558</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="維多利亞，塞席爾">維多利亞，塞席爾</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_vienna_austria" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Vienna, Austria</extra-loc-engineeringenglish>
      <source>Vienna, Austria559</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="維也納，奧地利">維也納，奧地利</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_vientiane_laos" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Vientiane, Laos</extra-loc-engineeringenglish>
      <source>Vientiane, Laos560</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="永珍，寮國">永珍，寮國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_vilnius_lithuania" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Vilnius, Lithuania</extra-loc-engineeringenglish>
      <source>Vilnius, Lithuania561</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="維爾紐斯，立陶宛">維爾紐斯，立陶宛</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_vladivostok_russia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Vladivostok, Russia</extra-loc-engineeringenglish>
      <source>Vladivostok, Russia562</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="海參威，俄羅斯">海參威，俄羅斯</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_warsaw_poland" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Warsaw, Poland</extra-loc-engineeringenglish>
      <source>Warsaw, Poland563</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="華沙，波蘭">華沙，波蘭</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_washington_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Washington, United States of America</extra-loc-engineeringenglish>
      <source>Washington, DC, United States of America564</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="華盛頓，DC，美國">華盛頓，DC，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_wellington_nzealand" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Wellington, New Zealand</extra-loc-engineeringenglish>
      <source>Wellington, New Zealand565</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="威靈頓，紐西蘭">威靈頓，紐西蘭</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_west_isl_cocos_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>West Island, Cocos Islands</extra-loc-engineeringenglish>
      <source>West Island, Cocos (Keeling) Islands566</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="西島，可可斯群島">西島，可可斯群島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_wichita_ks_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Wichita, KS, United States of America</extra-loc-engineeringenglish>
      <source>Wichita, KS, United States of America567</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="威契塔，KS，美國">威契塔，KS，美國</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_willemstad_curacao" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Willemstad, Curacao</extra-loc-engineeringenglish>
      <source>Willemstad, Curacao568</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="維倫斯塔，古拉索島">維倫斯塔，古拉索島</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_windhoek_namibia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Windhoek, Namibia</extra-loc-engineeringenglish>
      <source>Windhoek, Namibia569</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="文豪克，納米比亞">文豪克，納米比亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_winnipeg_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Winnipeg, Canada</extra-loc-engineeringenglish>
      <source>Winnipeg, Canada570</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="溫尼伯，加拿大">溫尼伯，加拿大</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_yakutsk_russia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Yakutsk, Russia</extra-loc-engineeringenglish>
      <source>Yakutsk, Russia571</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="雅庫茨克，俄羅斯">雅庫茨克，俄羅斯</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_yaoundé_cameroon" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Yaoundé, Cameroon</extra-loc-engineeringenglish>
      <source>Yaoundé, Cameroon572</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="雅溫德，喀麥隆">雅溫德，喀麥隆</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_yaren_district_nauru" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Yaren District, Nauru</extra-loc-engineeringenglish>
      <source>Yaren District, Nauru573</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="亞倫區，諾魯">亞倫區，諾魯</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_yekaterinburg_russia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Yekaterinburg, Russia</extra-loc-engineeringenglish>
      <source>Yekaterinburg, Russia574</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="凱薩琳堡，俄羅斯">凱薩琳堡，俄羅斯</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_yellowknife_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Yellowknife, Canada</extra-loc-engineeringenglish>
      <source>Yellowknife, Canada575</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="黃刀鎮，加拿大">黃刀鎮，加拿大</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_yerevan_armenia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Yerevan, Armenia</extra-loc-engineeringenglish>
      <source>Yerevan, Armenia576</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="葉勒凡，亞美尼亞">葉勒凡，亞美尼亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_zagreb_croatia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Zagreb, Croatia</extra-loc-engineeringenglish>
      <source>Zagreb, Croatia577</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="札格列柏，克羅埃西亞">札格列柏，克羅埃西亞</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_main_view_list_alarm" marked="false">
      <extracomment />
      <location />
      <comment>Alarm description is displayed in the middle row. If user doesnt enter name, the default description is "Alarm".</comment>
      <extra-loc-engineeringenglish>Alarm</extra-loc-engineeringenglish>
      <source>Alarm578</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="鬧鈴">鬧鈴</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_15,410</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock main view_P01</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="yes" id="txt_clk_main_view_list_in_ln_hrs" marked="false">
      <extracomment />
      <location />
      <comment>Remaining alarm time is displayed in the top row above the alarm description</comment>
      <extra-loc-engineeringenglish>In %Ln hrs</extra-loc-engineeringenglish>
      <source>In %Ln hours579</source>
      <translation testresult="false" keep="false">
        <numerusform plurality="a" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Warning ignored as instructed by Nokia." originaltestercomment="" variants="no" originaltranslation="在%Ln小時內">在%Ln小時內</numerusform>
      </translation>
      <oldsource>In %Ln hour</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_graphic_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_graphic_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock main view_P01</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_main_view_list_no_alarms_set" marked="false">
      <extracomment />
      <location />
      <comment>When there are no alarms set in Clock main view, the text "No alarms set" is displayed in list.</comment>
      <extra-loc-engineeringenglish>No alarms set</extra-loc-engineeringenglish>
      <source>(no alarms set)580</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="(未設定鬧鈴)">(未設定鬧鈴)</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_15,410</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock main view_with no alarms set_P02</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_main_view_list_occurence_detail" marked="false">
      <extracomment />
      <location />
      <comment>Occurence detail is displayed in the bottom row.</comment>
      <extra-loc-engineeringenglish>&lt;Occurence detail&gt;</extra-loc-engineeringenglish>
      <source>Alarm details581</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="鬧鈴詳細資訊">鬧鈴詳細資訊</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_15,410,79</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock main view_P01</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_main_view_list_time" marked="false">
      <extracomment />
      <location />
      <comment>When user sets alarm time, it is displayed on the left column. "am/pm" is placed below the time.</comment>
      <extra-loc-engineeringenglish>&lt;time&gt;</extra-loc-engineeringenglish>
      <source>Alarm time582</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="鬧鈴時間">鬧鈴時間</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_15,410</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock main view_P01</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_main_view_menu_delete_alarm" marked="false">
      <extracomment />
      <location />
      <comment>Long tap on an alarm in Alarm list opens the item specific menu displaying text "Delete alarm"</comment>
      <extra-loc-engineeringenglish>Delete alarm</extra-loc-engineeringenglish>
      <source>Delete alarm583</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="刪除鬧鈴">刪除鬧鈴</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_15,410,77</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>Clock main view_P01</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_main_view_opt_exit" marked="false">
      <extracomment />
      <location />
      <comment>Item in Options menu from Clock main view</comment>
      <extra-loc-engineeringenglish>Exit</extra-loc-engineeringenglish>
      <source>Exit584</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="退出">退出</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>97</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>Clock main view_P01</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_main_view_opt_help" marked="false">
      <extracomment />
      <location />
      <comment>Item in Options menu from Clock main view</comment>
      <extra-loc-engineeringenglish>Help</extra-loc-engineeringenglish>
      <source>Help585</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="說明">說明</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>511</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>Clock main view_P01</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_main_view_opt_settings" marked="false">
      <extracomment />
      <location />
      <comment>Item in Options menu from Clock main vew</comment>
      <extra-loc-engineeringenglish>Settings</extra-loc-engineeringenglish>
      <source>Settings586</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="設定">設定</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>290,NOT_291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>Clock main view_P01</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_main_view_title_clock" marked="false">
      <extracomment />
      <location />
      <comment>Title name for the Clock application</comment>
      <extra-loc-engineeringenglish>Clock</extra-loc-engineeringenglish>
      <source>Clock587</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="時鐘">時鐘</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_chrome_title</extra-loc-layout_id>
      <extra-loc-layout>qtl_chrome_title</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>61</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>Clock main view_P01</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_menu_delete" marked="false">
      <extracomment />
      <location />
      <comment>Long tap menu on an added city in World Clock view (both portrait and landscape)</comment>
      <extra-loc-engineeringenglish>Delete</extra-loc-engineeringenglish>
      <source>Delete588</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="刪除">刪除</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>77</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>Clock_World clock_P05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_menu_set_as_current_location" marked="false">
      <extracomment />
      <location />
      <comment>Long tap menu on an added city in the World clock view (both portrait and landscape)</comment>
      <extra-loc-engineeringenglish>Set as current location</extra-loc-engineeringenglish>
      <source>Set as current location589</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="設為目前的位置">設為目前的位置</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>543,NOT_544</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>Clock_World clock_P05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_menu_show_on_homescreen" marked="false">
      <extracomment />
      <location />
      <comment>Long tap menu on an added city in World clock view (both portrait and landscape)</comment>
      <extra-loc-engineeringenglish>Show on homescreen</extra-loc-engineeringenglish>
      <source>Show on Home screen590</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="在首頁畫面中顯示">在首頁畫面中顯示</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>432</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>Clock_World clock_P05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_opt_add_own_city" marked="false">
      <extracomment />
      <location />
      <comment>"Add own city" from Options menu in City list </comment>
      <extra-loc-engineeringenglish>Add own city</extra-loc-engineeringenglish>
      <source>Add own city591</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">zh_tw Add own city</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_alarm_sound" marked="false">
      <extracomment />
      <location />
      <comment>Label for Alarm sound in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Alarm sound</extra-loc-engineeringenglish>
      <source>Alarm sound592</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="鬧鈴聲">鬧鈴聲</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_checkbox_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_checkbox_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_15,410</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_date_format" marked="false">
      <extracomment />
      <location />
      <comment>3rd field in Regional date &amp; time settings view</comment>
      <extra-loc-engineeringenglish>Date format:</extra-loc-engineeringenglish>
      <source>Date format:593</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="日期格式：">日期格式：</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_heading_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_heading_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_3</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_day" marked="false">
      <extracomment />
      <location />
      <comment>Label for Day in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Day</extra-loc-engineeringenglish>
      <source>Day594</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="日">日</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_heading_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_heading_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_daylight_saving_time" marked="false">
      <extracomment />
      <location />
      <comment>Label for DST in Clock settings view</comment>
      <extra-loc-engineeringenglish>Daylight saving time</extra-loc-engineeringenglish>
      <source>Daylight saving time595</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="日光節約時間">日光節約時間</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_checkbox_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_checkbox_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_occurence" marked="false">
      <extracomment />
      <location />
      <comment>Label for Occurence in Alarm editor</comment>
      <extra-loc-engineeringenglish>Occurence</extra-loc-engineeringenglish>
      <source>Repeat596</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="重複">重複</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_heading_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_heading_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_400</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_time" marked="false">
      <extracomment />
      <location />
      <comment>Label for Time in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Time</extra-loc-engineeringenglish>
      <source>Time597</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="時間">時間</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_heading_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_heading_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_use_network_date_time" marked="false">
      <extracomment />
      <location />
      <comment>1st label in Date and time settings view</comment>
      <extra-loc-engineeringenglish>Use network date &amp; time</extra-loc-engineeringenglish>
      <source>Auto-update of date and time598</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="自動更新日期時間">自動更新日期時間</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_checkbox_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_checkbox_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>28</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_12_hour" marked="false">
      <extracomment />
      <location />
      <comment>2nd value in combo box list for Time format label</comment>
      <extra-loc-engineeringenglish>12 hour</extra-loc-engineeringenglish>
      <source>12-hour599</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="12小時制">12小時制</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_2_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_3</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_24_hour" marked="false">
      <extracomment />
      <location />
      <comment>1st Value in combo box list for Time format label</comment>
      <extra-loc-engineeringenglish>24 hour</extra-loc-engineeringenglish>
      <source>24-hour600</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="24小時制">24小時制</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_3</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_dd_mm_yyyy" marked="false">
      <extracomment />
      <location />
      <comment>1st value in combo box list for Date format label</comment>
      <extra-loc-engineeringenglish>dd mm yyyy</extra-loc-engineeringenglish>
      <source>dd mm yyyy601</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="日月年">日月年</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_3</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_friday" marked="false">
      <extracomment />
      <location />
      <comment>5th dropdown list value for Day label in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Friday</extra-loc-engineeringenglish>
      <source>Friday602</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="星期五">星期五</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_5_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_mm_dd_yyyy" marked="false">
      <extracomment />
      <location />
      <comment>2nd value in combo box list for Date format label</comment>
      <extra-loc-engineeringenglish>mm dd yyyy</extra-loc-engineeringenglish>
      <source>mm dd yyyy603</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="月日年">月日年</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_2_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_3</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_monday" marked="false">
      <extracomment />
      <location />
      <comment>1st dropdown list value for Day label in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Monday</extra-loc-engineeringenglish>
      <source>Monday604</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="星期一">星期一</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_once" marked="false">
      <extracomment />
      <location />
      <comment>1st dropdown list value for Occurence label in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Once</extra-loc-engineeringenglish>
      <source>Not repeated605</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="不重複">不重複</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_daily" marked="false">
      <extracomment />
      <location />
      <comment>2nd dropdown list value for Occurence label in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Repeat daily</extra-loc-engineeringenglish>
      <source>Daily606</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="每日">每日</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_2_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_on_workdays" marked="false">
      <extracomment />
      <location />
      <comment>4th dropdown list value for Occurence label in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Repeat on workdays</extra-loc-engineeringenglish>
      <source>Workdays607</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="工作日">工作日</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_4_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_weekly" marked="false">
      <extracomment />
      <location />
      <comment>3rd dropdown list value for Occurence label in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Repeat weekly</extra-loc-engineeringenglish>
      <source>Weekly608</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="每週">每週</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_3_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_saturday" marked="false">
      <extracomment />
      <location />
      <comment>6th dropdown list value for Day label in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Saturday</extra-loc-engineeringenglish>
      <source>Saturday609</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="星期六">星期六</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_6_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_sunday" marked="false">
      <extracomment />
      <location />
      <comment>7th dropdown list value for Day label in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Sunday</extra-loc-engineeringenglish>
      <source>Sunday610</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="星期日">星期日</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_7_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_thursday" marked="false">
      <extracomment />
      <location />
      <comment>4th dropdown list value for Day label in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Thursday</extra-loc-engineeringenglish>
      <source>Thursday611</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="星期四">星期四</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_4_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_tuesday" marked="false">
      <extracomment />
      <location />
      <comment>2nd dropdown list value for Day label in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Tuesday</extra-loc-engineeringenglish>
      <source>Tuesday612</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="星期二">星期二</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_2_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_wednesday" marked="false">
      <extracomment />
      <location />
      <comment>3rd dropdown list value for Day label in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Wednesday</extra-loc-engineeringenglish>
      <source>Wednesday613</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="星期三">星期三</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_3_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_yyyy_mm_dd" marked="false">
      <extracomment />
      <location />
      <comment>3rd value in combo box list for Date format label</comment>
      <extra-loc-engineeringenglish>yyyy mm dd</extra-loc-engineeringenglish>
      <source>yyyy mm dd614</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="年月日">年月日</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_3_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_3</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_week_starts_on" marked="false">
      <extracomment />
      <location />
      <comment>6th field in Regional date &amp; time settings view</comment>
      <extra-loc-engineeringenglish>Week starts on:</extra-loc-engineeringenglish>
      <source>Week starts on:615</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="週起始日：">週起始日：</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_heading_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_heading_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_320</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_3</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_workdays" marked="false">
      <extracomment />
      <location />
      <comment>Label for Workdays in Alarm editor</comment>
      <extra-loc-engineeringenglish>Workdays:</extra-loc-engineeringenglish>
      <source>Workdays:616</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="工作日：">工作日：</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_heading_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_heading_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_3</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_subhead_date_time" marked="false">
      <extracomment />
      <location />
      <comment>Sub-title for Date &amp; time settings view</comment>
      <extra-loc-engineeringenglish>Date &amp; time</extra-loc-engineeringenglish>
      <source>Date and time617</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="日期與時間">日期與時間</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_groupbox_simple_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_groupbox_simple_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>subtitle</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_subhead_regional_date_time_settings" marked="false">
      <extracomment />
      <location />
      <comment>Sub-title for Regiional date &amp; time settings</comment>
      <extra-loc-engineeringenglish>Regional date &amp; time settings</extra-loc-engineeringenglish>
      <source>Advanced settings618</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="進階設定">進階設定</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_groupbox_simple_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_groupbox_simple_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>290,NOT_291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>subtitle</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_3</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_subtitle_alarm" marked="false">
      <extracomment />
      <location />
      <comment>When user taps on already existed alarm in the alarm list, the alarm editor opens with subtitle "Alarm"</comment>
      <extra-loc-engineeringenglish>Alarm</extra-loc-engineeringenglish>
      <source>Alarm619</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="鬧鈴">鬧鈴</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_groupbox_simple_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_groupbox_simple_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_15,410</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>subtitle</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_subtitle_city_list" marked="false">
      <extracomment />
      <location />
      <comment>Subtitle for City list</comment>
      <extra-loc-engineeringenglish>City list</extra-loc-engineeringenglish>
      <source>City list620</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">zh_tw City list</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_groupbox_simple_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_groupbox_simple_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_156</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>subtitle</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_subtitle_new_alarm" marked="false">
      <extracomment />
      <location />
      <comment>When user taps on "New alarm" toolbar button in Clock main view, alarm editor opens with the subtitle "New alarm".</comment>
      <extra-loc-engineeringenglish>New alarm</extra-loc-engineeringenglish>
      <source>New alarm621</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="新鬧鈴">新鬧鈴</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_groupbox_simple_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_groupbox_simple_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_15,410</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>subtitle</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_subtitle_world_clock" marked="false">
      <extracomment />
      <location />
      <comment>Subtitle for World Clock view</comment>
      <extra-loc-engineeringenglish>World Clock</extra-loc-engineeringenglish>
      <source>World clock622</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="世界時鐘">世界時鐘</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_groupbox_simple_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_groupbox_simple_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_61</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>subtitle</extra-loc-positionid>
      <extra-loc-viewid>Clock_World clock_P05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_title_clock" marked="false">
      <extracomment />
      <location />
      <comment>Title for Date and time settings view</comment>
      <extra-loc-engineeringenglish>Clock</extra-loc-engineeringenglish>
      <source>Clock623</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="時鐘">時鐘</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_chrome_title</extra-loc-layout_id>
      <extra-loc-layout>qtl_chrome_title</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>61</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clock_opt_delete" marked="false">
      <extracomment />
      <location />
      <comment>When user creates a new alarm in Alarm editor form, he can "Delete" this alarm via Options menu.</comment>
      <extra-loc-engineeringenglish>Delete</extra-loc-engineeringenglish>
      <source>Delete624</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="刪除">刪除</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>77</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clock_opt_discard_changes" marked="false">
      <extracomment />
      <location />
      <comment>When user edits an already existed alarm in Alarm editor form, he can "Discard changes" from Options menu and the prevoius values are saved.</comment>
      <extra-loc-engineeringenglish>Discard changes</extra-loc-engineeringenglish>
      <source>Discard changes625</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="放棄變更">放棄變更</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cp_main_view_list_time_date" marked="false">
      <extracomment />
      <location />
      <comment>This text is displayed in 1st row</comment>
      <extra-loc-engineeringenglish>Time &amp; date</extra-loc-engineeringenglish>
      <source>Date and time626</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="日期與時間">日期與時間</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>CP main view_time &amp; date plugin_P11</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cp_main_view_list_time_info_date_info" marked="false">
      <extracomment />
      <location />
      <comment>The time and date information will be displayed in 2nd row</comment>
      <extra-loc-engineeringenglish>&lt;time info, date info&gt;</extra-loc-engineeringenglish>
      <source>Time, date627</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="時間，日期">時間，日期</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>CP main view_time &amp; date plugin_P11</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cp_main_view_subtitle_device" marked="false">
      <extracomment />
      <location />
      <comment>Subtitle for Control Panel main view under which Time &amp; date settings are displayed.</comment>
      <extra-loc-engineeringenglish>Device</extra-loc-engineeringenglish>
      <source>Phone628</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="手機">手機</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_groupbox_simple_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_groupbox_simple_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>228</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>subtitle</extra-loc-positionid>
      <extra-loc-viewid>CP main view_time &amp; date plugin_P11</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cp_main_view_title_control_panel" marked="false">
      <extracomment />
      <location />
      <comment>Title for Control Panel main view</comment>
      <extra-loc-engineeringenglish>Control Panel</extra-loc-engineeringenglish>
      <source>Control panel629</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="控制台">控制台</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_chrome_title</extra-loc-layout_id>
      <extra-loc-layout>qtl_chrome_title</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>CP main view_time &amp; date plugin_P11</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_long_caption_clk" marked="false">
      <extracomment />
      <location />
      <comment>Long caption for Clock in App library listview</comment>
      <extra-loc-engineeringenglish>Clock</extra-loc-engineeringenglish>
      <source>Clock630</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="時鐘">時鐘</translation>
      <oldsource>Clock</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>61</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
  </context>
</TS>