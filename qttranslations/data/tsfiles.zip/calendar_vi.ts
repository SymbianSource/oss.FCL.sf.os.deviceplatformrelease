<?xml version="1.0" encoding="utf-8"?>
<TS xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" version="1.0" sourcelanguage="English-GB" language="vi">
  <extra-loc-extended xsi:type="xsd:boolean">true</extra-loc-extended>
  <defaultcodec />
  <extra-loc-feature xsi:type="xsd:string">calendar@dfsxx.01</extra-loc-feature>
  <extra-loc-style xsi:type="xsd:string">ts</extra-loc-style>
  <context>
    <name>Prophet</name>
    <message numerus="no" id="txt_calendar_button_new_event" marked="false">
      <extracomment />
      <location />
      <comment>Tool bar button in the agenda view to create new event</comment>
      <extra-loc-engineeringenglish>New event</extra-loc-engineeringenglish>
      <source>New calendar entry35</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi #New event</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny1_1</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny1_1</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_41,42</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>calendar_p2</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_description" marked="false">
      <extracomment />
      <location />
      <comment>Label item in event editor</comment>
      <extra-loc-engineeringenglish>Description</extra-loc-engineeringenglish>
      <source>Description36</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Description</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>formlabel_4</extra-loc-positionid>
      <extra-loc-viewid>calendar_p5</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_location" marked="false">
      <extracomment />
      <location />
      <comment>Default text for Location field in event editor(Text edit widget)</comment>
      <extra-loc-engineeringenglish>Location</extra-loc-engineeringenglish>
      <source>Location37</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Location</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_543,NOT_544</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>formlabel_2_val</extra-loc-positionid>
      <extra-loc-viewid>calendar_p5</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_formlabel_val_subject" marked="false">
      <extracomment />
      <location />
      <comment>Default text for Subject field in event editor (Multiline input text field)</comment>
      <extra-loc-engineeringenglish>Subject</extra-loc-engineeringenglish>
      <source>Subject38</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Subject</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_description_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_description_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>formlabel_1_val</extra-loc-positionid>
      <extra-loc-viewid>calendar_p5</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_list_all_day_event" marked="false">
      <extracomment />
      <location />
      <comment>Label item in the event editor to indicate the event is for the whole day</comment>
      <extra-loc-engineeringenglish>All day event</extra-loc-engineeringenglish>
      <source>All-day event39</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi All-day event</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_checkbox_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_checkbox_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_96</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>calendar_p5</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_list_time" marked="false">
      <extracomment />
      <location />
      <comment>(From - To)Time displayed in the left side of the agenda view (12 hour /24 hour format)</comment>
      <extra-loc-engineeringenglish>&lt;Time&gt;</extra-loc-engineeringenglish>
      <source>Time40</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Time</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri_large_graphic_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri_large_graphic_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>calendar_p2</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_done" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item . This command mark the selected task to completed state</comment>
      <extra-loc-engineeringenglish>Mark as done</extra-loc-engineeringenglish>
      <source>Mark as done41</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Mark as done</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>167</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>calendar_p2</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_menu_mark_as_undone" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. This command set the task to uncompleted state</comment>
      <extra-loc-engineeringenglish>Mark as undone</extra-loc-engineeringenglish>
      <source>Mark as not done42</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Mark as not done</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>167</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>calendar_p2</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_menu_send" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Send command is used to send the selected event to other users</comment>
      <extra-loc-engineeringenglish>Send</extra-loc-engineeringenglish>
      <source>Send43</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Send</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>281</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>calendar_p2</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_opt_add_attachment" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item to add attachment to a event </comment>
      <extra-loc-engineeringenglish>Add attachment</extra-loc-engineeringenglish>
      <source>Add attachment44</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Add attachment</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>21</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>calendar_p5</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_opt_add_description" marked="false">
      <extracomment />
      <location />
      <comment>Option menu item to add description to a event </comment>
      <extra-loc-engineeringenglish>Add description</extra-loc-engineeringenglish>
      <source>Add description45</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Add description</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>calendar_p5</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_opt_calendar_settings" marked="false">
      <extracomment />
      <location />
      <comment>Option menu item to go to calendar settings view</comment>
      <extra-loc-engineeringenglish>Calendar settings</extra-loc-engineeringenglish>
      <source>Settings46</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi #Calendar settings</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>290</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>calendar_p1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_opt_delete_entries" marked="false">
      <extracomment />
      <location />
      <comment>Option menu item with sub menu to delete entries in the calendar</comment>
      <extra-loc-engineeringenglish>Delete entries</extra-loc-engineeringenglish>
      <source>Delete entries47</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Delete entries</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>77,42</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt_#</extra-loc-positionid>
      <extra-loc-viewid>calendar_p1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_opt_delete_event" marked="false">
      <extracomment />
      <location />
      <comment>Options menu item to delete a event</comment>
      <extra-loc-engineeringenglish>Delete event</extra-loc-engineeringenglish>
      <source>Delete entry48</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Delete entry</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>42,77</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>calendar_p5</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_opt_go_to_date" marked="false">
      <extracomment />
      <location />
      <comment>Option menu item to trigger the pop-up dialog where user input the date information</comment>
      <extra-loc-engineeringenglish>Go to date</extra-loc-engineeringenglish>
      <source>Go to date49</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi #Go to date</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>114</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>calendar_p1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_opt_new_event" marked="false">
      <extracomment />
      <location />
      <comment>Option menu item in month view to create new event</comment>
      <extra-loc-engineeringenglish>New event</extra-loc-engineeringenglish>
      <source>New entry50</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi #New event</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>42</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>calendar_p1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_opt_sub_all_entries" marked="false">
      <extracomment />
      <location />
      <comment>Options submenu item to delete all entries in the calendar</comment>
      <extra-loc-engineeringenglish>All entries</extra-loc-engineeringenglish>
      <source>All entries51</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi #All entries</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>42</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt_#_sub</extra-loc-positionid>
      <extra-loc-viewid>calendar_p1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_opt_sub_before_date" marked="false">
      <extracomment />
      <location />
      <comment>Options submenu item to delete entries before current date</comment>
      <extra-loc-engineeringenglish>Before date</extra-loc-engineeringenglish>
      <source>Before selected date52</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi #Before date</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_280</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt_#_sub</extra-loc-positionid>
      <extra-loc-viewid>calendar_p1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_preview_daydate" marked="false">
      <extracomment />
      <location />
      <comment>Displays day and date in Preview pane title text -month view</comment>
      <extra-loc-engineeringenglish>&lt;Day&gt;&lt;Date&gt;</extra-loc-engineeringenglish>
      <source>Day date53</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Day date</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>?</extra-loc-layout_id>
      <extra-loc-layout>?</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>preview</extra-loc-positionid>
      <extra-loc-viewid>calendar_p1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_alarm_snooze_time" marked="false">
      <extracomment />
      <location />
      <comment>Settings item label for setting Alarm snooze time interval</comment>
      <extra-loc-engineeringenglish>Alarm snooze time</extra-loc-engineeringenglish>
      <source>Alarm snooze time54</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi #Alarm snooze time</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>15,NOT_410</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_11</extra-loc-positionid>
      <extra-loc-viewid>calendar_p3</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_from" marked="false">
      <extracomment />
      <location />
      <comment>From (Start time &amp; date) label in event editor</comment>
      <extra-loc-engineeringenglish>From</extra-loc-engineeringenglish>
      <source>From55</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi From</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1</extra-loc-positionid>
      <extra-loc-viewid>calendar_p5</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_reminder" marked="false">
      <extracomment />
      <location />
      <comment>Label item in event editor </comment>
      <extra-loc-engineeringenglish>Reminder</extra-loc-engineeringenglish>
      <source>Reminder56</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Reminder</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_heading_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_heading_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_539</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_3</extra-loc-positionid>
      <extra-loc-viewid>calendar_p5</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="yes" id="txt_calendar_setlabel_reminder_val_before_ln_days" marked="false">
      <extracomment />
      <location />
      <comment>reminder value in ComboBox widget</comment>
      <extra-loc-engineeringenglish>Before %Ln days</extra-loc-engineeringenglish>
      <source>%Ln days before57</source>
      <translation testresult="false" keep="false">
        <numerusform plurality="a" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="">vi %Ln day before</numerusform>
      </translation>
      <oldsource>%Ln day before</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_3_val</extra-loc-positionid>
      <extra-loc-viewid>calendar_p5</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="yes" id="txt_calendar_setlabel_reminder_val_before_ln_hour" marked="false">
      <extracomment />
      <location />
      <comment>Reminder value in comboBox widget</comment>
      <extra-loc-engineeringenglish>Before %Ln hours</extra-loc-engineeringenglish>
      <source>%Ln hours before58</source>
      <translation testresult="false" keep="false">
        <numerusform plurality="a" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="">vi %Ln hour before</numerusform>
      </translation>
      <oldsource>%Ln hour before</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_3_val</extra-loc-positionid>
      <extra-loc-viewid>calendar_p5</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="yes" id="txt_calendar_setlabel_reminder_val_before_ln_minu" marked="false">
      <extracomment />
      <location />
      <comment>Reminder value in the combox Box widget</comment>
      <extra-loc-engineeringenglish>Before %Ln minutes</extra-loc-engineeringenglish>
      <source>%Ln minute before59</source>
      <translation testresult="false" keep="false">
        <numerusform plurality="a" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="">vi %Ln minute before</numerusform>
      </translation>
      <oldsource>%Ln minutes before</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_3_val</extra-loc-positionid>
      <extra-loc-viewid>calendar_p5</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="yes" id="txt_calendar_setlabel_reminder_val_before_ln_week" marked="false">
      <extracomment />
      <location />
      <comment>Reminder value in comboxBox widget</comment>
      <extra-loc-engineeringenglish>Before %Ln weeks</extra-loc-engineeringenglish>
      <source>%Ln weeks before60</source>
      <translation testresult="false" keep="false">
        <numerusform plurality="a" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="">vi %Ln week before</numerusform>
      </translation>
      <oldsource>%Ln week before</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_3_val</extra-loc-positionid>
      <extra-loc-viewid>calendar_p5</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat" marked="false">
      <extracomment />
      <location />
      <comment>Label item in event editor</comment>
      <extra-loc-engineeringenglish>Repeat</extra-loc-engineeringenglish>
      <source>Repeat61</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Repeat</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_heading_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_heading_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_400</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_4</extra-loc-positionid>
      <extra-loc-viewid>calendar_p5</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_until" marked="false">
      <extracomment />
      <location />
      <comment>Label item in event editor. Displayed only when repeat value is not equal to off/none</comment>
      <extra-loc-engineeringenglish>Repeat until</extra-loc-engineeringenglish>
      <source>Repeat until62</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Repeat until</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_400</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_5</extra-loc-positionid>
      <extra-loc-viewid>calendar_p5</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_biweekly" marked="false">
      <extracomment />
      <location />
      <comment>Repeat value in ComboBox widget</comment>
      <extra-loc-engineeringenglish>Bi-weekly</extra-loc-engineeringenglish>
      <source>Fortnightly63</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Fortnightly</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_4_val</extra-loc-positionid>
      <extra-loc-viewid>calendar_p5</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_daily" marked="false">
      <extracomment />
      <location />
      <comment>Repeat value in ComboBox widget</comment>
      <extra-loc-engineeringenglish>Daily</extra-loc-engineeringenglish>
      <source>Daily64</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Daily</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_4_val</extra-loc-positionid>
      <extra-loc-viewid>calendar_p5</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_monthly" marked="false">
      <extracomment />
      <location />
      <comment>Repeat value in ComboBox widget</comment>
      <extra-loc-engineeringenglish>Monthly</extra-loc-engineeringenglish>
      <source>Monthly65</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Monthly</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_4_val</extra-loc-positionid>
      <extra-loc-viewid>calendar_p5</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_only_once" marked="false">
      <extracomment />
      <location />
      <comment>Repeat value in ComboBox widget</comment>
      <extra-loc-engineeringenglish>Only once</extra-loc-engineeringenglish>
      <source>Not repeated66</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Not repeated</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_4_val</extra-loc-positionid>
      <extra-loc-viewid>calendar_p5</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_weekly" marked="false">
      <extracomment />
      <location />
      <comment>Repeat value in ComboBox widget</comment>
      <extra-loc-engineeringenglish>Weekly</extra-loc-engineeringenglish>
      <source>Weekly67</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Weekly</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_4_val</extra-loc-positionid>
      <extra-loc-viewid>calendar_p5</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_repeat_val_yearly" marked="false">
      <extracomment />
      <location />
      <comment>Repeat value in ComboBox widget</comment>
      <extra-loc-engineeringenglish>Yearly</extra-loc-engineeringenglish>
      <source>Yearly68</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Yearly</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_4_val</extra-loc-positionid>
      <extra-loc-viewid>calendar_p5</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_show_week_numbers" marked="false">
      <extracomment />
      <location />
      <comment>Settings item label  to show/hide week numbers in month view</comment>
      <extra-loc-engineeringenglish>Show week numbers</extra-loc-engineeringenglish>
      <source>Week numbers69</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi #Show week numbers</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_22</extra-loc-positionid>
      <extra-loc-viewid>calendar_p3</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_setlabel_to" marked="false">
      <extracomment />
      <location />
      <comment>"To" (End date and time) label in event editor</comment>
      <extra-loc-engineeringenglish>To</extra-loc-engineeringenglish>
      <source>To70</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi To</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_2</extra-loc-positionid>
      <extra-loc-viewid>calendar_p5</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="yes" id="txt_calendar_setlabel_val_ln_minutes" marked="false">
      <extracomment />
      <location />
      <comment>Alarm snooze time interval value in the combox setting</comment>
      <extra-loc-engineeringenglish>%Ln minutes</extra-loc-engineeringenglish>
      <source>%Ln minutes71</source>
      <translation testresult="false" keep="false">
        <numerusform plurality="a" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="">vi #%Ln minutes</numerusform>
      </translation>
      <oldsource>%Ln minute</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_description_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_description_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_11_val</extra-loc-positionid>
      <extra-loc-viewid>calendar_p3</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_subtitle_calendar_settings" marked="false">
      <extracomment />
      <location />
      <comment>Text displayed in the simple text label(GroupBOx)</comment>
      <extra-loc-engineeringenglish>Calendar settings</extra-loc-engineeringenglish>
      <source>Settings72</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Settings</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_groupbox_simple_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_groupbox_simple_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>290,NOT_291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>subtitle</extra-loc-positionid>
      <extra-loc-viewid>calendar_p3</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_subtitle_daydate" marked="false">
      <extracomment />
      <location />
      <comment>Day and Date will be displayed in the Simple groupBOX</comment>
      <extra-loc-engineeringenglish>&lt;Day&gt;&lt;Date&gt;</extra-loc-engineeringenglish>
      <source>Day date73</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Day date</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_groupbox_simple_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_groupbox_simple_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>subtitle</extra-loc-positionid>
      <extra-loc-viewid>calendar_p1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_subtitle_monthyear" marked="false">
      <extracomment />
      <location />
      <comment>Date and Year will be displayed in the simple groupbox(Subhead) . For eg: May 2009</comment>
      <extra-loc-engineeringenglish>&lt;Month&gt;&lt;Year&gt;</extra-loc-engineeringenglish>
      <source>Month year74</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Month year</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_groupbox_simple_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_groupbox_simple_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>subtitle</extra-loc-positionid>
      <extra-loc-viewid>calendar_p1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_subtitle_new_event" marked="false">
      <extracomment />
      <location />
      <comment>Subheading in the simple label groupBox</comment>
      <extra-loc-engineeringenglish>New event</extra-loc-engineeringenglish>
      <source>New entry75</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi New entry</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_groupbox_simple_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_groupbox_simple_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>42</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>subtitle</extra-loc-positionid>
      <extra-loc-viewid>calendar_p5</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_title_calendar" marked="false">
      <extracomment />
      <location />
      <comment>Calendar Application Title text</comment>
      <extra-loc-engineeringenglish>Calendar</extra-loc-engineeringenglish>
      <source>Calendar76</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Calendar</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_chrome_title</extra-loc-layout_id>
      <extra-loc-layout>qtl_chrome_title</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>41</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>calendar_p1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_title_end_date" marked="false">
      <extracomment />
      <location />
      <comment>Message header text for event "end date" dialog - Set end date using tumbler widget</comment>
      <extra-loc-engineeringenglish>End date</extra-loc-engineeringenglish>
      <source>End date77</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi End date</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>calendar_p11</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_title_end_time" marked="false">
      <extracomment />
      <location />
      <comment>Message header text for event "End time" dialog - Set end time using tumbler widget</comment>
      <extra-loc-engineeringenglish>End time</extra-loc-engineeringenglish>
      <source>End time78</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi End time</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>calendar_p11</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_title_start_date" marked="false">
      <extracomment />
      <location />
      <comment>Message header text for event "Start date" Dialog  - Set start date using tumbler widget</comment>
      <extra-loc-engineeringenglish>Start date</extra-loc-engineeringenglish>
      <source>Start date79</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Start date</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_320</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>calendar_p11</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_title_start_time" marked="false">
      <extracomment />
      <location />
      <comment>Message header text for evennt "Start time" dialog - Set start time using tumbler widget</comment>
      <extra-loc-engineeringenglish>Start time</extra-loc-engineeringenglish>
      <source>Start time80</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Start time</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_320</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>calendar_p11</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_toggle_no" marked="false">
      <extracomment />
      <location />
      <comment>Setting item to hide week numbers in month view. Tap to toggle values</comment>
      <extra-loc-engineeringenglish>No</extra-loc-engineeringenglish>
      <source>Hidden81</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi #No</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>?</extra-loc-layout_id>
      <extra-loc-layout>?</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_126</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>Toggle</extra-loc-positionid>
      <extra-loc-viewid>calendar_p3</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_calendar_toggle_yes" marked="false">
      <extracomment />
      <location />
      <comment>Setting item to showweek numbers in month view. Tap to toggle values</comment>
      <extra-loc-engineeringenglish>Yes</extra-loc-engineeringenglish>
      <source>Shown82</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi Shown</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>?</extra-loc-layout_id>
      <extra-loc-layout>?</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>Toggle</extra-loc-positionid>
      <extra-loc-viewid>calendar_p3</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_long_caption_calendar" marked="false">
      <extracomment />
      <location />
      <comment>Calendar long application name</comment>
      <extra-loc-engineeringenglish>Calendar</extra-loc-engineeringenglish>
      <source>Calendar83</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi #Calendar</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>calendar_p1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_short_caption_calendar" marked="false">
      <extracomment />
      <location />
      <comment>Calendar short application name</comment>
      <extra-loc-engineeringenglish>Calendar</extra-loc-engineeringenglish>
      <source>Calendar84</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">vi #Calendar</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_grid_applications_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_grid_applications_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>grid</extra-loc-positionid>
      <extra-loc-viewid>calendar_p1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
  </context>
</TS>