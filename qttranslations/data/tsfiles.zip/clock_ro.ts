<?xml version="1.0" encoding="utf-8"?>
<TS xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" version="1.0" sourcelanguage="English-GB" language="ro">
  <extra-loc-extended xsi:type="xsd:boolean">true</extra-loc-extended>
  <defaultcodec />
  <extra-loc-feature xsi:type="xsd:string">clock@dfsxx.01</extra-loc-feature>
  <extra-loc-style xsi:type="xsd:string">ts</extra-loc-style>
  <context>
    <name>Prophet</name>
    <message numerus="no" id="txt_clk_button_cityname_countryname" marked="false">
      <extracomment />
      <location />
      <comment>Tapping on this button opens City list to select city.</comment>
      <extra-loc-engineeringenglish>&lt;cityname, countryname&gt;</extra-loc-engineeringenglish>
      <source>Select city176</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography does not work between NTR and Trados" originaltestercomment="" originaltranslation="Selectare oraȘ">Selectare oraȘ</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>280</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_button_date" marked="false">
      <extracomment />
      <location />
      <comment>Tapping on this button opens date picker as a popup to edit time</comment>
      <extra-loc-engineeringenglish>&lt;date&gt;</extra-loc-engineeringenglish>
      <source>Select date177</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Selectare dată">Selectare dată</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>280</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_button_regional_date_time_settings" marked="false">
      <extracomment />
      <location />
      <comment>Tapping on this button opens advanced date and time view</comment>
      <extra-loc-engineeringenglish>Regional date &amp; time settings</extra-loc-engineeringenglish>
      <source>Advanced settings178</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Setări avansate">Setări avansate</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_groupbox_simple_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_groupbox_simple_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>290,NOT_291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_button_time" marked="false">
      <extracomment />
      <location />
      <comment>Tapping on this button opens time picker as a popup for editing the time</comment>
      <extra-loc-engineeringenglish>&lt;time&gt;</extra-loc-engineeringenglish>
      <source>Time179</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Oră">Oră</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_caption_clock" marked="false">
      <extracomment />
      <location />
      <comment>Caption for Clock in Task switcher</comment>
      <extra-loc-engineeringenglish>Clock</extra-loc-engineeringenglish>
      <source>Clock180</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ro Clock</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>cell_tport_appsw_pane_t1</extra-loc-layout_id>
      <extra-loc-layout>cell_tport_appsw_pane_t1</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>61</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>caption</extra-loc-positionid>
      <extra-loc-viewid>Clock</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_formlabel_description" marked="false">
      <extracomment />
      <location />
      <comment>Label for Description in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Description</extra-loc-engineeringenglish>
      <source>Description181</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Descriere">Descriere</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>formlabel_1</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_formlabel_place" marked="false">
      <extracomment />
      <location />
      <comment>5th label for Place in Clock settings view</comment>
      <extra-loc-engineeringenglish>Place:</extra-loc-engineeringenglish>
      <source>Location:182</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography does not work between NTR and Trados" originaltestercomment="" originaltranslation="LocaȚie:">LocaȚie:</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_heading_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_heading_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>543,NOT_544</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>formlabel_1</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_formlabel_time_format" marked="false">
      <extracomment />
      <location />
      <comment>Time format:</comment>
      <extra-loc-engineeringenglish>Time format:</extra-loc-engineeringenglish>
      <source>Time format:183</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Format oră:">Format oră:</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_heading_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_heading_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_3</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_formlabel_val_alarm" marked="false">
      <extracomment />
      <location />
      <comment>Default value for Description label in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Alarm</extra-loc-engineeringenglish>
      <source>Alarm184</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Alarmă">Alarmă</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_description_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_description_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_15,410</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>formlabel_1_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="yes" id="txt_clk_grid_lnln" marked="false">
      <extracomment />
      <location />
      <comment>When a city is added to the World Clock one line grid view in landscape mode, its relative time offset is displayed with respect to homecity.</comment>
      <extra-loc-engineeringenglish>&lt;-/+&gt;%Ln:%Ln</extra-loc-engineeringenglish>
      <source>&lt;-/+&gt;%Ln:%Ln185</source>
      <translation testresult="false" keep="false">
        <numerusform plurality="a" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="">ro #&lt;-/+&gt;%Ln:%Ln</numerusform>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id />
      <extra-loc-layout />
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>1-line grid</extra-loc-positionid>
      <extra-loc-viewid>Clock_World clock_L05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_line_grid_cityname" marked="false">
      <extracomment />
      <location />
      <comment>When a city is added to the World Clock one line grid view in landscape mode, its name is displayed.</comment>
      <extra-loc-engineeringenglish>&lt;cityname&gt;</extra-loc-engineeringenglish>
      <source>Add city186</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography does not work between NTR and Trados" originaltestercomment="" originaltranslation="Adăugare oraȘ">Adăugare oraȘ</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>1-line grid</extra-loc-positionid>
      <extra-loc-viewid>Clock_World clock_L05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_line_grid_date" marked="false">
      <extracomment />
      <location />
      <comment>When a city is added to the World Clock one line grid view in landscape mode, its date is displayed</comment>
      <extra-loc-engineeringenglish>&lt;date&gt;</extra-loc-engineeringenglish>
      <source>Date187</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Dată">Dată</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>1-line grid</extra-loc-positionid>
      <extra-loc-viewid>Clock_World clock_L05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_abidjan_cotedIvoire" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Abidjan, Cote d'Ivoire</extra-loc-engineeringenglish>
      <source>Abidjan, Côte d'Ivoire188</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Abidjan, Republica Côte d'Ivoire">Abidjan, Republica Côte d'Ivoire</lengthvariant>
      </translation>
      <oldsource>Abidjan, Cote d'Ivoire</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_abu_dhabi_uae" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Abu Dhabi, United Arab Emirates</extra-loc-engineeringenglish>
      <source>Abu Dhabi, United Arab Emirates189</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="CR ignored, as instructed" originaltestercomment="" originaltranslation="Abu Dhabi, Emiratele Arabe Unite">Abu Dhabi, Emiratele Arabe Unite</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_abuja_nigeria" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Abuja, Nigeria</extra-loc-engineeringenglish>
      <source>Abuja, Nigeria190</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Abuja, Nigeria">Abuja, Nigeria</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_accra_ghana" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Accra, Ghana</extra-loc-engineeringenglish>
      <source>Accra, Ghana191</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Accra, Ghana">Accra, Ghana</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_acre_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Acre, Brazil</extra-loc-engineeringenglish>
      <source>Acre, Brazil192</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Acre, Brazilia">Acre, Brazilia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_adak_ak_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Adak, AK, United States of America</extra-loc-engineeringenglish>
      <source>Adak, AK, United States of America193</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="CR error ignored, as instructed" originaltestercomment="" originaltranslation="Adak, AK, Statele Unite ale Americii">Adak, AK, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Adak, AK, United States of America</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_adamstown_pitcairn_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Adamstown, Pitcairn Islands</extra-loc-engineeringenglish>
      <source>Adamstown, Pitcairn Islands194</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Adamstown, Insulele Pitcairn">Adamstown, Insulele Pitcairn</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Adamstown, Pitcairn Islands</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_addis _ababa_ethiopia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Addis Ababa, Ethiopia</extra-loc-engineeringenglish>
      <source>Addis Ababa, Ethiopia195</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Addis Abeba, Etiopia">Addis Abeba, Etiopia</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Addis Ababa, Ethiopia</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_adelaide_aus" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Adelaide, Australia</extra-loc-engineeringenglish>
      <source>Adelaide, Australia196</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Adelaide, Australia">Adelaide, Australia</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Adelaide, Australia</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_agana, guam" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Agana, Guam</extra-loc-engineeringenglish>
      <source>Agana, Guam197</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Agana, Guam">Agana, Guam</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Agana, Guam</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_aktau_kaz" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Aktau, Kazakhstan</extra-loc-engineeringenglish>
      <source>Aktau, Kazakhstan198</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Aktau, Kazahstan">Aktau, Kazahstan</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Aktau, Kazakhstan</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_albuquerque_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Albuquerque, United States of America</extra-loc-engineeringenglish>
      <source>Albuquerque, United States of America199</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="CR error ignored, as instructed" originaltestercomment="" originaltranslation="Albuquerque, Statele Unite ale Americii">Albuquerque, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Albuquerque, United States of America</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_algiers_algeria" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Algiers, Algeria</extra-loc-engineeringenglish>
      <source>Algiers, Algeria200</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Alger, Algeria">Alger, Algeria</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Algiers, Algeria</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_alofi_niue" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Alofi, Niue</extra-loc-engineeringenglish>
      <source>Alofi, Niue201</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Alofi, Niue">Alofi, Niue</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Alofi, Niue</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_amman_jordan" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Amman, Jordan</extra-loc-engineeringenglish>
      <source>Amman, Jordan202</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Amman, Iordania">Amman, Iordania</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Amman, Jordan</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_amsterdam_netherlands" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Amsterdam, Netherlands</extra-loc-engineeringenglish>
      <source>Amsterdam, Netherlands203</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Amsterdam, Olanda">Amsterdam, Olanda</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Amsterdam, Netherlands</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_anadyr_russia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Anadyr, Russia</extra-loc-engineeringenglish>
      <source>Anadyr, Russia204</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Anadîr, Rusia">Anadîr, Rusia</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Anadyr, Russia</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_andorra_la_vella_andorra" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Andorra La Vella, Andorra</extra-loc-engineeringenglish>
      <source>Andorra La Vella, Andorra205</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Andorra La Vella, Andorra">Andorra La Vella, Andorra</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Andorra La Vella, Andorra</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_ankara_turkey" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Ankara, Turkey</extra-loc-engineeringenglish>
      <source>Ankara, Turkey206</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ankara, Turcia">Ankara, Turcia</lengthvariant>
      </translation>
      <oldsource>&lt;TR-PLACEHOLDER&gt;Ankara, TurkeyAnkara, Turkey</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_antananarivo_madagascar" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Antananarivo, Madagascar</extra-loc-engineeringenglish>
      <source>Antananarivo, Madagascar207</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Antananarivo, Madagascar">Antananarivo, Madagascar</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_apia samoa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Apia, Samoa</extra-loc-engineeringenglish>
      <source>Apia, Samoa208</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Apia, Samoa">Apia, Samoa</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_aracaju_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Aracaju, Brazil</extra-loc-engineeringenglish>
      <source>Aracaju, Brazil209</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Aracaju, Brazilia">Aracaju, Brazilia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_araguaina_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Araguaina, Brazil</extra-loc-engineeringenglish>
      <source>Araguaina, Brazil210</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Araguaina, Brazilia">Araguaina, Brazilia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_ashgabat_turkmenistan" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Ashgabat, Turkmenistan</extra-loc-engineeringenglish>
      <source>Ashgabat, Turkmenistan211</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography is incompatible between NTR and Trados" originaltestercomment="" originaltranslation="AȘgabat, Turkmenistan">AȘgabat, Turkmenistan</lengthvariant>
      </translation>
      <oldsource>Ashgabat. Turkmenistan</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_asmara_eritrea" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Asmara, Eritrea</extra-loc-engineeringenglish>
      <source>Asmara, Eritrea212</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Asmara, Eritreea">Asmara, Eritreea</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_astana_kaz" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Astana, Kazakhstan</extra-loc-engineeringenglish>
      <source>Astana, Kazakhstan213</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Astana, Kazahstan">Astana, Kazahstan</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_asuncion_paraguay" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Asuncion, Paraguay</extra-loc-engineeringenglish>
      <source>Asunción, Paraguay214</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Asunción, Paraguay">Asunción, Paraguay</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_atikokan_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Atikokan, Canada</extra-loc-engineeringenglish>
      <source>Atikokan, Canada215</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Atikokan, Canada">Atikokan, Canada</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_atlanta_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Atlanta, United States of America</extra-loc-engineeringenglish>
      <source>Atlanta, GA, United States of America216</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="CR error ignored, as instructed" originaltestercomment="" originaltranslation="Atlanta, GA, Statele Unite ale Americii">Atlanta, GA, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_auckland_nz" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Auckland, Newzealand</extra-loc-engineeringenglish>
      <source>Auckland, New Zealand217</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Auckland, Noua Zeelandă">Auckland, Noua Zeelandă</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_augusta_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Augusta, United States of America</extra-loc-engineeringenglish>
      <source>Augusta, ME, United States of America218</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="CR error ignored, as instructed" originaltestercomment="" originaltranslation="Augusta, ME, Statele Unite ale Americii">Augusta, ME, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_avarua_cook_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Avarua, Cook Islands</extra-loc-engineeringenglish>
      <source>Avarua, Cook Islands219</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Avarua, Insulele Cook">Avarua, Insulele Cook</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_baghdad_iraq" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Baghdad, Iraq</extra-loc-engineeringenglish>
      <source>Baghdad, Iraq220</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Bagdad, Irak">Bagdad, Irak</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_baku_azerb" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Baku, Azerbaijan</extra-loc-engineeringenglish>
      <source>Baku, Azerbaijan221</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Baku, Azerbaidjan">Baku, Azerbaidjan</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_baltimore_md_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Baltimore, MD, United States of America</extra-loc-engineeringenglish>
      <source>Baltimore, MD, United States of America222</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="CR error ignored, as instructed" originaltestercomment="" originaltranslation="Baltimore, MD, Statele Unite ale Americii">Baltimore, MD, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_bamako_mali" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Bamako, Mali</extra-loc-engineeringenglish>
      <source>Bamako, Mali223</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Bamako, Mali">Bamako, Mali</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_bandar_seri_begawan_brunei" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Bandar Seri Begawan, Brunei</extra-loc-engineeringenglish>
      <source>Bandar Seri Begawan, Brunei224</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Bandar Seri Begawan, Brunei">Bandar Seri Begawan, Brunei</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_bangkok_thai" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Bangkok, Thailand</extra-loc-engineeringenglish>
      <source>Bangkok, Thailand225</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Bangkok, Thailanda">Bangkok, Thailanda</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_bangui_car" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Bangui, Central African Republic</extra-loc-engineeringenglish>
      <source>Bangul, Central African Republic226</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Bangui, Republica Centrafricană">Bangui, Republica Centrafricană</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_banjul_gambia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Banjul, Gambia</extra-loc-engineeringenglish>
      <source>Banjul, Gambia227</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Banjul, Gambia">Banjul, Gambia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_basse_terre_guadeloupe" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Basse-Terre, Guadeloupe</extra-loc-engineeringenglish>
      <source>Basse-Terre, Guadeloupe228</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Basse-Terre, Guadelupa">Basse-Terre, Guadelupa</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_beijing_china" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Beijing, China</extra-loc-engineeringenglish>
      <source>Beijing, China229</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Beijing, China">Beijing, China</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_beirut_lebanon" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Beirut, Lebanon</extra-loc-engineeringenglish>
      <source>Beirut, Lebanon230</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Beirut, Liban">Beirut, Liban</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_belem_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Belem, Brazil</extra-loc-engineeringenglish>
      <source>Belem, Brazil231</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Belem, Brazilia">Belem, Brazilia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_belfast_ireland" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Belfast, Ireland</extra-loc-engineeringenglish>
      <source>Belfast, Northern Ireland232</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Belfast, Irlanda de Nord">Belfast, Irlanda de Nord</lengthvariant>
      </translation>
      <oldsource>Belfast, Ireland</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_belgrade_serbia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Belgrade, Serbia</extra-loc-engineeringenglish>
      <source>Belgrade, Serbia233</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Belgrad, Serbia">Belgrad, Serbia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_belmopan_belize" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Belmopan, Belize</extra-loc-engineeringenglish>
      <source>Belmopan, Belize234</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Belmopan, Belize">Belmopan, Belize</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_belo_horizonte_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Belo Horizonte, Brazil</extra-loc-engineeringenglish>
      <source>Belo Horizonte, Brazil235</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Belo Horizonte, Brazilia">Belo Horizonte, Brazilia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_berlin_germany" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Berlin, Germany</extra-loc-engineeringenglish>
      <source>Berlin, Germany236</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Berlin, Germania">Berlin, Germania</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_bern_switz" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Bern, Switzerland</extra-loc-engineeringenglish>
      <source>Bern, Switzerland237</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography is incompatible between NTR and Trados" originaltestercomment="" originaltranslation="Berna, ElveȚia">Berna, ElveȚia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_billings_mt_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Billings, MT, United States of America</extra-loc-engineeringenglish>
      <source>Billings, MT, United States of America238</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="CR error ignored, as instructed" originaltestercomment="" originaltranslation="Billings, MT, Statele Unite ale Americii">Billings, MT, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_birmingham_al_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Birmingham, AL, United States of America</extra-loc-engineeringenglish>
      <source>Birmingham, AL, United States of America239</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="CR error ignored, as instructed" originaltestercomment="" originaltranslation="Birmingham, AL, Statele Unite ale Americii">Birmingham, AL, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_bishkek_kyrgyzstan" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Bishkek, Kyrgyzstan</extra-loc-engineeringenglish>
      <source>Bishkek, Kyrgyzstan240</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography is incompatible between NTR and Trados" originaltestercomment="" originaltranslation="BiȘkek, Kârgâzstan">BiȘkek, Kârgâzstan</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_bismarck_nd_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Bismarck, ND, United States of America</extra-loc-engineeringenglish>
      <source>Bismarck, ND, United States of America241</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="CR error ignored, as instructed" originaltestercomment="" originaltranslation="Bismarck, ND, Statele Unite ale Americii">Bismarck, ND, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_bissau_guinea_bissau" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Bissau, Guinea-Bissau</extra-loc-engineeringenglish>
      <source>Bissau, Guinea-Bissau242</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Bissau, Guineea-Bissau">Bissau, Guineea-Bissau</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_blanc_sablon_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Blanc-Sablon, Canada</extra-loc-engineeringenglish>
      <source>Blanc-Sablon, Canada243</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Blanc-Sablon, Canada">Blanc-Sablon, Canada</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_boa_vista_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Boa Vista, Brazil</extra-loc-engineeringenglish>
      <source>Boa Vista, Brazil244</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Boa Vista, Brazilia">Boa Vista, Brazilia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_bogota_colombia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Bogota, Colombia</extra-loc-engineeringenglish>
      <source>Bogotá, Colombia245</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Bogotá, Columbia">Bogotá, Columbia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_boise_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Boise, United States of America</extra-loc-engineeringenglish>
      <source>Boise, ID, United States of America246</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Boise, ID, Statele Unite ale Americii">Boise, ID, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_boston_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Boston, United States of America</extra-loc-engineeringenglish>
      <source>Boston, MA, Untied States of America247</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Boston, MA, Statele Unite ale Americii">Boston, MA, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_brasilia_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Brasilia, Brazil</extra-loc-engineeringenglish>
      <source>Brasilia, Brazil248</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Brasilia, Brazilia">Brasilia, Brazilia</lengthvariant>
      </translation>
      <oldsource>Brasilia. Brazil</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_bratislava_slovakia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Bratislava, Slovakia</extra-loc-engineeringenglish>
      <source>Bratislava, Slovakia249</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Bratislava, Slovacia">Bratislava, Slovacia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_brazzaville_drc" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Brazzaville, Democratic Republic of the Congo</extra-loc-engineeringenglish>
      <source>Brazzaville, Congo, Republic of the250</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that Brazzaville is the capital of the Republic of Congo, not the DR of Congo (whose capital is Kinshasa)" originaltestercomment="" originaltranslation="Brazzaville, Congo, Republica">Brazzaville, Congo, Republica</lengthvariant>
      </translation>
      <oldsource>Brazzaville, Congo, Democratic Republic of the</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_bridgetown_barbados" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Bridgetown, Barbados</extra-loc-engineeringenglish>
      <source>Bridgetown, Barbados251</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Bridgetown, Barbados">Bridgetown, Barbados</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_brisbane_aus" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Brisbane, Australia</extra-loc-engineeringenglish>
      <source>Brisbane, Australia252</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Brisbane, Australia">Brisbane, Australia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_brussels_belgium" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Brussels, Belgium</extra-loc-engineeringenglish>
      <source>Brussels, Belgium253</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Bruxelles, Belgia">Bruxelles, Belgia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_bucharest_romania" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Bucharest, Romania</extra-loc-engineeringenglish>
      <source>Bucharest, Romania254</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography is incompatible between NTR and Trados" originaltestercomment="" originaltranslation="BucureȘti, România">BucureȘti, România</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_budapest_hungary" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Budapest, Hungary</extra-loc-engineeringenglish>
      <source>Budapest, Hungary255</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Budapesta, Ungaria">Budapesta, Ungaria</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_buenos_aires_argen" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Buenos Aires, Argentina</extra-loc-engineeringenglish>
      <source>Buenos Aires, Argentina256</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Buenos Aires, Argentina">Buenos Aires, Argentina</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_bujumbura_burundi" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Bujumbura, Burundi</extra-loc-engineeringenglish>
      <source>Bujumbura, Burundi257</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Bujumbura, Burundi">Bujumbura, Burundi</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_cairo_egypt" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Cairo, Egypt</extra-loc-engineeringenglish>
      <source>Cairo, Egypt258</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Cairo, Egipt">Cairo, Egipt</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_calgary_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Calgary, Canada</extra-loc-engineeringenglish>
      <source>Calgary, Canada259</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Calgary, Canada">Calgary, Canada</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_cambridge_bay_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Cambridge Bay, Canada</extra-loc-engineeringenglish>
      <source>Cambridge Bay, Canada260</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Cambridge Bay, Canada">Cambridge Bay, Canada</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_campo_grande_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Campo Grande, Brazil</extra-loc-engineeringenglish>
      <source>Campo Grande, Brazil261</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Campo Grande, Brazilia">Campo Grande, Brazilia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_canberra_aus" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Canberra, Australia</extra-loc-engineeringenglish>
      <source>Canberra, Australia262</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Canberra, Australia">Canberra, Australia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_caracas_venezuela" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Caracas, Venezuela</extra-loc-engineeringenglish>
      <source>Caracas, Venezuela263</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Caracas, Venezuela">Caracas, Venezuela</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_cardiff_uk" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Cardiff, United Kingdom</extra-loc-engineeringenglish>
      <source>Cardiff, United Kingdom264</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Cardiff, Regatul Unit">Cardiff, Regatul Unit</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_casablanca_morocco" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Casablanca, Morocco</extra-loc-engineeringenglish>
      <source>Casablanca, Morocco265</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Casablanca, Maroc">Casablanca, Maroc</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_castries_st_lucia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Castries, St. Lucia</extra-loc-engineeringenglish>
      <source>Castries, St. Lucia266</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Castries, St. Lucia">Castries, St. Lucia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_cayenne_french_guiana" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Cayenne, French Guiana</extra-loc-engineeringenglish>
      <source>Cayenne, French Guiana267</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Cayenne, Guyana Franceză">Cayenne, Guyana Franceză</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_charleston_wv_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Charleston, WV, United States of America</extra-loc-engineeringenglish>
      <source>Charleston, WV, United States of America268</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Charleston, WV, Statele Unite ale Americii">Charleston, WV, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_charlotte_amalie_vi_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Charlotte Amalie, VI, United States of America</extra-loc-engineeringenglish>
      <source>Charlotte Amalie, VI, United States of America269</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Charlotte Amalie, VI, Statele Unite ale Americii">Charlotte Amalie, VI, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_charlotte_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Charlotte, United States of America</extra-loc-engineeringenglish>
      <source>Charlotte, NC, United States of America270</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Charlotte, NC, Statele Unite ale Americii">Charlotte, NC, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_charlottetown_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Charlottetown, Canada</extra-loc-engineeringenglish>
      <source>Charlottetown, Canada271</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Charlottetown, Canada">Charlottetown, Canada</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_chatham_newz" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Chatham, Newzealand</extra-loc-engineeringenglish>
      <source>Chatham, New Zealand272</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Chatham, Noua Zeelandă">Chatham, Noua Zeelandă</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_chennai_india" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Chennai, India</extra-loc-engineeringenglish>
      <source>Chennai, India273</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Chennai, India">Chennai, India</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_cheyenne_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Cheyenne, United States of America</extra-loc-engineeringenglish>
      <source>Cheyenne, WY, United States of America274</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Cheyenne, WY, Statele Unite ale Americii">Cheyenne, WY, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_chicago_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Chicago, United States of America</extra-loc-engineeringenglish>
      <source>Chicago, IL, United States of America275</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Chicago, IL, Statele Unite ale Americii">Chicago, IL, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_chihuahua_mexico" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Chihuahua, Mexico</extra-loc-engineeringenglish>
      <source>Chihuahua, Mexico276</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Chihuahua, Mexic">Chihuahua, Mexic</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_chisinau_moldova" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Chisinau, Moldova</extra-loc-engineeringenglish>
      <source>Chisinau, Moldova277</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography is incompatible between NTR and Trados" originaltestercomment="" originaltranslation="ChiȘinău, Moldova">ChiȘinău, Moldova</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_choibalsan_mongolia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Choibalsan, Mongolia</extra-loc-engineeringenglish>
      <source>Choybalsan, Mongolia278</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Choybalsan, Mongolia">Choybalsan, Mongolia</lengthvariant>
      </translation>
      <oldsource>Choybalsan, Mongolia&lt;TR-PLACEHOLDER&gt;</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_city_name_country_name" marked="false">
      <extracomment />
      <location />
      <comment>After user adds a city to the World clock list view, the city name and country name is displayed.</comment>
      <extra-loc-engineeringenglish>&lt;city name, country name&gt;</extra-loc-engineeringenglish>
      <source>Add city279</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography does not work between NTR and Trados" originaltestercomment="" originaltranslation="Adăugare oraȘ">Adăugare oraȘ</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_World clock_P05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_cockburn_town_turks_and_caicos_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Cockburn Town, </extra-loc-engineeringenglish>
      <source>Cockburn Town, Turks and Caicos Islands280</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography is incompatible between NTR and Trados" originaltestercomment="" originaltranslation="Cockburn Town, Insulele Turks Și Caicos">Cockburn Town, Insulele Turks Și Caicos</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_colombo_srilanka" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Colombo, Srilanka</extra-loc-engineeringenglish>
      <source>Colombo, Sri Lanka281</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Colombo, Sri Lanka">Colombo, Sri Lanka</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_colonia_micronesia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Colonia, Micronesia</extra-loc-engineeringenglish>
      <source>Colonia, Micronesia282</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Colonia, Micronezia">Colonia, Micronezia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_columbia_sc_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Columbia, SC, United States of America</extra-loc-engineeringenglish>
      <source>Columbia, SC, United States of America283</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Columbia, SC, Statele Unite ale Americii">Columbia, SC, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_columbus_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Columbus, United States of America</extra-loc-engineeringenglish>
      <source>Columbus, OH, United States of America284</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Columbus, OH, Statele Unite ale Americii">Columbus, OH, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_conakry_guinea" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Conakry, Guinea</extra-loc-engineeringenglish>
      <source>Conakry, Guinea285</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Conakry, Guineea">Conakry, Guineea</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_concord_nh_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Concord, NH, United States of America</extra-loc-engineeringenglish>
      <source>Concord, NH, United States of America286</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Concord, NH, Statele Unite ale Americii">Concord, NH, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_copenhagen_denmark" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Copenhagen, Denmark</extra-loc-engineeringenglish>
      <source>Copenhagen, Denmark287</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Copenhaga, Danemarca">Copenhaga, Danemarca</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_coral_harbour_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Coral Harbour, Canada</extra-loc-engineeringenglish>
      <source>Coral Harbour, Canada288</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Coral Harbour, Canada">Coral Harbour, Canada</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_cranbrook_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Cranbrook, Canada</extra-loc-engineeringenglish>
      <source>Cranbrook, Canada289</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Cranbrook, Canada">Cranbrook, Canada</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_creighton_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Creighton, Canada</extra-loc-engineeringenglish>
      <source>Creighton, Canada290</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Creighton, Canada">Creighton, Canada</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_cuiaba_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Cuiaba, Brazil</extra-loc-engineeringenglish>
      <source>Cuiaba, Brazil291</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Cuiaba, Brazilia">Cuiaba, Brazilia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_curitiba_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Curitiba, Brazil</extra-loc-engineeringenglish>
      <source>Curitiba, Brazil292</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Curitiba, Brazilia">Curitiba, Brazilia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_dakar_senegal" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Dakar, Senegal</extra-loc-engineeringenglish>
      <source>Dakar, Senegal293</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Dakar, Senegal">Dakar, Senegal</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_dallas_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Dallas, United States of America</extra-loc-engineeringenglish>
      <source>Dallas, TX, United States of America294</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Dallas, TX, Statele Unite ale Americii">Dallas, TX, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_damascus_syria" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Damascus, Syria</extra-loc-engineeringenglish>
      <source>Damascus, Syria295</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Damasc, Siria">Damasc, Siria</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_danmarkshavn_greenland" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Danmarkshavn, Greenland</extra-loc-engineeringenglish>
      <source>Danmarkshavn, Greenland296</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Danmarkshavn, Groenlanda">Danmarkshavn, Groenlanda</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_dar_es_salaam_tanzania" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Dar es Salaam, Tanzania</extra-loc-engineeringenglish>
      <source>Dar es Salaam, Tanzania297</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Dar es Salaam, Tanzania">Dar es Salaam, Tanzania</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_darwin_aus" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Darwin, Australia</extra-loc-engineeringenglish>
      <source>Darwin, Australia298</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Darwin, Australia">Darwin, Australia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_date" marked="false">
      <extracomment />
      <location />
      <comment>When a city is added to the World Clock list view, the city's current date is displayed.</comment>
      <extra-loc-engineeringenglish>&lt;date&gt;</extra-loc-engineeringenglish>
      <source>Date299</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Dată">Dată</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_World clock_P05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_dawson_creek_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Dawson Creek, Canada</extra-loc-engineeringenglish>
      <source>Dawson Creek, Canada300</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Dawson Creek, Canada">Dawson Creek, Canada</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_denver_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Denver, United States of America</extra-loc-engineeringenglish>
      <source>Denver, CO, United States of America301</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Denver, CO, Statele Unite ale Americii">Denver, CO, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_des_moines_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Des Moines, United States of America</extra-loc-engineeringenglish>
      <source>Des Moines, IA, United States of America302</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Des Moines, IA, Statele Unite ale Americii">Des Moines, IA, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_detroit_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Detroit, United States of America</extra-loc-engineeringenglish>
      <source>Detroit, United States of America303</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Detroit, Statele Unite ale Americii">Detroit, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_dhaka_bangla" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Dhaka, Bangladesh</extra-loc-engineeringenglish>
      <source>Dhaka, Bangladesh304</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Dhaka, Bangladesh">Dhaka, Bangladesh</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_diego_garcia_chagos_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Diego Garcia, Chagos Islands</extra-loc-engineeringenglish>
      <source>Diego Garcia, Chagos Archipelago305</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Diego Garcia, Arhipelagul Chagos">Diego Garcia, Arhipelagul Chagos</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_dili_east_timor" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Dili, East Timor</extra-loc-engineeringenglish>
      <source>Dili, East Timor306</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Dili, Timorul de Est">Dili, Timorul de Est</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_djibouti_djibouti" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Djibouti, Djibouti</extra-loc-engineeringenglish>
      <source>Djibouti, Djibouti307</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Djibouti, Djibouti">Djibouti, Djibouti</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_doha_qatar" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Doha, Qatar</extra-loc-engineeringenglish>
      <source>Doha, Qatar308</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Doha, Qatar">Doha, Qatar</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_dover_de_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Dover, DE, United States of America</extra-loc-engineeringenglish>
      <source>Dover, DE, United States of America309</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Dover, DE, Statele Unite ale Americii">Dover, DE, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_dublin_ireland" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Dublin, Ireland</extra-loc-engineeringenglish>
      <source>Dublin, Ireland310</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Dublin, Irlanda">Dublin, Irlanda</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_dushanbe_tajikistan" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Dushanbe, Tajikistan</extra-loc-engineeringenglish>
      <source>Dushanbe, Tajikistan311</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography is incompatible between NTR and Trados" originaltestercomment="" originaltranslation="DuȘanbe, Tadjikistan">DuȘanbe, Tadjikistan</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_edinburgh_uk" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Edinburgh, United Kingdom</extra-loc-engineeringenglish>
      <source>Edinburgh, United Kingdom312</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Edinburgh, Regatul Unit">Edinburgh, Regatul Unit</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_edmonton_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Edmonton, Canada</extra-loc-engineeringenglish>
      <source>Edmonton, Canada313</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Edmonton, Canada">Edmonton, Canada</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_eucla_aus" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Eucla, Australia</extra-loc-engineeringenglish>
      <source>Eucla, Australia314</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Eucla, Australia">Eucla, Australia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_evansville_in_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Evansville, IN, United States of America</extra-loc-engineeringenglish>
      <source>Evansville, IN, United States of America315</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Evansville, IN, Statele Unite ale Americii">Evansville, IN, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_fakaofo_tokelau" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Fakaofo, Tokelau</extra-loc-engineeringenglish>
      <source>Fakaofo, Tokelau316</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Fakaofo, Tokelau">Fakaofo, Tokelau</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_fernando_de_noronha_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Fernando de Noronha, Brazil</extra-loc-engineeringenglish>
      <source>Fernando de Noronha, Brazil317</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Fernando de Noronha, Brazilia">Fernando de Noronha, Brazilia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_fort_de_france_martinique" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Fort-de-France, Martinique</extra-loc-engineeringenglish>
      <source>Fort-de-France, Martinique318</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Fort-de-France, Martinica">Fort-de-France, Martinica</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_fortaleza_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Fortaleza, Brazil</extra-loc-engineeringenglish>
      <source>Fortaleza, Brazil319</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Fortaleza, Brazilia">Fortaleza, Brazilia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_freetown_sierra_leone" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Freetown, Sierra Leone</extra-loc-engineeringenglish>
      <source>Freetown, Sierra Leone320</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Freetown, Sierra Leone">Freetown, Sierra Leone</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_funafuti_tuvalu" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Funafuti, Tuvalu</extra-loc-engineeringenglish>
      <source>Funafuti, Tuvalu321</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Funafuti, Tuvalu">Funafuti, Tuvalu</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_funchal_madeira" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Funchal, Madeira</extra-loc-engineeringenglish>
      <source>Funchal, Madeira322</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Funchal, Madeira">Funchal, Madeira</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_gaborone_botswana" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Gaborone, Botswana</extra-loc-engineeringenglish>
      <source>Gaborone, Botswana323</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Gaborone, Botswana">Gaborone, Botswana</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_gambier_isl_french_polynesia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Gambier Islands, French Polynesia</extra-loc-engineeringenglish>
      <source>Gambier Islands, French Polynesia324</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Insulele Gambier, Polinezia Franceză">Insulele Gambier, Polinezia Franceză</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_gary_in_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Gary, IN, United States of America</extra-loc-engineeringenglish>
      <source>Gary, IN, United States of America325</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Gary, IN, Statele Unite ale Americii">Gary, IN, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_george_town_cayman_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>George Town, Cayman Islands</extra-loc-engineeringenglish>
      <source>George Town, Cayman Islands326</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="George Town, Insulele Cayman">George Town, Insulele Cayman</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_georgetown_guyana" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Georgetown, Guyana</extra-loc-engineeringenglish>
      <source>Georgetown, Guyana327</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Georgetown, Guyana">Georgetown, Guyana</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_gibraltar_gibraltar" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Gibraltar, Gibraltar</extra-loc-engineeringenglish>
      <source>Gibraltar, Gibraltar328</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Gibraltar, Gibraltar">Gibraltar, Gibraltar</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_goiania_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Goiania, Brazil</extra-loc-engineeringenglish>
      <source>Goiania, Brazil329</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Goiania, Brazilia">Goiania, Brazilia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_greece_athens" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Athens, Greece</extra-loc-engineeringenglish>
      <source>Athens, Greece330</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Atena, Grecia">Atena, Grecia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_grytviken_south_georgia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Grytviken, South Georgia</extra-loc-engineeringenglish>
      <source>Grytviken, South Georgia331</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Grytviken, Georgia de Sud">Grytviken, Georgia de Sud</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_guam_mp_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Guam, MP, United States of America</extra-loc-engineeringenglish>
      <source>Guam, MP, United States of America332</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Guam, MP, Statele Unite ale Americii">Guam, MP, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_guatemala_guatemala" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Guatemala, Guatemala</extra-loc-engineeringenglish>
      <source>Guatemala, Guatemala333</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Guatemala, Guatemala">Guatemala, Guatemala</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_hagatna_guam" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Hagatna, Guam</extra-loc-engineeringenglish>
      <source>Hagatna, Guam334</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Hagatna, Guam">Hagatna, Guam</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_halifax_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Halifax, Canada</extra-loc-engineeringenglish>
      <source>Halifax, Canada335</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Halifax, Canada">Halifax, Canada</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_hamilton_bermuda" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Hamilton, Bermuda</extra-loc-engineeringenglish>
      <source>Hamilton, Bermuda336</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Hamilton, Bermuda">Hamilton, Bermuda</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_hanga_roa_easter_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Hanga Roa, Easter Island</extra-loc-engineeringenglish>
      <source>Hanga Roa, Easter Island337</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography is incompatible between NTR and Trados" originaltestercomment="" originaltranslation="Hanga Roa, Insula PaȘtelui">Hanga Roa, Insula PaȘtelui</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_hanoi_vietnam" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Hanoi, Vietnam</extra-loc-engineeringenglish>
      <source>Hanoi, Vietnam338</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Hanoi, Vietnam">Hanoi, Vietnam</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_harare_zimbabwe" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Harare, Zimbabwe</extra-loc-engineeringenglish>
      <source>Harare, Zimbabwe339</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Harare, Zimbabwe">Harare, Zimbabwe</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_hartford_ct_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Hartford, CT, United States of America</extra-loc-engineeringenglish>
      <source>Hartford, CT, United States of America340</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Hartford, CT, Statele Unite ale Americii">Hartford, CT, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_havana_cuba" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Havana, Cuba</extra-loc-engineeringenglish>
      <source>Havana, Cuba341</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Havana, Cuba">Havana, Cuba</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_helsinki_finland" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Helsinki, Finland</extra-loc-engineeringenglish>
      <source>Helsinki, Finland342</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Helsinki, Finlanda">Helsinki, Finlanda</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_hobart_aus" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Hobart, Australia</extra-loc-engineeringenglish>
      <source>Hobart, Australia343</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Hobart, Australia">Hobart, Australia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_holy_see_vatican_city" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Holy See, Vatican City</extra-loc-engineeringenglish>
      <source>Holy See, Vatican City344</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography is incompatible between NTR and Trados" originaltestercomment="" originaltranslation="Sfântul Scaun, OraȘul Vatican">Sfântul Scaun, OraȘul Vatican</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_hong_kong_victoria" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Hong kong, Victoria</extra-loc-engineeringenglish>
      <source>Hong Kong, Victoria345</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Hong Kong, Victoria">Hong Kong, Victoria</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_honiara_solomon_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Honiara, Solomon Islands</extra-loc-engineeringenglish>
      <source>Honiara, Solomon Islands346</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Honiara, Insulele Solomon">Honiara, Insulele Solomon</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_honolulu_hi_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Honolulu, HI, United States of America</extra-loc-engineeringenglish>
      <source>Honolulu, HI, United States of America347</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Honolulu, HI, Statele Unite ale Americii">Honolulu, HI, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_hovd_mongolia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Hovd, Mongolia</extra-loc-engineeringenglish>
      <source>Hovd, Mongolia348</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Hovd, Mongolia">Hovd, Mongolia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_indianapolis_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Indianapolis, United States of America</extra-loc-engineeringenglish>
      <source>Indianapolis, IN, United States of America349</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Indianapolis, IN, Statele Unite ale Americii">Indianapolis, IN, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_iqaluit_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Iqaluit, Canada</extra-loc-engineeringenglish>
      <source>Iqaluit, Canada350</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Iqaluit, Canada">Iqaluit, Canada</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_irkutsk_russia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Irkutsk, Russia</extra-loc-engineeringenglish>
      <source>Irkutsk, Russia351</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Irkutsk, Rusia">Irkutsk, Rusia</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_islamabad_pak" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Islamabad, Pakistan</extra-loc-engineeringenglish>
      <source>Islamabad, Pakistan352</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Islamabad, Pakistan">Islamabad, Pakistan</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_istanbul_turkey" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Istanbul, Turkey</extra-loc-engineeringenglish>
      <source>Istanbul, Turkey353</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Istanbul, Turcia">Istanbul, Turcia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_jakarta_indonesia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Jakarta, Indonesia</extra-loc-engineeringenglish>
      <source>Jakarta, Indonesia354</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Jakarta, Indonezia">Jakarta, Indonezia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_jamestown_st_helena" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Jamestown, St. Helena</extra-loc-engineeringenglish>
      <source>Jamestown, Saint Helena355</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Jamestown, Sfânta Elena">Jamestown, Sfânta Elena</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_jayapura_indonesia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Jayapura, Indonesia</extra-loc-engineeringenglish>
      <source>Jayapura, Indonesia356</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Jayapura, Indonezia">Jayapura, Indonezia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_jerusalem_israel" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Jerusalem, Israel</extra-loc-engineeringenglish>
      <source>Jerusalem, Israel357</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ierusalim, Israel">Ierusalim, Israel</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_joao_pessoa_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Joao Pessoa, Brazil</extra-loc-engineeringenglish>
      <source>Joao Pessoa, Brazil358</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Joao Pessoa, Brazilia">Joao Pessoa, Brazilia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_johannesburg_safrica" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Johannesburg, South Africa</extra-loc-engineeringenglish>
      <source>Johannesburg, South Africa359</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Johannesburg, Africa de Sud">Johannesburg, Africa de Sud</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_joinville_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Joinville, Brazil</extra-loc-engineeringenglish>
      <source>Joinville, Brazil360</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Joinville, Brazilia">Joinville, Brazilia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kabul_afghan" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kabul, Afghanistan</extra-loc-engineeringenglish>
      <source>Kabul, Afghanistan361</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Kabul, Afganistan">Kabul, Afganistan</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kaliningrad_russia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kaliningrad, Russia</extra-loc-engineeringenglish>
      <source>Kaliningrad, Russia362</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Kaliningrad, Rusia">Kaliningrad, Rusia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kampala_uganda" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kampala, Uganda</extra-loc-engineeringenglish>
      <source>Kampala, Uganda363</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Kampala, Uganda">Kampala, Uganda</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kanton_isl_phoenix_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kanton Island, Phoenix Islands</extra-loc-engineeringenglish>
      <source>Kanton Island, Phoenix Islands364</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Insula Kanton, Insulele Phoenix">Insula Kanton, Insulele Phoenix</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_karachi_pakistan" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Karachi, Pakistan</extra-loc-engineeringenglish>
      <source>Karachi, Pakistan365</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Karachi, Pakistan">Karachi, Pakistan</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kathmandu_nepal" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kathmandu, Nepal</extra-loc-engineeringenglish>
      <source>Kathmandu, Nepal366</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Kathmandu, Nepal">Kathmandu, Nepal</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_khartoum_sudan" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Khartoum, Sudan</extra-loc-engineeringenglish>
      <source>Khartoum, Sudan367</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Khartoum, Sudan">Khartoum, Sudan</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kigali_rwanda" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kigali, Rwanda</extra-loc-engineeringenglish>
      <source>Kigali, Rwanda368</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Kigali, Ruanda">Kigali, Ruanda</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kingston_jamaica" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kingston, Jamaica</extra-loc-engineeringenglish>
      <source>Kingston, Jamaica369</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Kingston, Jamaica">Kingston, Jamaica</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kingston_norfolk_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kingston, Norfolk Island</extra-loc-engineeringenglish>
      <source>Kingston, Norfolk Island370</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Kingston, Insula Norfolk">Kingston, Insula Norfolk</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kingstown_st_vincent" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kingstown, St. Vincent</extra-loc-engineeringenglish>
      <source>Kingstown, Saint Vincent and Grenadines371</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography is incompatible between NTR and Trados" originaltestercomment="" originaltranslation="Kingstown, Saint Vincent Și Grenadine">Kingstown, Saint Vincent Și Grenadine</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kinshasa_drc" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kinshasa, Democratic Republic of the Congo</extra-loc-engineeringenglish>
      <source>Kinshasa, Congo, Democratic Republic of the372</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Kinshasa, Congo, Republica Democrată">Kinshasa, Congo, Republica Democrată</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kolkata_india" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kolkata, India</extra-loc-engineeringenglish>
      <source>Kolkata, India373</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Kolkata, India">Kolkata, India</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_krasnoyarsk_russia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Krasnoyarsk, Russia</extra-loc-engineeringenglish>
      <source>Krasnoyarsk, Russia374</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Krasnoiarsk, Rusia">Krasnoiarsk, Rusia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kuala_lumpur_malaysia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kuala Lumpur, Malaysia</extra-loc-engineeringenglish>
      <source>Kuala Lumpur, Malaysia375</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Kuala Lumpur, Malaezia">Kuala Lumpur, Malaezia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kuwait_city_kuwait" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kuwait City, Kuwait</extra-loc-engineeringenglish>
      <source>Kuwait City, Kuwait376</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Kuwait City, Kuwait">Kuwait City, Kuwait</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_kyiv_ukraine" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Kyiv, Ukraine</extra-loc-engineeringenglish>
      <source>Kyiv, Ukraine377</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Kiev, Ucraina">Kiev, Ucraina</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_la_paz_bolivia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>La Paz, Bolivia</extra-loc-engineeringenglish>
      <source>La Paz, Bolivia378</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="La Paz, Bolivia">La Paz, Bolivia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_laayoune_west_sahara" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Laayoune, Western Sahara</extra-loc-engineeringenglish>
      <source>Laayoune, Western Sahara379</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Laayoune, Sahara Occidentală">Laayoune, Sahara Occidentală</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_las_palmas_canary_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Las Palmas, Canary Islands</extra-loc-engineeringenglish>
      <source>Las Palmas, Canary Islands380</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Las Palmas, Insulele Canare">Las Palmas, Insulele Canare</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_las_vegas_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Las Vegas, United States of America</extra-loc-engineeringenglish>
      <source>Las Vegas, NV, United States of America381</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Las Vegas, NV, Statele Unite ale Americii">Las Vegas, NV, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_libreville_gabon" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Libreville, Gabon</extra-loc-engineeringenglish>
      <source>Libreville, Gabon382</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Libreville, Gabon">Libreville, Gabon</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_lilongwe_malawi" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Lilongwe, Malawi</extra-loc-engineeringenglish>
      <source>Lilongwe, Malawi383</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Lilongwe, Malawi">Lilongwe, Malawi</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_lima_peru" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Lima, Peru</extra-loc-engineeringenglish>
      <source>Lima, Peru384</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Lima, Peru">Lima, Peru</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_lisbon_portugal" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Lisbon, Portugal</extra-loc-engineeringenglish>
      <source>Lisbon, Portugal385</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Lisabona, Portugalia">Lisabona, Portugalia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_ljubljana_slovenia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Ljubljana, Slovenia</extra-loc-engineeringenglish>
      <source>Ljubljana, Slovenia386</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ljubljana, Slovenia">Ljubljana, Slovenia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="yes" id="txt_clk_list_ln_hrsln_mins" marked="false">
      <extracomment />
      <location />
      <comment>When a city is added to the World Clock list view, its relative time offset is displayed with respect to Homecity.</comment>
      <extra-loc-engineeringenglish>&lt;+/-&gt;%Ln hrs,%Ln mins</extra-loc-engineeringenglish>
      <source>&lt;+/-&gt;%Ln hrs,%Ln mins387</source>
      <translation testresult="false" keep="false">
        <numerusform plurality="a" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" variants="no" originaltranslation="">ro #&lt;+/-&gt;%Ln hrs,%Ln mins</numerusform>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id />
      <extra-loc-layout />
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_World clock_P05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_lomé_togo" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Lomé, Togo</extra-loc-engineeringenglish>
      <source>Lomé, Togo388</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Lomé, Togo">Lomé, Togo</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_london_christmas_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>London, Christmas Island</extra-loc-engineeringenglish>
      <source>London, Christmas Island389</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Londra, Insula Christmas">Londra, Insula Christmas</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_london_uk" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>London, United Kingdom</extra-loc-engineeringenglish>
      <source>London, United Kingdom390</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Londra, Regatul Unit">Londra, Regatul Unit</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_lord_howe_isl_aus" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Lord Howe Island, Australia</extra-loc-engineeringenglish>
      <source>Lord Howe Island, Australia391</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Insula Lord Howe, Australia">Insula Lord Howe, Australia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_los_angeles_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Los Angeles, United States of America</extra-loc-engineeringenglish>
      <source>Los Angeles, CA, United States of America392</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Los Angeles, CA, Statele Unite ale Americii">Los Angeles, CA, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_louisville_ky_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Louisville, KY, United States of America</extra-loc-engineeringenglish>
      <source>Louisville, KY, United States of America393</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Louisville, KY, Statele Unite ale Americii">Louisville, KY, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_luanda_angola" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Luanda, Angola</extra-loc-engineeringenglish>
      <source>Luanda, Angola394</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Luanda, Angola">Luanda, Angola</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_lubumbashi_drc" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Lubumbashi, Democratic Republic of the Congo</extra-loc-engineeringenglish>
      <source>Lubumbashi, Congo, Democratic Republic of the395</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Lubumbashi, Congo, Republica Democrată">Lubumbashi, Congo, Republica Democrată</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_lusaka_zambia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Lusaka, Zambia</extra-loc-engineeringenglish>
      <source>Lusaka, Zambia396</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Lusaka, Zambia">Lusaka, Zambia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_luxembourg_city_luxembourg" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Luxembourg City, Luxembourg</extra-loc-engineeringenglish>
      <source>Luxembourg, Luxembourg397</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Luxemburg, Luxemburg">Luxemburg, Luxemburg</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_macapa_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Macapa, Brazil</extra-loc-engineeringenglish>
      <source>Macapa, Brazil398</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Macapa, Brazilia">Macapa, Brazilia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_macau_macau" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Macau, Macau</extra-loc-engineeringenglish>
      <source>Macau, Macau399</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Macao, Macao">Macao, Macao</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_maceio_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Maceio, Brazil</extra-loc-engineeringenglish>
      <source>Maceio, Brazil400</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Maceio, Brazilia">Maceio, Brazilia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_madrid_spain" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Madrid, Spain</extra-loc-engineeringenglish>
      <source>Madrid, Spain401</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Madrid, Spania">Madrid, Spania</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_magadan_russia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Magadan, Russia</extra-loc-engineeringenglish>
      <source>Magadan, Russia402</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Magadan, Rusia">Magadan, Rusia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_majuro_marshall_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Majuro, Marshall Islands</extra-loc-engineeringenglish>
      <source>Majuro, Marshall Islands403</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Majuro, Insulele Marshall">Majuro, Insulele Marshall</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_makassar_indonesia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Makassar, Indonesia</extra-loc-engineeringenglish>
      <source>Makassar, Indonesia404</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Makassar, Indonezia">Makassar, Indonezia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_malabo_eq_guinea" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Malabo, Equatorial Guinea</extra-loc-engineeringenglish>
      <source>Malabo, Equatorial Guinea405</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Malabo, Guineea Ecuatorială">Malabo, Guineea Ecuatorială</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_male_maldives" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Male, Maldives</extra-loc-engineeringenglish>
      <source>Male, Maldives406</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Male, Maldive">Male, Maldive</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_mamoudzou_mayotte" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Mamoudzou, Mayotte</extra-loc-engineeringenglish>
      <source>Mamoudzou, Mayotte407</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Mamoudzou, Mayotte">Mamoudzou, Mayotte</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_managua_nicaragua" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Managua, Nicaragua</extra-loc-engineeringenglish>
      <source>Managua, Nicaragua408</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Managua, Nicaragua">Managua, Nicaragua</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_manama_bahrain" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Manama, Bahrain</extra-loc-engineeringenglish>
      <source>Manama, Bahrain409</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Manama, Bahrain">Manama, Bahrain</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_manaus_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Manaus, Brazil</extra-loc-engineeringenglish>
      <source>Manaus, Brazil410</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Manaus, Brazilia">Manaus, Brazilia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_manila_philippines" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Manila, Philippines</extra-loc-engineeringenglish>
      <source>Manila, Philippines411</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Manila, Filipine">Manila, Filipine</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_maputo_mozambique" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Maputo, Mozambique</extra-loc-engineeringenglish>
      <source>Maputo, Mozambique412</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Maputo, Mozambic">Maputo, Mozambic</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_maseru_lesotho" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Maseru, Lesotho</extra-loc-engineeringenglish>
      <source>Maseru, Lesotho413</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Maseru, Lesotho">Maseru, Lesotho</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_mata_utu_wallis_futuna_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Mata_Utu, Wallis and Futuna Islands</extra-loc-engineeringenglish>
      <source>Mata-Utu, Wallis and Futuna Islands414</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography is incompatible between NTR and Trados" originaltestercomment="" originaltranslation="Mata-Utu, Insulele Wallis Și Futuna">Mata-Utu, Insulele Wallis Și Futuna</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_mbabane_swaziland" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Mbabane, Swaziland</extra-loc-engineeringenglish>
      <source>Mbabane, Swaziland415</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Mbabane, Swaziland">Mbabane, Swaziland</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_melbourne_aus" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Melbourne, Australia</extra-loc-engineeringenglish>
      <source>Melbourne, Australia416</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Melbourne, Australia">Melbourne, Australia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_melekeok_palau" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Melekeok, Palau</extra-loc-engineeringenglish>
      <source>Melekeok, Palau417</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Melekeok, Palau">Melekeok, Palau</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_memphis_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Memphis, United States of America</extra-loc-engineeringenglish>
      <source>Memphis, TN, United States of America418</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Memphis, TN, Statele Unite ale Americii">Memphis, TN, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_mexico_city_mexico" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Mexico City, Mexico</extra-loc-engineeringenglish>
      <source>Mexico City, Mexico419</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Mexico City, Mexic">Mexico City, Mexic</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_miami_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Miami, United States of America</extra-loc-engineeringenglish>
      <source>Miami, FL, United States of America420</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Miami, FL, Statele Unite ale Americii">Miami, FL, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_milwaukee_wi_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Milwaukee, WI, United States of America</extra-loc-engineeringenglish>
      <source>Milwaukee, WI, United States of America421</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Milwaukee, WI, Statele Unite ale Americii">Milwaukee, WI, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_minneapolis_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Minneapolis, United States of America</extra-loc-engineeringenglish>
      <source>Minneapolis, MN, United States of America422</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Minneapolis, MN, Statele Unite ale Americii">Minneapolis, MN, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_minsk_belarus" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Minsk, Belarus</extra-loc-engineeringenglish>
      <source>Minsk, Belarus423</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Minsk, Belarus">Minsk, Belarus</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_mogadishu_somalia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Mogadishu, Somalia</extra-loc-engineeringenglish>
      <source>Mogadishu, Somalia424</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Mogadishu, Somalia">Mogadishu, Somalia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_monaco_monaco" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Monaco, Monaco</extra-loc-engineeringenglish>
      <source>Monaco, Monaco425</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Monaco, Monaco">Monaco, Monaco</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_monrovia_liberia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Monrovia, Liberia</extra-loc-engineeringenglish>
      <source>Monrovia, Liberia426</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Monrovia, Liberia">Monrovia, Liberia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_montevideo_uruguay" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Montevideo, Uruguay</extra-loc-engineeringenglish>
      <source>Montevideo, Uruguay427</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Montevideo, Uruguay">Montevideo, Uruguay</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_montpelier_vt_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Montpelier, VT, United States of America</extra-loc-engineeringenglish>
      <source>Montpelier, VT, United States of America428</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Montpelier, VT, Statele Unite ale Americii">Montpelier, VT, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_montreal_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Montreal, Canada</extra-loc-engineeringenglish>
      <source>Montreal, Canada429</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Montreal, Canada">Montreal, Canada</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_moroni_comoros" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Moroni, Comoros</extra-loc-engineeringenglish>
      <source>Moroni, Comoros430</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Moroni, Comore">Moroni, Comore</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_moscow_russia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Moscow, Russia</extra-loc-engineeringenglish>
      <source>Moscow, Russia431</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Moscova, Rusia">Moscova, Rusia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_mumbai_india" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Mumbai, India</extra-loc-engineeringenglish>
      <source>Mumbai, India432</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Mumbai, India">Mumbai, India</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_muscat_oman" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Muscat, Oman</extra-loc-engineeringenglish>
      <source>Muscat, Oman433</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Muscat, Oman">Muscat, Oman</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_nairobi_kenya" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Nairobi, Kenya</extra-loc-engineeringenglish>
      <source>Nairobi, Kenya434</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Nairobi, Kenya">Nairobi, Kenya</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_nassau_bahamas" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Nassau, Bahamas</extra-loc-engineeringenglish>
      <source>Nassau, Bahamas435</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Nassau, Bahamas">Nassau, Bahamas</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_new_delhi_india" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>New Delhi, India</extra-loc-engineeringenglish>
      <source>New Delhi, India436</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="New Delhi, India">New Delhi, India</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_new_orleans_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>New Orleans, United States of America</extra-loc-engineeringenglish>
      <source>New Orleans, LA, United States of America437</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="New Orleans, LA, Statele Unite ale Americii">New Orleans, LA, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_new_york_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>New York, United States of America</extra-loc-engineeringenglish>
      <source>New York, NY, United States of America438</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="New York, NY, Statele Unite ale Americii">New York, NY, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_niamey_niger" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Niamey, Niger</extra-loc-engineeringenglish>
      <source>Niamey, Niger439</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Niamey, Niger">Niamey, Niger</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_nicosia_cyprus" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Nicosia, Cyprus</extra-loc-engineeringenglish>
      <source>Nicosia, Cyprus440</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Nicosia, Cipru">Nicosia, Cipru</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_nouakchott_mauritania" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Nouakchott, Mauritania</extra-loc-engineeringenglish>
      <source>Nouakchott, Mauritania441</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Nouakchott, Mauritania">Nouakchott, Mauritania</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_noumea_new_caledonia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Noumea, New Caledonia</extra-loc-engineeringenglish>
      <source>Noumea, New Caledonia442</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Nouméa, Noua Caledonie">Nouméa, Noua Caledonie</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_novosibirsk_russia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Novosibirsk, Russia</extra-loc-engineeringenglish>
      <source>Novosibirsk, Russia443</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Novosibirsk, Rusia">Novosibirsk, Rusia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_nuku_alofa_tonga" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Nuku’alofa, Tonga</extra-loc-engineeringenglish>
      <source>Nuku’alofa, Tonga444</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Nuku’alofa, Tonga">Nuku’alofa, Tonga</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_nuuk_greenland" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Nuuk, Greenland</extra-loc-engineeringenglish>
      <source>Nuuk, Greenland445</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Nuuk, Groenlanda">Nuuk, Groenlanda</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_oklahoma_city_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Oklahoma City, United States of America</extra-loc-engineeringenglish>
      <source>Oklahoma City, OK, United States of America446</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Oklahoma City, OK, Statele Unite ale Americii">Oklahoma City, OK, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_omaha_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Omaha, United States of America</extra-loc-engineeringenglish>
      <source>Omaha, NE, United States of America447</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Omaha, NE, Statele Unite ale Americii">Omaha, NE, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_oranjestad_aruba" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Oranjestad, Aruba</extra-loc-engineeringenglish>
      <source>Oranjestad, Aruba448</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Oranjestad, Aruba">Oranjestad, Aruba</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_osaka_japan" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Osaka, Japan</extra-loc-engineeringenglish>
      <source>Osaka, Japan449</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Osaka, Japonia">Osaka, Japonia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_oslo_norway" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Oslo, Norway</extra-loc-engineeringenglish>
      <source>Oslo, Norway450</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Oslo, Norvegia">Oslo, Norvegia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_ottawa_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Ottawa, Canada</extra-loc-engineeringenglish>
      <source>Ottawa, Canada451</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ottawa, Canada">Ottawa, Canada</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_ouagadougou_bf" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Ouagadougou, Burkina Faso</extra-loc-engineeringenglish>
      <source>Ouagadougou, Burkina Faso452</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ouagadougou, Burkina Faso">Ouagadougou, Burkina Faso</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_pago_pago_as_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Pago Pago, AS, United States of America</extra-loc-engineeringenglish>
      <source>Pago Pago, AS, United States of America453</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Pago Pago, AS, Statele Unite ale Americii">Pago Pago, AS, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_palikir_micronesia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Palikir, Micronesia</extra-loc-engineeringenglish>
      <source>Palikir, Micronesia454</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Palikir, Micronezia">Palikir, Micronezia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_palmas_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Palmas, Brazil</extra-loc-engineeringenglish>
      <source>Palmas, Brazil455</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Palmas, Brazilia">Palmas, Brazilia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_panama_city_panama" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Panama City, Panama</extra-loc-engineeringenglish>
      <source>Panama City, Panama456</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Panama City, Panama">Panama City, Panama</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_papeete_tahiti" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Papeete, Tahiti</extra-loc-engineeringenglish>
      <source>Papeete, Tahiti457</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Papeete, Tahiti">Papeete, Tahiti</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_paramaribo_suriname" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Paramaribo, Suriname</extra-loc-engineeringenglish>
      <source>Paramaribo, Suriname458</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Paramaribo, Suriname">Paramaribo, Suriname</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_paris_france" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Paris, France</extra-loc-engineeringenglish>
      <source>Paris, France459</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography is incompatible between NTR and Trados" originaltestercomment="" originaltranslation="Paris, FranȚa">Paris, FranȚa</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_pbm_galapagos_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Puerto Baquerizo Moreno, Galapagos Islands</extra-loc-engineeringenglish>
      <source>Puerto Baquerizo Moreno, Galapagos Islands460</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Puerto Baquerizo Moreno, Insulele Galapagos">Puerto Baquerizo Moreno, Insulele Galapagos</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_pensacola_fl_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Pensacola, FL, United States of America</extra-loc-engineeringenglish>
      <source>Pensacola, FL, United States of America461</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Pensacola, FL, Statele Unite ale Americii">Pensacola, FL, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_perth_aus" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Perth, Australia</extra-loc-engineeringenglish>
      <source>Perth, Australia462</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Perth, Australia">Perth, Australia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_philadelphia_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Philadelphia, United States of America</extra-loc-engineeringenglish>
      <source>Philadelphia, PA, United States of America463</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Philadelphia, PA, Statele Unite ale Americii">Philadelphia, PA, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_phnom_penh_cambodia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Phnom Penh, Cambodia</extra-loc-engineeringenglish>
      <source>Phnom Penh, Cambodia464</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Phnom Penh, Cambodgia">Phnom Penh, Cambodgia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_phoenix_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Phoenix, United States of America</extra-loc-engineeringenglish>
      <source>Phoenix, AZ, United States of America465</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Phoenix, AZ, Statele Unite ale Americii">Phoenix, AZ, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_podgorica_montenegro" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Podgorica, Montenegro</extra-loc-engineeringenglish>
      <source>Podgorica, Montenegro466</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Podgorica, Muntenegru">Podgorica, Muntenegru</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_ponta_delgada_azores" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Ponta Delgada, Azores</extra-loc-engineeringenglish>
      <source>Ponta Delgada, Azores467</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ponta Delgada, Azore">Ponta Delgada, Azore</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_port_louis_mauritius" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Port Louis, Mauritius</extra-loc-engineeringenglish>
      <source>Port Louis, Mauritius468</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Port Louis, Mauritius">Port Louis, Mauritius</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_port_moresby_png" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Port Moresby, Papua New Guinea</extra-loc-engineeringenglish>
      <source>Port Moresby, Papua New Guinea469</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Port Moresby, Papua Noua Guinee">Port Moresby, Papua Noua Guinee</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_port_of_spain_trinidad" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Port of Spain, Trinidad</extra-loc-engineeringenglish>
      <source>Port of Spain, Trinidad470</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Port of Spain, Trinidad">Port of Spain, Trinidad</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_port_vila_vanuatu" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Port Vila, Vanuatu</extra-loc-engineeringenglish>
      <source>Port Vila, Vanuatu471</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Port Vila, Vanuatu">Port Vila, Vanuatu</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_portland_or_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Portland, OR, United States of America</extra-loc-engineeringenglish>
      <source>Portland, OR, United States of America472</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Portland, OR, Statele Unite ale Americii">Portland, OR, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_porto_alegre_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Porto Alegre, Brazil</extra-loc-engineeringenglish>
      <source>Porto Alegre, Brazil473</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Porto Alegre, Brazilia">Porto Alegre, Brazilia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_porto_au_prince_haiti" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Port-au-Prince, Haiti</extra-loc-engineeringenglish>
      <source>Port-au-Prince, Haiti474</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Port-au-Prince, Haiti">Port-au-Prince, Haiti</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_porto_aux_francais_kerguelen" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Port-aux-Francais, Kerguelen</extra-loc-engineeringenglish>
      <source>Port-aux-Francais, Kerguelen Islands475</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Port-aux-Français, Insulele Kerguelen">Port-aux-Français, Insulele Kerguelen</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_porto_novo_benin" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Porto-Novo, Benin</extra-loc-engineeringenglish>
      <source>Porto-Novo, Benin476</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Porto-Novo, Benin">Porto-Novo, Benin</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_porto_velho_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Porto Velho, Brazil</extra-loc-engineeringenglish>
      <source>Porto Velho, Brazil477</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Porto Velho, Brazilia">Porto Velho, Brazilia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_prague_czech" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Prague, Czechoslovakia</extra-loc-engineeringenglish>
      <source>Prague, Czech Republic478</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the source text is erroneous. Czechoslovakia has ceased to exist a long time ago, and Prague is the capital of the Czech Republic - and this is the way we translated it." originaltestercomment="" originaltranslation="Praga, Republica Cehă">Praga, Republica Cehă</lengthvariant>
      </translation>
      <oldsource>Prague, Czechoslovakia</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_praia_cape_verde" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Praia, Cape Verde</extra-loc-engineeringenglish>
      <source>Praia, Cape Verde479</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Praia, Capul Verde">Praia, Capul Verde</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_pretoria_safrica" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Pretoria, South Africa</extra-loc-engineeringenglish>
      <source>Pretoria, South Africa480</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Pretoria, Africa de Sud">Pretoria, Africa de Sud</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_providence_ri_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Providence, RI, United States of America</extra-loc-engineeringenglish>
      <source>Providence, RI, United States of America481</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Providence, RI, Statele Unite ale Americii">Providence, RI, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_pyongyang_north_korea" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Pyongyang, North Korea</extra-loc-engineeringenglish>
      <source>Pyongyang, North Korea482</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Pyongyang, Coreea de Nord">Pyongyang, Coreea de Nord</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_quito_equador" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Quito, Equador</extra-loc-engineeringenglish>
      <source>Quito, Equador483</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Quito, Ecuador">Quito, Ecuador</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_rabat_morocco" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Rabat, Morocco</extra-loc-engineeringenglish>
      <source>Rabat, Morocco484</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Rabat, Maroc">Rabat, Maroc</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_rainy_river_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Rainy River, Canada</extra-loc-engineeringenglish>
      <source>Rainy River, Canada485</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Rainy River, Canada">Rainy River, Canada</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_rangoon_myanmar" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Rangoon, Myanmar</extra-loc-engineeringenglish>
      <source>Rangoon, Myanmar486</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Rangoon, Myanmar">Rangoon, Myanmar</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_rankin_inlet_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Rankin Inlet, Canada</extra-loc-engineeringenglish>
      <source>Rankin Inlet, Canada487</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Rankin Inlet, Canada">Rankin Inlet, Canada</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_recife_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Recife, Brazil</extra-loc-engineeringenglish>
      <source>Recife, Brazil488</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Recife, Brazilia">Recife, Brazilia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_regina_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Regina, Canada</extra-loc-engineeringenglish>
      <source>Regina, Canada489</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Regina, Canada">Regina, Canada</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_reykjavik_iceland" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Reykjavik, Iceland</extra-loc-engineeringenglish>
      <source>Reykjavik, Iceland490</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Reykjavik, Islanda">Reykjavik, Islanda</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_richmond_va_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Richmond, VA, United States of America</extra-loc-engineeringenglish>
      <source>Richmond, VA, United States of America491</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Richmond, VA, Statele Unite ale Americii">Richmond, VA, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_riga_latvia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Riga, Latvia</extra-loc-engineeringenglish>
      <source>Riga, Latvia492</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Riga, Letonia">Riga, Letonia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_rio_de_jan_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Rio de Janeiro, Brazil</extra-loc-engineeringenglish>
      <source>Rio de Janeiro, Brazil493</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Rio de Janeiro, Brazilia">Rio de Janeiro, Brazilia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_riyadh_saudi_arabia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Riyadh, Saudi Arabia</extra-loc-engineeringenglish>
      <source>Riyadh, Saudi Arabia494</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Riad, Arabia Saudită">Riad, Arabia Saudită</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_road_town_british_virgin_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Road Town, British Virgin Islands</extra-loc-engineeringenglish>
      <source>Road Town, British Virgin Islands495</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Road Town, Insulele Virgine Britanice">Road Town, Insulele Virgine Britanice</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_rome_italy" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Rome, Italy</extra-loc-engineeringenglish>
      <source>Rome, Italy496</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Roma, Italia">Roma, Italia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_roseau_dominica" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Roseau, Dominica</extra-loc-engineeringenglish>
      <source>Roseau, Dominica497</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Roseau, Dominica">Roseau, Dominica</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_saint_denis_reunion" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Saint-Denis, Reunion</extra-loc-engineeringenglish>
      <source>Saint-Denis, Reunion498</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Saint-Denis, Reunion">Saint-Denis, Reunion</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_saint_georges_grenada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Saint George's, </extra-loc-engineeringenglish>
      <source>Saint George's, Grenada499</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Saint George's, Grenada">Saint George's, Grenada</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_saint_johns_ab" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Saint John's, Antigua and Barbuda</extra-loc-engineeringenglish>
      <source>Saint John's, Antigua and Barbuda500</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography is incompatible between NTR and Trados" originaltestercomment="" originaltranslation="Saint John's, Antigua Și Barbuda">Saint John's, Antigua Și Barbuda</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_saint_pierre_miquelon" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Saint-Pierre, Miquelon</extra-loc-engineeringenglish>
      <source>Saint-Pierre, Miquelon501</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Saint-Pierre, Miquelon">Saint-Pierre, Miquelon</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_saipan_mariana_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Saipan, Mariana Islands</extra-loc-engineeringenglish>
      <source>Saipan, Mariana Islands502</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Saipan, Insulele Mariane">Saipan, Insulele Mariane</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_saipan_mp_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Saipan, MP, United States of America</extra-loc-engineeringenglish>
      <source>Saipan, MP, United States of America503</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Saipan, MP, Statele Unite ale Americii">Saipan, MP, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_salt_lake_city_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Salt Lake City, United States of America</extra-loc-engineeringenglish>
      <source>Salt Lake City, UT, United States of America504</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Salt Lake City, UT, Statele Unite ale Americii">Salt Lake City, UT, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_salvador_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Salvador, Brazil</extra-loc-engineeringenglish>
      <source>Salvador, Brazil505</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Salvador, Brazilia">Salvador, Brazilia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_samara_russia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Samara, Russia</extra-loc-engineeringenglish>
      <source>Samara, Russia506</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Samara, Rusia">Samara, Rusia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_san_francisco_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>San Francisco, United States of America</extra-loc-engineeringenglish>
      <source>San Francisco, CA, United States of America507</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="San Francisco, CA, Statele Unite ale Americii">San Francisco, CA, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_san_jose_costa_rica" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>San Jose, Costa Rica</extra-loc-engineeringenglish>
      <source>San Jose, Costa Rica508</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="San Jose, Costa Rica">San Jose, Costa Rica</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_san_juan_puerto_rico" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>San Juan, Puerto Rico</extra-loc-engineeringenglish>
      <source>San Juan, Puerto Rico509</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="San Juan, Puerto Rico">San Juan, Puerto Rico</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_san_marino_city_san_marino" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>San Marino City, San Marino</extra-loc-engineeringenglish>
      <source>San Marino City, San Marino510</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="San Marino City, San Marino">San Marino City, San Marino</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_san_salvador_el_salvador" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>San Salvador, El Salvador</extra-loc-engineeringenglish>
      <source>San Salvador, El Salvador511</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="San Salvador, El Salvador">San Salvador, El Salvador</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_sanaa_yemen" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Sanaa, Yemen</extra-loc-engineeringenglish>
      <source>Sanaa, Yemen512</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Sanaa, Yemen">Sanaa, Yemen</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_santiago_chile" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Santiago, Chile</extra-loc-engineeringenglish>
      <source>Santiago, Chile513</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Santiago, Chile">Santiago, Chile</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_santo_domingo_dominican_rep" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Santo Domingo, Dominican Republic</extra-loc-engineeringenglish>
      <source>Santo Domingo, Dominican Republic514</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Santo Domingo, Republica Dominicană">Santo Domingo, Republica Dominicană</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_sao_luis_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Sao Luis, Brazil</extra-loc-engineeringenglish>
      <source>Sao Luis, Brazil515</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Sao Luis, Brazilia">Sao Luis, Brazilia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_sao_paulo_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Sao Paulo, Brazil</extra-loc-engineeringenglish>
      <source>Sao Paulo, Brazil516</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Sao Paulo, Brazilia">Sao Paulo, Brazilia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_sao_tome_principe" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>São Tomé, Príncipe</extra-loc-engineeringenglish>
      <source>São Tomé, São Tomé and Príncipe517</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography is incompatible between NTR and Trados" originaltestercomment="" originaltranslation="São Tomé, São Tomé Și Príncipe">São Tomé, São Tomé Și Príncipe</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_sapporo_japan" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Sapporo, Japan</extra-loc-engineeringenglish>
      <source>Sapporo, Japan518</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Sapporo, Japonia">Sapporo, Japonia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_scoresbysund_greenland" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Scoresbysund, Greenland</extra-loc-engineeringenglish>
      <source>Scoresbysund, Greenland519</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Scoresbysund, Groenlanda">Scoresbysund, Groenlanda</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_seattle_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Seattle, United States of America</extra-loc-engineeringenglish>
      <source>Seattle, WA, United States of America520</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Seattle, WA, Statele Unite ale Americii">Seattle, WA, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_seoul_skorea" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Seoul, South Korea</extra-loc-engineeringenglish>
      <source>Seoul, South Korea521</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Seoul, Coreea de Sud">Seoul, Coreea de Sud</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_singapore_city_singapore" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Singapore City, Singapore</extra-loc-engineeringenglish>
      <source>Singapore, Singapore522</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Singapore, Singapore">Singapore, Singapore</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_sioux_falls_sd_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Sioux Falls, SD, United States of America</extra-loc-engineeringenglish>
      <source>Sioux Falls, SD, United States of America523</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Sioux Falls, SD, Statele Unite ale Americii">Sioux Falls, SD, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_skopje_macedonia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Skopje, Macedonia</extra-loc-engineeringenglish>
      <source>Skopje, Macedonia524</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Skopje, Macedonia">Skopje, Macedonia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_sofia_bulgaria" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Sofia, Bulgaria</extra-loc-engineeringenglish>
      <source>Sofia, Bulgaria525</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Sofia, Bulgaria">Sofia, Bulgaria</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_sonora_mexico" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Sonora, Mexico</extra-loc-engineeringenglish>
      <source>Sonora, Mexico526</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Sonora, Mexic">Sonora, Mexic</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_st_loius_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>St. Louis, United States of America</extra-loc-engineeringenglish>
      <source>St. Louis, MO, United States of America527</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="St. Louis, MO, Statele Unite ale Americii">St. Louis, MO, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_st_petersburg_russia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>St. Petersburg, Russia</extra-loc-engineeringenglish>
      <source>St. Petersburg, Russia528</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="St. Petersburg, Rusia">St. Petersburg, Rusia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_stanley_falkland_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Stanley, Falkland Islands</extra-loc-engineeringenglish>
      <source>Stanley, Falkland Islands529</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Stanley, Insulele Falkland">Stanley, Insulele Falkland</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_stockholm_sweden" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Stockholm, Sweden</extra-loc-engineeringenglish>
      <source>Stockholm, Sweden530</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Stockholm, Suedia">Stockholm, Suedia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_suva_fiji" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Suva, Fiji</extra-loc-engineeringenglish>
      <source>Suva, Fiji531</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Suva, Fiji">Suva, Fiji</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_taiohae_marquesas_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Taiohae, Marquesas Islands</extra-loc-engineeringenglish>
      <source>Taiohae, Marquesas Islands532</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Taiohae, Insulele Marquesas">Taiohae, Insulele Marquesas</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_taipei_taiwan" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Taipei, Taiwan</extra-loc-engineeringenglish>
      <source>Taipei, Taiwan533</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Taipei, Taiwan">Taipei, Taiwan</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_tallinn_estonia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Tallinn, Estonia</extra-loc-engineeringenglish>
      <source>Tallinn, Estonia534</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Tallinn, Estonia">Tallinn, Estonia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_tarawa_kiribati" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Tarawa, Kiribati</extra-loc-engineeringenglish>
      <source>Tarawa, Kiribati535</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Tarawa, Kiribati">Tarawa, Kiribati</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_taskhkent_uzbekistan" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Tashkent, Uzbekistan</extra-loc-engineeringenglish>
      <source>Tashkent, Uzbekistan536</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography is incompatible between NTR and Trados" originaltestercomment="" originaltranslation="TaȘkent, Uzbekistan">TaȘkent, Uzbekistan</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_tbilisi_georgia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Tbilisi, Georgia</extra-loc-engineeringenglish>
      <source>Tbilisi, Georgia537</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Tbilisi, Georgia">Tbilisi, Georgia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_tegucigalpa_honduras" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Tegucigalpa, Honduras</extra-loc-engineeringenglish>
      <source>Tegucigalpa, Honduras538</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Tegucigalpa, Honduras">Tegucigalpa, Honduras</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_tehran_iran" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Tehran, Iran</extra-loc-engineeringenglish>
      <source>Tehran, Iran539</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Teheran, Iran">Teheran, Iran</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_tel_aviv_israel" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Tel Aviv, Israel</extra-loc-engineeringenglish>
      <source>Tel Aviv, Israel540</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Tel Aviv, Israel">Tel Aviv, Israel</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_teresina_brazil" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Teresina, Brazil</extra-loc-engineeringenglish>
      <source>Teresina, Brazil541</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Teresina, Brazilia">Teresina, Brazilia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_the_settlement_christmas_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>The Settlement, Christmas Island.</extra-loc-engineeringenglish>
      <source>The Settlement, Christmas Island542</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="The Settlement, Insula Christmas">The Settlement, Insula Christmas</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_the_valley_anguilla" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>The Valley, Anguilla</extra-loc-engineeringenglish>
      <source>The Valley, Anguilla543</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="The Valley, Anguilla">The Valley, Anguilla</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_thimpu_bhutan" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Thimpu, Bhutan</extra-loc-engineeringenglish>
      <source>Thimpu, Bhutan544</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Thimpu, Bhutan">Thimpu, Bhutan</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_thule_greenland" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Thule, Greenland</extra-loc-engineeringenglish>
      <source>Thule, Greenland545</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Thule, Groenlanda">Thule, Groenlanda</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_tijuana_mexico" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Tijuana, Mexico</extra-loc-engineeringenglish>
      <source>Tijuana, Mexico546</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Tijuana, Mexic">Tijuana, Mexic</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_time" marked="false">
      <extracomment />
      <location />
      <comment>When a city is added to the World Clock listview, its time is displayed.</comment>
      <extra-loc-engineeringenglish>&lt;time&gt;</extra-loc-engineeringenglish>
      <source>Time547</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Oră">Oră</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_World clock_P05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_tirana_albania" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Tirana, Albania</extra-loc-engineeringenglish>
      <source>Tirana, Albania548</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Tirana, Albania">Tirana, Albania</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_tokya_japan" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Tokya, Japan</extra-loc-engineeringenglish>
      <source>Tokyo, Japan549</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Tokyo, Japonia">Tokyo, Japonia</lengthvariant>
      </translation>
      <oldsource>Tokya, Japan</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_toronto_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Toronto, Canada</extra-loc-engineeringenglish>
      <source>Toronto, Canada550</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Toronto, Canada">Toronto, Canada</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_tórshavn_faroe_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Tórshavn, Faroe Islands</extra-loc-engineeringenglish>
      <source>Tórshavn, Faroe Islands551</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ro Tórshavn, Faroe Islands</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_tripoli_libya" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Tripoli, Libya</extra-loc-engineeringenglish>
      <source>Tripoli, Libya552</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Tripoli, Libia">Tripoli, Libia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_tunis_tunisia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Tunis, Tunisia</extra-loc-engineeringenglish>
      <source>Tunis, Tunisia553</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Tunis, Tunisia">Tunis, Tunisia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_ulaanbaatar_mongolia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Ulaanbaatar, Mongolia</extra-loc-engineeringenglish>
      <source>Ulaanbaatar, Mongolia554</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ulan Bator, Mongolia">Ulan Bator, Mongolia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_vaduz_lichtenstein" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Vaduz, Lichtenstein</extra-loc-engineeringenglish>
      <source>Vaduz, Lichtenstein555</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Vaduz, Lichtenstein">Vaduz, Lichtenstein</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_valletta_malta" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Valletta, Malta</extra-loc-engineeringenglish>
      <source>Valletta, Malta556</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Valletta, Malta">Valletta, Malta</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_vancouver_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Vancouver, Canada</extra-loc-engineeringenglish>
      <source>Vancouver, Canada557</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Vancouver, Canada">Vancouver, Canada</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_victoria_seychelles" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Victoria, Seychelles</extra-loc-engineeringenglish>
      <source>Victoria, Seychelles558</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Victoria, Seychelles">Victoria, Seychelles</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_vienna_austria" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Vienna, Austria</extra-loc-engineeringenglish>
      <source>Vienna, Austria559</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Viena, Austria">Viena, Austria</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_vientiane_laos" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Vientiane, Laos</extra-loc-engineeringenglish>
      <source>Vientiane, Laos560</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Vientiane, Laos">Vientiane, Laos</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_vilnius_lithuania" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Vilnius, Lithuania</extra-loc-engineeringenglish>
      <source>Vilnius, Lithuania561</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Vilnius, Lituania">Vilnius, Lituania</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_vladivostok_russia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Vladivostok, Russia</extra-loc-engineeringenglish>
      <source>Vladivostok, Russia562</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Vladivostok, Rusia">Vladivostok, Rusia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_warsaw_poland" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Warsaw, Poland</extra-loc-engineeringenglish>
      <source>Warsaw, Poland563</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography is incompatible between NTR and Trados" originaltestercomment="" originaltranslation="VarȘovia, Polonia">VarȘovia, Polonia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_washington_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Washington, United States of America</extra-loc-engineeringenglish>
      <source>Washington, DC, United States of America564</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Washington, DC, Statele Unite ale Americii">Washington, DC, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_wellington_nzealand" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Wellington, New Zealand</extra-loc-engineeringenglish>
      <source>Wellington, New Zealand565</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Wellington, Noua Zeelandă">Wellington, Noua Zeelandă</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_west_isl_cocos_isl" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>West Island, Cocos Islands</extra-loc-engineeringenglish>
      <source>West Island, Cocos (Keeling) Islands566</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="West Island, Insulele Cocos (Keeling)">West Island, Insulele Cocos (Keeling)</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_wichita_ks_usa" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Wichita, KS, United States of America</extra-loc-engineeringenglish>
      <source>Wichita, KS, United States of America567</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Wichita, KS, Statele Unite ale Americii">Wichita, KS, Statele Unite ale Americii</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_willemstad_curacao" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Willemstad, Curacao</extra-loc-engineeringenglish>
      <source>Willemstad, Curacao568</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Willemstad, Curacao">Willemstad, Curacao</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_windhoek_namibia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Windhoek, Namibia</extra-loc-engineeringenglish>
      <source>Windhoek, Namibia569</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Windhoek, Namibia">Windhoek, Namibia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_winnipeg_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Winnipeg, Canada</extra-loc-engineeringenglish>
      <source>Winnipeg, Canada570</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Winnipeg, Canada">Winnipeg, Canada</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_yakutsk_russia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Yakutsk, Russia</extra-loc-engineeringenglish>
      <source>Yakutsk, Russia571</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Iakutsk, Rusia">Iakutsk, Rusia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_yaoundé_cameroon" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Yaoundé, Cameroon</extra-loc-engineeringenglish>
      <source>Yaoundé, Cameroon572</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Yaoundé, Camerun">Yaoundé, Camerun</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_yaren_district_nauru" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Yaren District, Nauru</extra-loc-engineeringenglish>
      <source>Yaren District, Nauru573</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Yaren District, Nauru">Yaren District, Nauru</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_yekaterinburg_russia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Yekaterinburg, Russia</extra-loc-engineeringenglish>
      <source>Yekaterinburg, Russia574</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ecaterinburg, Rusia">Ecaterinburg, Rusia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_yellowknife_canada" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Yellowknife, Canada</extra-loc-engineeringenglish>
      <source>Yellowknife, Canada575</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Yellowknife, Canada">Yellowknife, Canada</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_yerevan_armenia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Yerevan, Armenia</extra-loc-engineeringenglish>
      <source>Yerevan, Armenia576</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Erevan, Armenia">Erevan, Armenia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_list_zagreb_croatia" marked="false">
      <extracomment />
      <location />
      <comment>City name</comment>
      <extra-loc-engineeringenglish>Zagreb, Croatia</extra-loc-engineeringenglish>
      <source>Zagreb, Croatia577</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography is incompatible between NTR and Trados" originaltestercomment="" originaltranslation="Zagreb, CroaȚia">Zagreb, CroaȚia</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_main_view_list_alarm" marked="false">
      <extracomment />
      <location />
      <comment>Alarm description is displayed in the middle row. If user doesnt enter name, the default description is "Alarm".</comment>
      <extra-loc-engineeringenglish>Alarm</extra-loc-engineeringenglish>
      <source>Alarm578</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Alarmă">Alarmă</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_15,410</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock main view_P01</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="yes" id="txt_clk_main_view_list_in_ln_hrs" marked="false">
      <extracomment />
      <location />
      <comment>Remaining alarm time is displayed in the top row above the alarm description</comment>
      <extra-loc-engineeringenglish>In %Ln hrs</extra-loc-engineeringenglish>
      <source>In %Ln hours579</source>
      <translation testresult="false" keep="false">
        <numerusform plurality="a" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Warning ignored, as instructed in the Q&amp;A file." originaltestercomment="" variants="no" originaltranslation="În %Ln oră">În %Ln oră</numerusform>
        <numerusform plurality="b" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Warning ignored, as instructed in the Q&amp;A file." originaltestercomment="" variants="no" originaltranslation="În %Ln ore">În %Ln ore</numerusform>
        <numerusform plurality="c" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Warning ignored, as instructed in the Q&amp;A file." originaltestercomment="" variants="no" originaltranslation="În %Ln de ore">În %Ln de ore</numerusform>
      </translation>
      <oldsource>In %Ln hour</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_graphic_add</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_graphic_add</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock main view_P01</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_main_view_list_no_alarms_set" marked="false">
      <extracomment />
      <location />
      <comment>When there are no alarms set in Clock main view, the text "No alarms set" is displayed in list.</comment>
      <extra-loc-engineeringenglish>No alarms set</extra-loc-engineeringenglish>
      <source>(no alarms set)580</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="(nicio alarmă setată)">(nicio alarmă setată)</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_15,410</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock main view_with no alarms set_P02</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_main_view_list_occurence_detail" marked="false">
      <extracomment />
      <location />
      <comment>Occurence detail is displayed in the bottom row.</comment>
      <extra-loc-engineeringenglish>&lt;Occurence detail&gt;</extra-loc-engineeringenglish>
      <source>Alarm details581</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Detalii alarmă">Detalii alarmă</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_15,410,79</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock main view_P01</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_main_view_list_time" marked="false">
      <extracomment />
      <location />
      <comment>When user sets alarm time, it is displayed on the left column. "am/pm" is placed below the time.</comment>
      <extra-loc-engineeringenglish>&lt;time&gt;</extra-loc-engineeringenglish>
      <source>Alarm time582</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Oră alarmă">Oră alarmă</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_15,410</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock main view_P01</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_main_view_menu_delete_alarm" marked="false">
      <extracomment />
      <location />
      <comment>Long tap on an alarm in Alarm list opens the item specific menu displaying text "Delete alarm"</comment>
      <extra-loc-engineeringenglish>Delete alarm</extra-loc-engineeringenglish>
      <source>Delete alarm583</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography does not work between NTR and Trados" originaltestercomment="" originaltranslation="Ștergere alarmă">Ștergere alarmă</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_15,410,77</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>Clock main view_P01</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_main_view_opt_exit" marked="false">
      <extracomment />
      <location />
      <comment>Item in Options menu from Clock main view</comment>
      <extra-loc-engineeringenglish>Exit</extra-loc-engineeringenglish>
      <source>Exit584</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography does not work between NTR and Trados" originaltestercomment="" originaltranslation="IeȘire">IeȘire</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>97</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>Clock main view_P01</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_main_view_opt_help" marked="false">
      <extracomment />
      <location />
      <comment>Item in Options menu from Clock main view</comment>
      <extra-loc-engineeringenglish>Help</extra-loc-engineeringenglish>
      <source>Help585</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ajutor">Ajutor</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>511</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>Clock main view_P01</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_main_view_opt_settings" marked="false">
      <extracomment />
      <location />
      <comment>Item in Options menu from Clock main vew</comment>
      <extra-loc-engineeringenglish>Settings</extra-loc-engineeringenglish>
      <source>Settings586</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Setări">Setări</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>290,NOT_291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>Clock main view_P01</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_main_view_title_clock" marked="false">
      <extracomment />
      <location />
      <comment>Title name for the Clock application</comment>
      <extra-loc-engineeringenglish>Clock</extra-loc-engineeringenglish>
      <source>Clock587</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ceas">Ceas</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_chrome_title</extra-loc-layout_id>
      <extra-loc-layout>qtl_chrome_title</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>61</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>Clock main view_P01</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_menu_delete" marked="false">
      <extracomment />
      <location />
      <comment>Long tap menu on an added city in World Clock view (both portrait and landscape)</comment>
      <extra-loc-engineeringenglish>Delete</extra-loc-engineeringenglish>
      <source>Delete588</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography does not work between NTR and Trados" originaltestercomment="" originaltranslation="Ștergere">Ștergere</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>77</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>Clock_World clock_P05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_menu_set_as_current_location" marked="false">
      <extracomment />
      <location />
      <comment>Long tap menu on an added city in the World clock view (both portrait and landscape)</comment>
      <extra-loc-engineeringenglish>Set as current location</extra-loc-engineeringenglish>
      <source>Set as current location589</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography does not work between NTR and Trados" originaltestercomment="" originaltranslation="Setare ca locaȚie curentă">Setare ca locaȚie curentă</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>543,NOT_544</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>Clock_World clock_P05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_menu_show_on_homescreen" marked="false">
      <extracomment />
      <location />
      <comment>Long tap menu on an added city in World clock view (both portrait and landscape)</comment>
      <extra-loc-engineeringenglish>Show on homescreen</extra-loc-engineeringenglish>
      <source>Show on Home screen590</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography does not work between NTR and Trados" originaltestercomment="" originaltranslation="AfiȘare pe ecranul de start">AfiȘare pe ecranul de start</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>432</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>Clock_World clock_P05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_opt_add_own_city" marked="false">
      <extracomment />
      <location />
      <comment>"Add own city" from Options menu in City list </comment>
      <extra-loc-engineeringenglish>Add own city</extra-loc-engineeringenglish>
      <source>Add own city591</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ro Add own city</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_alarm_sound" marked="false">
      <extracomment />
      <location />
      <comment>Label for Alarm sound in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Alarm sound</extra-loc-engineeringenglish>
      <source>Alarm sound592</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Sunet alarmă">Sunet alarmă</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_checkbox_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_checkbox_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_15,410</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_date_format" marked="false">
      <extracomment />
      <location />
      <comment>3rd field in Regional date &amp; time settings view</comment>
      <extra-loc-engineeringenglish>Date format:</extra-loc-engineeringenglish>
      <source>Date format:593</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Format dată:">Format dată:</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_heading_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_heading_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_3</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_day" marked="false">
      <extracomment />
      <location />
      <comment>Label for Day in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Day</extra-loc-engineeringenglish>
      <source>Day594</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Zi">Zi</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_heading_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_heading_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_daylight_saving_time" marked="false">
      <extracomment />
      <location />
      <comment>Label for DST in Clock settings view</comment>
      <extra-loc-engineeringenglish>Daylight saving time</extra-loc-engineeringenglish>
      <source>Daylight saving time595</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Orar de vară">Orar de vară</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_checkbox_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_checkbox_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_occurence" marked="false">
      <extracomment />
      <location />
      <comment>Label for Occurence in Alarm editor</comment>
      <extra-loc-engineeringenglish>Occurence</extra-loc-engineeringenglish>
      <source>Repeat596</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Repetare">Repetare</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_heading_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_heading_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_400</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_time" marked="false">
      <extracomment />
      <location />
      <comment>Label for Time in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Time</extra-loc-engineeringenglish>
      <source>Time597</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Oră">Oră</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_heading_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_heading_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_use_network_date_time" marked="false">
      <extracomment />
      <location />
      <comment>1st label in Date and time settings view</comment>
      <extra-loc-engineeringenglish>Use network date &amp; time</extra-loc-engineeringenglish>
      <source>Auto-update of date and time598</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography does not work between NTR and Trados" originaltestercomment="" originaltranslation="Actualizare automată a datei Și orei">Actualizare automată a datei Și orei</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_checkbox_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_checkbox_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>28</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_12_hour" marked="false">
      <extracomment />
      <location />
      <comment>2nd value in combo box list for Time format label</comment>
      <extra-loc-engineeringenglish>12 hour</extra-loc-engineeringenglish>
      <source>12-hour599</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="12 ore">12 ore</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_2_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_3</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_24_hour" marked="false">
      <extracomment />
      <location />
      <comment>1st Value in combo box list for Time format label</comment>
      <extra-loc-engineeringenglish>24 hour</extra-loc-engineeringenglish>
      <source>24-hour600</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="24 ore">24 ore</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_3</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_dd_mm_yyyy" marked="false">
      <extracomment />
      <location />
      <comment>1st value in combo box list for Date format label</comment>
      <extra-loc-engineeringenglish>dd mm yyyy</extra-loc-engineeringenglish>
      <source>dd mm yyyy601</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="zz ll aaaa">zz ll aaaa</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_3</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_friday" marked="false">
      <extracomment />
      <location />
      <comment>5th dropdown list value for Day label in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Friday</extra-loc-engineeringenglish>
      <source>Friday602</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Vineri">Vineri</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_5_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_mm_dd_yyyy" marked="false">
      <extracomment />
      <location />
      <comment>2nd value in combo box list for Date format label</comment>
      <extra-loc-engineeringenglish>mm dd yyyy</extra-loc-engineeringenglish>
      <source>mm dd yyyy603</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="ll zz aaaa">ll zz aaaa</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_2_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_3</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_monday" marked="false">
      <extracomment />
      <location />
      <comment>1st dropdown list value for Day label in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Monday</extra-loc-engineeringenglish>
      <source>Monday604</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Luni">Luni</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_once" marked="false">
      <extracomment />
      <location />
      <comment>1st dropdown list value for Occurence label in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Once</extra-loc-engineeringenglish>
      <source>Not repeated605</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Nu se repetă">Nu se repetă</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_daily" marked="false">
      <extracomment />
      <location />
      <comment>2nd dropdown list value for Occurence label in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Repeat daily</extra-loc-engineeringenglish>
      <source>Daily606</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Zilnic">Zilnic</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_2_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_on_workdays" marked="false">
      <extracomment />
      <location />
      <comment>4th dropdown list value for Occurence label in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Repeat on workdays</extra-loc-engineeringenglish>
      <source>Workdays607</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Zile lucrătoare">Zile lucrătoare</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_4_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_repeat_weekly" marked="false">
      <extracomment />
      <location />
      <comment>3rd dropdown list value for Occurence label in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Repeat weekly</extra-loc-engineeringenglish>
      <source>Weekly608</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Săptămânal">Săptămânal</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_3_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_saturday" marked="false">
      <extracomment />
      <location />
      <comment>6th dropdown list value for Day label in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Saturday</extra-loc-engineeringenglish>
      <source>Saturday609</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Sâmbătă">Sâmbătă</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_6_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_sunday" marked="false">
      <extracomment />
      <location />
      <comment>7th dropdown list value for Day label in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Sunday</extra-loc-engineeringenglish>
      <source>Sunday610</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Duminică">Duminică</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_7_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_thursday" marked="false">
      <extracomment />
      <location />
      <comment>4th dropdown list value for Day label in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Thursday</extra-loc-engineeringenglish>
      <source>Thursday611</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Joi">Joi</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_4_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_tuesday" marked="false">
      <extracomment />
      <location />
      <comment>2nd dropdown list value for Day label in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Tuesday</extra-loc-engineeringenglish>
      <source>Tuesday612</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography does not work between NTR and Trados" originaltestercomment="" originaltranslation="MarȚi">MarȚi</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_2_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_wednesday" marked="false">
      <extracomment />
      <location />
      <comment>3rd dropdown list value for Day label in Alarm editor view</comment>
      <extra-loc-engineeringenglish>Wednesday</extra-loc-engineeringenglish>
      <source>Wednesday613</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Miercuri">Miercuri</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_3_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_val_yyyy_mm_dd" marked="false">
      <extracomment />
      <location />
      <comment>3rd value in combo box list for Date format label</comment>
      <extra-loc-engineeringenglish>yyyy mm dd</extra-loc-engineeringenglish>
      <source>yyyy mm dd614</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="aaaa ll zz">aaaa ll zz</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_group_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_group_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_3_val</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_3</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_week_starts_on" marked="false">
      <extracomment />
      <location />
      <comment>6th field in Regional date &amp; time settings view</comment>
      <extra-loc-engineeringenglish>Week starts on:</extra-loc-engineeringenglish>
      <source>Week starts on:615</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Săptămâna începe:">Săptămâna începe:</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_heading_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_heading_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_320</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_3</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_setlabel_workdays" marked="false">
      <extracomment />
      <location />
      <comment>Label for Workdays in Alarm editor</comment>
      <extra-loc-engineeringenglish>Workdays:</extra-loc-engineeringenglish>
      <source>Workdays:616</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Zile lucrătoare:">Zile lucrătoare:</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_heading_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_heading_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_1</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_3</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_subhead_date_time" marked="false">
      <extracomment />
      <location />
      <comment>Sub-title for Date &amp; time settings view</comment>
      <extra-loc-engineeringenglish>Date &amp; time</extra-loc-engineeringenglish>
      <source>Date and time617</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography does not work between NTR and Trados" originaltestercomment="" originaltranslation="Dată Și oră">Dată Și oră</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_groupbox_simple_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_groupbox_simple_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>subtitle</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_subhead_regional_date_time_settings" marked="false">
      <extracomment />
      <location />
      <comment>Sub-title for Regiional date &amp; time settings</comment>
      <extra-loc-engineeringenglish>Regional date &amp; time settings</extra-loc-engineeringenglish>
      <source>Advanced settings618</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Setări avansate">Setări avansate</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_groupbox_simple_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_groupbox_simple_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>290,NOT_291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>subtitle</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_3</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_subtitle_alarm" marked="false">
      <extracomment />
      <location />
      <comment>When user taps on already existed alarm in the alarm list, the alarm editor opens with subtitle "Alarm"</comment>
      <extra-loc-engineeringenglish>Alarm</extra-loc-engineeringenglish>
      <source>Alarm619</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Alarmă">Alarmă</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_groupbox_simple_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_groupbox_simple_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_15,410</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>subtitle</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_subtitle_city_list" marked="false">
      <extracomment />
      <location />
      <comment>Subtitle for City list</comment>
      <extra-loc-engineeringenglish>City list</extra-loc-engineeringenglish>
      <source>City list620</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">ro City list</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_groupbox_simple_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_groupbox_simple_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_156</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>subtitle</extra-loc-positionid>
      <extra-loc-viewid>Clock_City list_P07</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_subtitle_new_alarm" marked="false">
      <extracomment />
      <location />
      <comment>When user taps on "New alarm" toolbar button in Clock main view, alarm editor opens with the subtitle "New alarm".</comment>
      <extra-loc-engineeringenglish>New alarm</extra-loc-engineeringenglish>
      <source>New alarm621</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Alarmă nouă">Alarmă nouă</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_groupbox_simple_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_groupbox_simple_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_15,410</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>subtitle</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_subtitle_world_clock" marked="false">
      <extracomment />
      <location />
      <comment>Subtitle for World Clock view</comment>
      <extra-loc-engineeringenglish>World Clock</extra-loc-engineeringenglish>
      <source>World clock622</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ceas universal">Ceas universal</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_groupbox_simple_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_groupbox_simple_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_61</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>subtitle</extra-loc-positionid>
      <extra-loc-viewid>Clock_World clock_P05</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clk_title_clock" marked="false">
      <extracomment />
      <location />
      <comment>Title for Date and time settings view</comment>
      <extra-loc-engineeringenglish>Clock</extra-loc-engineeringenglish>
      <source>Clock623</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ceas">Ceas</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_chrome_title</extra-loc-layout_id>
      <extra-loc-layout>qtl_chrome_title</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>61</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>Clock_Date &amp; time settings_P04_1</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clock_opt_delete" marked="false">
      <extracomment />
      <location />
      <comment>When user creates a new alarm in Alarm editor form, he can "Delete" this alarm via Options menu.</comment>
      <extra-loc-engineeringenglish>Delete</extra-loc-engineeringenglish>
      <source>Delete624</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography does not work between NTR and Trados" originaltestercomment="" originaltranslation="Ștergere">Ștergere</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>77</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_clock_opt_discard_changes" marked="false">
      <extracomment />
      <location />
      <comment>When user edits an already existed alarm in Alarm editor form, he can "Discard changes" from Options menu and the prevoius values are saved.</comment>
      <extra-loc-engineeringenglish>Discard changes</extra-loc-engineeringenglish>
      <source>Discard changes625</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Anulare modificări">Anulare modificări</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>Clock_Alarm editor_P03</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cp_main_view_list_time_date" marked="false">
      <extracomment />
      <location />
      <comment>This text is displayed in 1st row</comment>
      <extra-loc-engineeringenglish>Time &amp; date</extra-loc-engineeringenglish>
      <source>Date and time626</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="Please note that the new Romanian orthography does not work between NTR and Trados" originaltestercomment="" originaltranslation="Dată Și oră">Dată Și oră</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>CP main view_time &amp; date plugin_P11</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cp_main_view_list_time_info_date_info" marked="false">
      <extracomment />
      <location />
      <comment>The time and date information will be displayed in 2nd row</comment>
      <extra-loc-engineeringenglish>&lt;time info, date info&gt;</extra-loc-engineeringenglish>
      <source>Time, date627</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Oră, dată">Oră, dată</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_sec_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_sec_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>CP main view_time &amp; date plugin_P11</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cp_main_view_subtitle_device" marked="false">
      <extracomment />
      <location />
      <comment>Subtitle for Control Panel main view under which Time &amp; date settings are displayed.</comment>
      <extra-loc-engineeringenglish>Device</extra-loc-engineeringenglish>
      <source>Phone628</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Telefon">Telefon</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_groupbox_simple_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_groupbox_simple_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>228</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>subtitle</extra-loc-positionid>
      <extra-loc-viewid>CP main view_time &amp; date plugin_P11</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_cp_main_view_title_control_panel" marked="false">
      <extracomment />
      <location />
      <comment>Title for Control Panel main view</comment>
      <extra-loc-engineeringenglish>Control Panel</extra-loc-engineeringenglish>
      <source>Control panel629</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Panou control">Panou control</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_chrome_title</extra-loc-layout_id>
      <extra-loc-layout>qtl_chrome_title</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>CP main view_time &amp; date plugin_P11</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_long_caption_clk" marked="false">
      <extracomment />
      <location />
      <comment>Long caption for Clock in App library listview</comment>
      <extra-loc-engineeringenglish>Clock</extra-loc-engineeringenglish>
      <source>Clock630</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Ceas">Ceas</translation>
      <oldsource>Clock</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>61</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>list</extra-loc-positionid>
      <extra-loc-viewid>Clock</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
  </context>
</TS>