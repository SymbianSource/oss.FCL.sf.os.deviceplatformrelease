<?xml version="1.0" encoding="utf-8"?>
<TS xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" version="1.0" sourcelanguage="English-GB" language="sk">
  <extra-loc-extended xsi:type="xsd:boolean">true</extra-loc-extended>
  <defaultcodec />
  <extra-loc-feature xsi:type="xsd:string">cmmanager@dfsxx.01</extra-loc-feature>
  <extra-loc-style xsi:type="xsd:string">ts</extra-loc-style>
  <context>
    <name>Prophet</name>
    <message numerus="no" id="txt_occ_dblist_internet" marked="false">
      <extracomment />
      <location />
      <comment>List item, 2-row, primary text. Name of the Internet destination.</comment>
      <extra-loc-engineeringenglish>Internet</extra-loc-engineeringenglish>
      <source>Internet634</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Internet">Internet</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>502</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dblist_2</extra-loc-positionid>
      <extra-loc-viewid>occ_settings</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_occ_dblist_intranet" marked="false">
      <extracomment />
      <location />
      <comment>List item, 2-row, primary text. Name of the Intranet destination.</comment>
      <extra-loc-engineeringenglish>Intranet</extra-loc-engineeringenglish>
      <source>Intranet635</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Intranet">Intranet</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_627</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dblist_4</extra-loc-positionid>
      <extra-loc-viewid>occ_settings</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_occ_dblist_operator_services" marked="false">
      <extracomment />
      <location />
      <comment>List item, 2-row, primary text. Name of the Operator services destination.</comment>
      <extra-loc-engineeringenglish>Operator services</extra-loc-engineeringenglish>
      <source>Operator services636</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Služby operátora">Služby operátora</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_list_pri_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_list_pri_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_482</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dblist_3</extra-loc-positionid>
      <extra-loc-viewid>occ_settings</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_occ_setlabel_connection_name_val_connection" marked="false">
      <extracomment />
      <location />
      <comment>Setting value. Default name for internet access point in case no name defined by user.</comment>
      <extra-loc-engineeringenglish>Connection</extra-loc-engineeringenglish>
      <source>Connection637</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">sk #Connection</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dataform_editor_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dataform_editor_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>setlabel_11_val</extra-loc-positionid>
      <extra-loc-viewid>occ_iap_ui_02</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
  </context>
</TS>