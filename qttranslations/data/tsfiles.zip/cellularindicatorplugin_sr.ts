<?xml version="1.0" encoding="utf-8"?>
<TS xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" version="1.0" sourcelanguage="English-GB" language="sr">
  <extra-loc-extended xsi:type="xsd:boolean">true</extra-loc-extended>
  <defaultcodec />
  <extra-loc-feature xsi:type="xsd:string">cellularindicatorplugin@dfsxx.01</extra-loc-feature>
  <extra-loc-style xsi:type="xsd:string">ts</extra-loc-style>
  <context>
    <name>Prophet</name>
    <message numerus="no" id="txt_occ_dblist_cellular_data" marked="false">
      <extracomment />
      <location />
      <comment>Indicator menu cellular data connection plugin title.</comment>
      <extra-loc-engineeringenglish>Cellular data</extra-loc-engineeringenglish>
      <source>Cellular data168</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">sr #Cellular data</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_indimenu_pri_medium_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_indimenu_pri_medium_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dblist_14</extra-loc-positionid>
      <extra-loc-viewid>occ_indicator_menu</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_occ_dblist_cellular_data_val_1_connected" marked="false">
      <extracomment />
      <location />
      <comment>Indicator menu cellular data connection plugin value, one connection active, to access point %1. Parameter not localised.</comment>
      <extra-loc-engineeringenglish>'%1' connected</extra-loc-engineeringenglish>
      <source>'%1' connected169</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">sr #'%1' connected</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_indimenu_sec_medium_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_indimenu_sec_medium_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dblist_14_val</extra-loc-positionid>
      <extra-loc-viewid>occ_indicator_menu</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_occ_dblist_cellular_data_val_l1_connections" marked="false">
      <extracomment />
      <location />
      <comment>Indicator menu cellular data connection plugin value, several simultaneous connections active (more than one), %L1 is the number of active connections.</comment>
      <extra-loc-engineeringenglish>%L1 connections</extra-loc-engineeringenglish>
      <source>%L1 connections170</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">sr #%L1 connections</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_indimenu_sec_medium_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_indimenu_sec_medium_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dblist_14_val</extra-loc-positionid>
      <extra-loc-viewid>occ_indicator_menu</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
  </context>
</TS>