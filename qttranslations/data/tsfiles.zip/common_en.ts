<?xml version="1.0" encoding="utf-8"?>
<TS xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" version="1.0" sourcelanguage="English-GB" language="en">
  <extra-loc-extended xsi:type="xsd:boolean">true</extra-loc-extended>
  <defaultcodec />
  <extra-loc-feature xsi:type="xsd:string">common@dfsxx.01</extra-loc-feature>
  <extra-loc-style xsi:type="xsd:string">ts</extra-loc-style>
  <context>
    <name>Prophet</name>
    <message numerus="no" id="txt_common_button_answer_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to answer an incoming call.</comment>
      <extra-loc-engineeringenglish>Answer</extra-loc-engineeringenglish>
      <source>Answer628</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">en #Answer</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_cancel_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to cancel the action or process.</comment>
      <extra-loc-engineeringenglish>Cancel</extra-loc-engineeringenglish>
      <source>Cancel629</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">en #Cancel</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_clear_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to clear text from an editing field.</comment>
      <extra-loc-engineeringenglish>Clear</extra-loc-engineeringenglish>
      <source>Clear630</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">en #Clear</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_delete_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to delete an item. Note that deleting removes the item permanently from memory.</comment>
      <extra-loc-engineeringenglish>Delete</extra-loc-engineeringenglish>
      <source>Delete631</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">en #Delete</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_hide_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to hide an item.</comment>
      <extra-loc-engineeringenglish>Hide</extra-loc-engineeringenglish>
      <source>Hide632</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">en #Hide</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_no_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Pressing this button rejects the selected operation.</comment>
      <extra-loc-engineeringenglish>No</extra-loc-engineeringenglish>
      <source>No633</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">en #No</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_ok_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. When this button is pressed, the focused item or operation will be selected or accepted.</comment>
      <extra-loc-engineeringenglish>OK</extra-loc-engineeringenglish>
      <source>OK634</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">en #OK</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_reject_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to reject the suggested operation.</comment>
      <extra-loc-engineeringenglish>Reject</extra-loc-engineeringenglish>
      <source>Reject635</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">en #Reject</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_send_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to send a message or an item.</comment>
      <extra-loc-engineeringenglish>Send</extra-loc-engineeringenglish>
      <source>Send636</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">en #Send</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_yes_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Pressing this button confirms the selected operation.</comment>
      <extra-loc-engineeringenglish>Yes</extra-loc-engineeringenglish>
      <source>Yes637</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">en #Yes</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_adding" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being added.</comment>
      <extra-loc-engineeringenglish>Adding</extra-loc-engineeringenglish>
      <source>Adding638</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Adding">Adding</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_buffering" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when buffering is in progress.</comment>
      <extra-loc-engineeringenglish>Buffering</extra-loc-engineeringenglish>
      <source>Buffering639</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Buffering">Buffering</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_cancelling" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being cancelled.</comment>
      <extra-loc-engineeringenglish>Cancelling</extra-loc-engineeringenglish>
      <source>Cancelling640</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Cancelling">Cancelling</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>54</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_closing" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being closed.</comment>
      <extra-loc-engineeringenglish>Closing</extra-loc-engineeringenglish>
      <source>Closing641</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Closing">Closing</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>62</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_connecting" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when the device is connecting to for example a server, another device etc.</comment>
      <extra-loc-engineeringenglish>Connecting</extra-loc-engineeringenglish>
      <source>Connecting642</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Connecting">Connecting</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_copying" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being copied.</comment>
      <extra-loc-engineeringenglish>Copying</extra-loc-engineeringenglish>
      <source>Copying643</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Copying">Copying</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>722</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_deleting" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being deleted.</comment>
      <extra-loc-engineeringenglish>Deleting</extra-loc-engineeringenglish>
      <source>Deleting644</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Deleting">Deleting</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>77</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_disconnecting" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when a connection is being terminated.</comment>
      <extra-loc-engineeringenglish>Disconnecting</extra-loc-engineeringenglish>
      <source>Disconnecting645</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Disconnecting">Disconnecting</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_initialising" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when at the beginning of synchronisation when the phone is giving the server the starting values.</comment>
      <extra-loc-engineeringenglish>Initialising</extra-loc-engineeringenglish>
      <source>Initialising646</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Initialising">Initialising</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_inserting" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when an item (e.g. an image into message or a contact into a group) is being inserted.</comment>
      <extra-loc-engineeringenglish>Inserting</extra-loc-engineeringenglish>
      <source>Inserting647</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Inserting">Inserting</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>143</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_installing" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being installed.</comment>
      <extra-loc-engineeringenglish>Installing</extra-loc-engineeringenglish>
      <source>Installing648</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Installing">Installing</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_loading" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being loaded.</comment>
      <extra-loc-engineeringenglish>Loading</extra-loc-engineeringenglish>
      <source>Loading649</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Loading">Loading</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_moving" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being moved.</comment>
      <extra-loc-engineeringenglish>Moving</extra-loc-engineeringenglish>
      <source>Moving650</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Moving">Moving</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>184</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_opening" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being opened.</comment>
      <extra-loc-engineeringenglish>Opening</extra-loc-engineeringenglish>
      <source>Opening651</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Opening">Opening</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>210</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_processing" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being processed.</comment>
      <extra-loc-engineeringenglish>Processing</extra-loc-engineeringenglish>
      <source>Processing652</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Processing">Processing</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_registering" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being registered.</comment>
      <extra-loc-engineeringenglish>Registering</extra-loc-engineeringenglish>
      <source>Registering653</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Registering">Registering</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_removing" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being removed.</comment>
      <extra-loc-engineeringenglish>Removing</extra-loc-engineeringenglish>
      <source>Removing654</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Removing">Removing</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>266</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_requesting" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being requested.</comment>
      <extra-loc-engineeringenglish>Requesting</extra-loc-engineeringenglish>
      <source>Requesting655</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Requesting">Requesting</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_retrieving" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being retrieved.</comment>
      <extra-loc-engineeringenglish>Retrieving</extra-loc-engineeringenglish>
      <source>Retrieving656</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Retrieving">Retrieving</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>270</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_saving" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being saved.</comment>
      <extra-loc-engineeringenglish>Saving</extra-loc-engineeringenglish>
      <source>Saving657</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Saving">Saving</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>273</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_searching" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed during a search operation.</comment>
      <extra-loc-engineeringenglish>Searching</extra-loc-engineeringenglish>
      <source>Searching658</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Searching">Searching</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>276</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_unistalling" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being uninstalled.</comment>
      <extra-loc-engineeringenglish>Uninstalling</extra-loc-engineeringenglish>
      <source>Uninstalling659</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Uninstalling">Uninstalling</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_about_application" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. About application. Opens a view where information about the application is given.</comment>
      <extra-loc-engineeringenglish>About application</extra-loc-engineeringenglish>
      <source>About application660</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="About application">About application</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>3,NOT_18,NOT_408</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_activate" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Activates the focused call diverting item or call barring. </comment>
      <extra-loc-engineeringenglish>Activate</extra-loc-engineeringenglish>
      <source>Activate661</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Activate">Activate</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>542</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_activate_handsfree" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Switches the call from loudspeaker or handsfree to handset.</comment>
      <extra-loc-engineeringenglish>Activate handset</extra-loc-engineeringenglish>
      <source>Activate handset662</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Activate handset">Activate handset</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>542,NOT_121,490</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_activate_loudspeaker" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Switches the call from handset or handsfree to loudspeaker.</comment>
      <extra-loc-engineeringenglish>Activate loudspeaker</extra-loc-engineeringenglish>
      <source>Activate loudspeaker663</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Activate loudspeaker">Activate loudspeaker</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>542,161</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_add_bookmark" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to add a bookmark.</comment>
      <extra-loc-engineeringenglish>Add bookmark</extra-loc-engineeringenglish>
      <source>Save as bookmark664</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Save as bookmark">Save as bookmark</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>39,273</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_add_detail" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to add a new item (i.e. a piece of information) for e.g. a meeting request or contact.</comment>
      <extra-loc-engineeringenglish>Add detail</extra-loc-engineeringenglish>
      <source>Add detail665</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Add detail">Add detail</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_add_from_contacts" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Opens Contacts application where the user can select contact information.</comment>
      <extra-loc-engineeringenglish>Add from Contacts</extra-loc-engineeringenglish>
      <source>Add from Contacts666</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Add from Contacts">Add from Contacts</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_70,71</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_add_image" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allow user to add image from e.g. Photos.</comment>
      <extra-loc-engineeringenglish>Add image</extra-loc-engineeringenglish>
      <source>Add image667</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Add image">Add image</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>133</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_add_member" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to add a member to a group.</comment>
      <extra-loc-engineeringenglish>Add member</extra-loc-engineeringenglish>
      <source>Add member668</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Add member">Add member</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_add_recipient" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to add a recipient to the current message.</comment>
      <extra-loc-engineeringenglish>Add recipient</extra-loc-engineeringenglish>
      <source>Add recipient669</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Add recipient">Add recipient</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_add_thumbnail" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows to add or change a thumbnail image for e.g. a member, group or memory.</comment>
      <extra-loc-engineeringenglish>Add thumbnail</extra-loc-engineeringenglish>
      <source>Add thumbnail image670</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Add thumbnail image">Add thumbnail image</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_133,336</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_add_to_contacts" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Opens Contacts application where the user can select contact information.</comment>
      <extra-loc-engineeringenglish>Add to Contacts</extra-loc-engineeringenglish>
      <source>Add to Contacts671</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Add to Contacts">Add to Contacts</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_70,71</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_add_to_folder" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to add an item into a folder.</comment>
      <extra-loc-engineeringenglish>Add to folder</extra-loc-engineeringenglish>
      <source>Add to folder672</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Add to folder">Add to folder</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_additional_details" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to view additional details of the selected item.</comment>
      <extra-loc-engineeringenglish>Additional details</extra-loc-engineeringenglish>
      <source>Additional details673</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Additional details">Additional details</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>79</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_advanced_settings" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Opens a view where the user can edit advanced settings.</comment>
      <extra-loc-engineeringenglish>Advanced settings</extra-loc-engineeringenglish>
      <source>Advanced settings674</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Advanced settings">Advanced settings</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>290,NOT_291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_attachments" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Opens a view where attachments can be added or opened.</comment>
      <extra-loc-engineeringenglish>Attachments</extra-loc-engineeringenglish>
      <source>Attachments675</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Attachments">Attachments</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>21</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_automatic_find_off" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Switches off the automatic find function.</comment>
      <extra-loc-engineeringenglish>Automatic find off</extra-loc-engineeringenglish>
      <source>Automatic find off676</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Automatic find off">Automatic find off</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>101</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_automatic_find_on" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Switches on the automatic find function.</comment>
      <extra-loc-engineeringenglish>Automatic find on</extra-loc-engineeringenglish>
      <source>Automatic find on677</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Automatic find on">Automatic find on</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>101</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_call_noun" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. A noun meaning a connection between the caller and the called party or parties; a phone call.</comment>
      <extra-loc-engineeringenglish>Call</extra-loc-engineeringenglish>
      <source>Call678</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Call">Call</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>43,NOT_402</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_call_verb" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. A verb, meaning "to start a phone call".</comment>
      <extra-loc-engineeringenglish>Call</extra-loc-engineeringenglish>
      <source>Call679</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Call">Call</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_43,402</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_cancel_download" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Cancels the ongoing download.</comment>
      <extra-loc-engineeringenglish>Cancel download</extra-loc-engineeringenglish>
      <source>Cancel download680</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Cancel download">Cancel download</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>54,84,NOT_454</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_change" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to change the highlighted setting.</comment>
      <extra-loc-engineeringenglish>Change</extra-loc-engineeringenglish>
      <source>Change681</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Change">Change</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_chat" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to open a chat with the focused contact.</comment>
      <extra-loc-engineeringenglish>Chat</extra-loc-engineeringenglish>
      <source>Chat682</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Chat">Chat</translation>
      <oldsource>Chat</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_144</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_connect" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Connects to e.g. a remote drive or the selected network or establishes a Bluetooth connection.</comment>
      <extra-loc-engineeringenglish>Connect</extra-loc-engineeringenglish>
      <source>Connect683</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Connect">Connect</translation>
      <oldsource>Connect</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_continue" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Continues the paused or interrupted action, such as playing a video clip, editing the message or setting, etc.</comment>
      <extra-loc-engineeringenglish>Continue</extra-loc-engineeringenglish>
      <source>Continue684</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Continue">Continue</translation>
      <oldsource>Continue</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>72</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_copy" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. The selected text is copied and added to the clipboard.</comment>
      <extra-loc-engineeringenglish>Copy</extra-loc-engineeringenglish>
      <source>Copy685</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Copy">Copy</translation>
      <oldsource>Copy</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>722</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_copy_to_folder" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Copies the selected item to a folder.</comment>
      <extra-loc-engineeringenglish>Copy to folder</extra-loc-engineeringenglish>
      <source>Copy to folder686</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Copy to folder">Copy to folder</translation>
      <oldsource>Copy to folder</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>722</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_create_message" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to create a new message (SMS, MMS, e-mail, etc.).</comment>
      <extra-loc-engineeringenglish>Create message</extra-loc-engineeringenglish>
      <source>Create message687</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Create message">Create message</translation>
      <oldsource>Create message</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_cut" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. The selected text is cut and added to the clipboard.</comment>
      <extra-loc-engineeringenglish>Cut</extra-loc-engineeringenglish>
      <source>Cut688</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Cut">Cut</translation>
      <oldsource>Cut</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>721</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_deactivate" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Deactivates the focused item.</comment>
      <extra-loc-engineeringenglish>Deactivate</extra-loc-engineeringenglish>
      <source>Deactivate689</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Deactivate">Deactivate</translation>
      <oldsource>Deactivate</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>403</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_deactivate_loudspeaker" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Deactivates the loudspeaker.</comment>
      <extra-loc-engineeringenglish>Deactivate loudspeaker</extra-loc-engineeringenglish>
      <source>Deactivate loudspeaker690</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Deactivate loudspeaker">Deactivate loudspeaker</translation>
      <oldsource>Deactivate loudspeaker</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>403,161</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_delete" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Erases something completely from the phone, list, or memory card, for example. Delete should only be used when something in removed permanently.</comment>
      <extra-loc-engineeringenglish>Delete</extra-loc-engineeringenglish>
      <source>Delete691</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Delete">Delete</translation>
      <oldsource>Delete</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>77</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_details" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Opens a view where information about the item is given.</comment>
      <extra-loc-engineeringenglish>Details</extra-loc-engineeringenglish>
      <source>Details692</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Details">Details</translation>
      <oldsource>Details</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>79</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_disable" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to disable the selected item or function.</comment>
      <extra-loc-engineeringenglish>Disable</extra-loc-engineeringenglish>
      <source>Disable693</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Disable">Disable</translation>
      <oldsource>Disable</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_disconnect" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Ends the active connection to e.g a remote drive or the selected network or the Bluetooth connection.</comment>
      <extra-loc-engineeringenglish>Disconnect</extra-loc-engineeringenglish>
      <source>Disconnect694</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Disconnect">Disconnect</translation>
      <oldsource>Disconnect</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_edit" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. The user can open a selected item, such as a name or text, for editing.</comment>
      <extra-loc-engineeringenglish>Edit</extra-loc-engineeringenglish>
      <source>Edit695</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Edit">Edit</translation>
      <oldsource>Edit</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>88</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_enable" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to enable the selected item or function.</comment>
      <extra-loc-engineeringenglish>Enable</extra-loc-engineeringenglish>
      <source>Enable696</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Enable">Enable</translation>
      <oldsource>Enable</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_exit" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. With the exit option, the user can close the currently active application and return to the Home screen.</comment>
      <extra-loc-engineeringenglish>Exit</extra-loc-engineeringenglish>
      <source>Exit697</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Exit">Exit</translation>
      <oldsource>Exit</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>97</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_find" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Opens a find pop-up window after the user has selected this option in the Find application.</comment>
      <extra-loc-engineeringenglish>Find</extra-loc-engineeringenglish>
      <source>Find698</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Find">Find</translation>
      <oldsource>Find</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>101</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_fit_to_screen" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Image is sized to fit to the screen.</comment>
      <extra-loc-engineeringenglish>Fit to screen</extra-loc-engineeringenglish>
      <source>Fit to screen699</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Fit to screen">Fit to screen</translation>
      <oldsource>Fit to screen</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_forward" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Forwards e.g. a message (SMS, MMS, e-mail) or meeting request to another recipient.</comment>
      <extra-loc-engineeringenglish>Forward</extra-loc-engineeringenglish>
      <source>Forward700</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Forward">Forward</translation>
      <oldsource>Forward</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_go_to_web_address" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Opens the defined web address.</comment>
      <extra-loc-engineeringenglish>Go to web address</extra-loc-engineeringenglish>
      <source>Go to web address701</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Go to web address">Go to web address</translation>
      <oldsource>Go to web address</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>114,384</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_insert" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to insert an object such as an image, sound clip, video, recording, number, or symbol to a message, text, or presentation.</comment>
      <extra-loc-engineeringenglish>Insert</extra-loc-engineeringenglish>
      <source>Insert702</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Insert">Insert</translation>
      <oldsource>Insert</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>143</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_install" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to install a file or files.</comment>
      <extra-loc-engineeringenglish>Install</extra-loc-engineeringenglish>
      <source>Install703</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Install">Install</translation>
      <oldsource>Install</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_internet_call" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to make an Internet call.</comment>
      <extra-loc-engineeringenglish>Internet call</extra-loc-engineeringenglish>
      <source>Make internet call704</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Make internet call">Make internet call</translation>
      <oldsource>Make internet call</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_43,NOT_402,145</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_mark" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to mark one or more items in a list.</comment>
      <extra-loc-engineeringenglish>Mark</extra-loc-engineeringenglish>
      <source>Mark705</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Mark">Mark</translation>
      <oldsource>Mark</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>167</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_move" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Moves the selected item to another location inside a grid or a list.</comment>
      <extra-loc-engineeringenglish>Move</extra-loc-engineeringenglish>
      <source>Move706</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Move">Move</translation>
      <oldsource>Move</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>184</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_move_to_folder" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Moves an item to a selected folder.</comment>
      <extra-loc-engineeringenglish>Move to folder</extra-loc-engineeringenglish>
      <source>Move to folder707</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Move to folder">Move to folder</translation>
      <oldsource>Move to folder</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>184</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_open" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Opens a highlighted item such as an application, folder, or message</comment>
      <extra-loc-engineeringenglish>Open</extra-loc-engineeringenglish>
      <source>Open708</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Open">Open</translation>
      <oldsource>Open</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>210</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_organise" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to move items and folders.</comment>
      <extra-loc-engineeringenglish>Organise</extra-loc-engineeringenglish>
      <source>Organise709</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Organise">Organise</translation>
      <oldsource>Organise</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>624</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_paste" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to paste the copied or cut data in the clipboard to the selected place.</comment>
      <extra-loc-engineeringenglish>Paste</extra-loc-engineeringenglish>
      <source>Paste710</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Paste">Paste</translation>
      <oldsource>Paste</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>723</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_pause" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Pauses the ongoing action, such as playing an audio or video clip or presentation.</comment>
      <extra-loc-engineeringenglish>Pause</extra-loc-engineeringenglish>
      <source>Pause711</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Pause">Pause</translation>
      <oldsource>Pause</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_play_music" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. For playing music tracks and other audio.</comment>
      <extra-loc-engineeringenglish>Play</extra-loc-engineeringenglish>
      <source>Play712</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Play">Play</translation>
      <oldsource>Play</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_play_video" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. For playing video.</comment>
      <extra-loc-engineeringenglish>Play</extra-loc-engineeringenglish>
      <source>Play713</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Play">Play</translation>
      <oldsource>Play</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_preview_audio" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to preview the focused music track or other audio item.</comment>
      <extra-loc-engineeringenglish>Preview</extra-loc-engineeringenglish>
      <source>Preview714</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Preview">Preview</translation>
      <oldsource>Preview</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_preview_video" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to preview the focused video item.</comment>
      <extra-loc-engineeringenglish>Preview</extra-loc-engineeringenglish>
      <source>Preview715</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Preview">Preview</translation>
      <oldsource>Preview</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_print" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Starts printing of an item (e.g. image).</comment>
      <extra-loc-engineeringenglish>Print</extra-loc-engineeringenglish>
      <source>Print716</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Print">Print</translation>
      <oldsource>Print</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_remove" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Takes something away from a certain list or group, but does not completely erase it from the phone.</comment>
      <extra-loc-engineeringenglish>Remove</extra-loc-engineeringenglish>
      <source>Remove717</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Remove">Remove</translation>
      <oldsource>Remove</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>266</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_rename_item" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows user to rename the selected item (file, folder, music track, image etc.).</comment>
      <extra-loc-engineeringenglish>Rename</extra-loc-engineeringenglish>
      <source>Rename718</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Rename">Rename</translation>
      <oldsource>Rename</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_rename_people" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows user to define a new name for one or more persons.</comment>
      <extra-loc-engineeringenglish>Rename</extra-loc-engineeringenglish>
      <source>Rename719</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Rename">Rename</translation>
      <oldsource>Rename</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_replace" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to replace text.</comment>
      <extra-loc-engineeringenglish>Replace</extra-loc-engineeringenglish>
      <source>Replace720</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Replace">Replace</translation>
      <oldsource>Replace</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_save" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Lets the user store the changes made or new items or entries added.</comment>
      <extra-loc-engineeringenglish>Save</extra-loc-engineeringenglish>
      <source>Save721</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Save">Save</translation>
      <oldsource>Save</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>273</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_save_to_contacts" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Saves the selected item to Contacts.</comment>
      <extra-loc-engineeringenglish>Save to Contacts</extra-loc-engineeringenglish>
      <source>Save to Contacts722</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Save to Contacts">Save to Contacts</translation>
      <oldsource>Save to Contacts</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_70,71,273</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_select" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Lets the user choose the focused item from a list.</comment>
      <extra-loc-engineeringenglish>Select</extra-loc-engineeringenglish>
      <source>Select723</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Select">Select</translation>
      <oldsource>Select</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>280</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_send_item" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Sends the selected item.</comment>
      <extra-loc-engineeringenglish>Send</extra-loc-engineeringenglish>
      <source>Send724</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Send">Send</translation>
      <oldsource>Send</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>281</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_send_message" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to send a message (SMS, MMS, e-mail etc.).</comment>
      <extra-loc-engineeringenglish>Send message</extra-loc-engineeringenglish>
      <source>Send message725</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Send message">Send message</translation>
      <oldsource>Send message</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>281</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_settings" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Opens a view where the user can change the settings of applications, features, and services.</comment>
      <extra-loc-engineeringenglish>Settings</extra-loc-engineeringenglish>
      <source>Settings726</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Settings">Settings</translation>
      <oldsource>Settings</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_290,291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_undo" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Undoes the previous operation or edit.</comment>
      <extra-loc-engineeringenglish>Undo</extra-loc-engineeringenglish>
      <source>Undo727</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Undo">Undo</translation>
      <oldsource>Undo</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_uninstall" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to uninstall files or programs.</comment>
      <extra-loc-engineeringenglish>Uninstall</extra-loc-engineeringenglish>
      <source>Uninstall728</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Uninstall">Uninstall</translation>
      <oldsource>Uninstall</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_unmark" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to select one or more items in a list to be unmarked. </comment>
      <extra-loc-engineeringenglish>Unmark</extra-loc-engineeringenglish>
      <source>Unmark729</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Unmark">Unmark</translation>
      <oldsource>Unmark</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>348</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_unmute" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to unmute a muted phone's microphones.</comment>
      <extra-loc-engineeringenglish>Unmute</extra-loc-engineeringenglish>
      <source>Unmute730</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Unmute">Unmute</translation>
      <oldsource>Unmute</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_video_call" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to make a video call.</comment>
      <extra-loc-engineeringenglish>Video call</extra-loc-engineeringenglish>
      <source>Make video call731</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Make video call">Make video call</translation>
      <oldsource>Make video call</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_43,NOT_402,359</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_voice_call" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to make a voice call.</comment>
      <extra-loc-engineeringenglish>Voice call</extra-loc-engineeringenglish>
      <source>Make voice call732</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Make voice call">Make voice call</translation>
      <oldsource>Make voice call</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_43,NOT_402</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_zoom_in" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Increases the size of an image on the display.</comment>
      <extra-loc-engineeringenglish>Zoom in</extra-loc-engineeringenglish>
      <source>Zoom in733</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Zoom in">Zoom in</translation>
      <oldsource>Zoom in</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>396</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_zoom_out" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Decreases the size of an image on the display. </comment>
      <extra-loc-engineeringenglish>Zoom out</extra-loc-engineeringenglish>
      <source>Zoom out734</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Zoom out">Zoom out</translation>
      <oldsource>Zoom out</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>456</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_about_application" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. About application. Opens a view where information about the application is given.</comment>
      <extra-loc-engineeringenglish>About application</extra-loc-engineeringenglish>
      <source>About application735</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="About application">About application</translation>
      <oldsource>About application</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>3</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_activate" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Activates the focused call diverting item or call barring. </comment>
      <extra-loc-engineeringenglish>Activate</extra-loc-engineeringenglish>
      <source>Activate736</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Activate">Activate</translation>
      <oldsource>Activate</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>542</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_activate_handsfree" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Switches the call from loudspeaker or handsfree to handset.</comment>
      <extra-loc-engineeringenglish>Activate handset</extra-loc-engineeringenglish>
      <source>Activate handset737</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Activate handset">Activate handset</translation>
      <oldsource>Activate handset</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>542,NOT_121,490</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_activate_loudspeaker" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Switches the call from handset or handsfree to loudspeaker.</comment>
      <extra-loc-engineeringenglish>Activate loudspeaker</extra-loc-engineeringenglish>
      <source>Activate loudspeaker738</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Activate loudspeaker">Activate loudspeaker</translation>
      <oldsource>Activate loudspeaker</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>542,161</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_add_bookmark" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to add a bookmark.</comment>
      <extra-loc-engineeringenglish>Add bookmark</extra-loc-engineeringenglish>
      <source>Save as bookmark739</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Save as bookmark">Save as bookmark</translation>
      <oldsource>Add bookmark</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>39</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_add_detail" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to add a new item (i.e. a piece of information) for e.g. a meeting request or contact.</comment>
      <extra-loc-engineeringenglish>Add detail</extra-loc-engineeringenglish>
      <source>Add detail740</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Add detail">Add detail</translation>
      <oldsource>Add detail</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_add_from_contacts" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Opens Contacts application where the user can select contact information.</comment>
      <extra-loc-engineeringenglish>Add from Contacts</extra-loc-engineeringenglish>
      <source>Add from Contacts741</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Add from Contacts">Add from Contacts</translation>
      <oldsource>Add from Contacts</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_70,71</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_add_image" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allow user to add image from e.g. Photos.</comment>
      <extra-loc-engineeringenglish>Add image</extra-loc-engineeringenglish>
      <source>Add image742</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Add image">Add image</translation>
      <oldsource>Add image</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>133</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_add_member" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to add a member to a group.</comment>
      <extra-loc-engineeringenglish>Add member</extra-loc-engineeringenglish>
      <source>Add member743</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Add member">Add member</translation>
      <oldsource>Add member</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_add_recipient" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to add a recipient to the current message.</comment>
      <extra-loc-engineeringenglish>Add recipient</extra-loc-engineeringenglish>
      <source>Add recipient744</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Add recipient">Add recipient</translation>
      <oldsource>Add recipient</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_add_thumbnail" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows to add or change a thumbnail image for e.g. a member, group or memory.</comment>
      <extra-loc-engineeringenglish>Add thumbnail</extra-loc-engineeringenglish>
      <source>Add thumbnail745</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Add thumbnail">Add thumbnail</translation>
      <oldsource>Add thumbnail</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>336</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_add_to_contacts" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Opens Contacts application where the user can select contact information.</comment>
      <extra-loc-engineeringenglish>Add to Contacts</extra-loc-engineeringenglish>
      <source>Save to Contacts746</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Save to Contacts">Save to Contacts</translation>
      <oldsource>Save to Contacts</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_70,71,273</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_add_to_folder" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to add an item into a folder.</comment>
      <extra-loc-engineeringenglish>Add to folder</extra-loc-engineeringenglish>
      <source>Add to folder747</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Add to folder">Add to folder</translation>
      <oldsource>Add to folder</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_additional_details" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to view additional details of the selected item.</comment>
      <extra-loc-engineeringenglish>Additional details</extra-loc-engineeringenglish>
      <source>More info748</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="More info">More info</translation>
      <oldsource>More info</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_advanced_settings" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Opens a view where the user can edit advanced settings.</comment>
      <extra-loc-engineeringenglish>Advanced settings</extra-loc-engineeringenglish>
      <source>Advanced settings749</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Advanced settings">Advanced settings</translation>
      <oldsource>Advanced settings</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>290,NOT_291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_attachments" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Opens a view where attachments can be added or opened.</comment>
      <extra-loc-engineeringenglish>Attachments</extra-loc-engineeringenglish>
      <source>Attachments750</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Attachments">Attachments</translation>
      <oldsource>Attachments</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>21</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_automatic_find_off" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Switches off the automatic find function.</comment>
      <extra-loc-engineeringenglish>Automatic find off</extra-loc-engineeringenglish>
      <source>Automatic find off751</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Automatic find off">Automatic find off</translation>
      <oldsource>Automatic find off</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_101</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_automatic_find_on" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Switches on the automatic find function.</comment>
      <extra-loc-engineeringenglish>Automatic find on</extra-loc-engineeringenglish>
      <source>Automatic find on752</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Automatic find on">Automatic find on</translation>
      <oldsource>Automatic find on</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_101</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_back" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Returns the user to the previous view.</comment>
      <extra-loc-engineeringenglish>Back</extra-loc-engineeringenglish>
      <source>Back753</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Back">Back</translation>
      <oldsource>Back</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>30</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_call_noun" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. A noun meaning a connection between the caller and the called party or parties; a phone call.</comment>
      <extra-loc-engineeringenglish>Call</extra-loc-engineeringenglish>
      <source>Call754</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Call">Call</translation>
      <oldsource>Call</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>43,NOT_402</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_call_verb" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. A verb, meaning "to start a phone call".</comment>
      <extra-loc-engineeringenglish>Call</extra-loc-engineeringenglish>
      <source>Call755</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Call">Call</translation>
      <oldsource>Call</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_43,402</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_cancel_download" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Cancels the ongoing download.</comment>
      <extra-loc-engineeringenglish>Cancel download</extra-loc-engineeringenglish>
      <source>Cancel download756</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Cancel download">Cancel download</translation>
      <oldsource>Cancel download</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>54,84,NOT_454</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_change" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to change the highlighted setting.</comment>
      <extra-loc-engineeringenglish>Change</extra-loc-engineeringenglish>
      <source>Change757</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Change">Change</translation>
      <oldsource>Change</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_chat" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to open a chat with the focused contact.</comment>
      <extra-loc-engineeringenglish>Chat</extra-loc-engineeringenglish>
      <source>Chat758</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Chat">Chat</translation>
      <oldsource>Chat</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_144</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_connect" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Connects to e.g. a remote drive or the selected network or establishes a Bluetooth connection.</comment>
      <extra-loc-engineeringenglish>Connect</extra-loc-engineeringenglish>
      <source>Connect759</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Connect">Connect</translation>
      <oldsource>Connect</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_continue" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Continues the paused or interrupted action, such as playing a video clip, editing the message or setting, etc.</comment>
      <extra-loc-engineeringenglish>Continue</extra-loc-engineeringenglish>
      <source>Continue760</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Continue">Continue</translation>
      <oldsource>Continue</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>72</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_copy" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. The selected text is copied and added to the clipboard.</comment>
      <extra-loc-engineeringenglish>Copy</extra-loc-engineeringenglish>
      <source>Copy761</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Copy">Copy</translation>
      <oldsource>Copy</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>722</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_copy_to_folder" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Copies the selected item to a folder.</comment>
      <extra-loc-engineeringenglish>Copy to folder</extra-loc-engineeringenglish>
      <source>Copy to folder762</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Copy to folder">Copy to folder</translation>
      <oldsource>Copy to folder</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>722</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_create_message" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to create a new message (SMS, MMS, e-mail, etc.).</comment>
      <extra-loc-engineeringenglish>Create message</extra-loc-engineeringenglish>
      <source>Create message763</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Create message">Create message</translation>
      <oldsource>Create message</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_cut" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. The selected text is cut and added to the clipboard.</comment>
      <extra-loc-engineeringenglish>Cut</extra-loc-engineeringenglish>
      <source>Cut764</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Cut">Cut</translation>
      <oldsource>Cut</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>721</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_deactivate" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Deactivates the focused item.</comment>
      <extra-loc-engineeringenglish>Deactivate</extra-loc-engineeringenglish>
      <source>Deactivate765</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Deactivate">Deactivate</translation>
      <oldsource>Deactivate</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>403</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_deactivate_loudspeaker" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Deactivates the loudspeaker.</comment>
      <extra-loc-engineeringenglish>Deactivate loudspeaker</extra-loc-engineeringenglish>
      <source>Deactivate loudspeaker766</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Deactivate loudspeaker">Deactivate loudspeaker</translation>
      <oldsource>Deactivate loudspeaker</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>403,161</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_delete" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Erases something completely from the phone, list, or memory card, for example. Delete should only be used when something in removed permanently.</comment>
      <extra-loc-engineeringenglish>Delete</extra-loc-engineeringenglish>
      <source>Delete767</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Delete">Delete</translation>
      <oldsource>Delete</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>77</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_details" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Opens a view where information about the item is given.</comment>
      <extra-loc-engineeringenglish>Details</extra-loc-engineeringenglish>
      <source>Details768</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Details">Details</translation>
      <oldsource>Details</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>79</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_disable" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to disable the selected item or function.</comment>
      <extra-loc-engineeringenglish>Disable</extra-loc-engineeringenglish>
      <source>Disable769</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Disable">Disable</translation>
      <oldsource>Disable</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_disconnect" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Ends the active connection to e.g a remote drive or the selected network or the Bluetooth connection.</comment>
      <extra-loc-engineeringenglish>Disconnect</extra-loc-engineeringenglish>
      <source>Disconnect770</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Disconnect">Disconnect</translation>
      <oldsource>Disconnect</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_edit" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. The user can open a selected item, such as a name or text, for editing.</comment>
      <extra-loc-engineeringenglish>Edit</extra-loc-engineeringenglish>
      <source>Edit771</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Edit">Edit</translation>
      <oldsource>Edit</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>88</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_enable" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to enable the selected item or function.</comment>
      <extra-loc-engineeringenglish>Enable</extra-loc-engineeringenglish>
      <source>Enable772</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Enable">Enable</translation>
      <oldsource>Enable</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_exit" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. With the exit option, the user can close the currently active application and return to the Home screen.</comment>
      <extra-loc-engineeringenglish>Exit</extra-loc-engineeringenglish>
      <source>Exit773</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Exit">Exit</translation>
      <oldsource>Exit</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>97</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_find" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Opens a find pop-up window after the user has selected this option in the Find application.</comment>
      <extra-loc-engineeringenglish>Find</extra-loc-engineeringenglish>
      <source>Find774</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Find">Find</translation>
      <oldsource>Find</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>101</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_fit_to_screen" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Image is sized to fit to the screen.</comment>
      <extra-loc-engineeringenglish>Fit to screen</extra-loc-engineeringenglish>
      <source>Fit to screen775</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Fit to screen">Fit to screen</translation>
      <oldsource>Fit to screen</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_forward" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Forwards e.g. a message (SMS, MMS, e-mail) or meeting request to another recipient.</comment>
      <extra-loc-engineeringenglish>Forward</extra-loc-engineeringenglish>
      <source>Forward776</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Forward">Forward</translation>
      <oldsource>Forward</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_go_to_web_address" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Opens the defined web address.</comment>
      <extra-loc-engineeringenglish>Go to web address</extra-loc-engineeringenglish>
      <source>Go to web address777</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Go to web address">Go to web address</translation>
      <oldsource>Go to web address</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>114,384</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_help" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Opens a help dialog.</comment>
      <extra-loc-engineeringenglish>Help</extra-loc-engineeringenglish>
      <source>User guide778</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="User guide">User guide</translation>
      <oldsource>User guide</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>758</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_insert" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to insert an object such as an image, sound clip, video, recording, number, or symbol to a message, text, or presentation.</comment>
      <extra-loc-engineeringenglish>Insert</extra-loc-engineeringenglish>
      <source>Insert779</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Insert">Insert</translation>
      <oldsource>Insert</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>143</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_install" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to install a file or files.</comment>
      <extra-loc-engineeringenglish>Install</extra-loc-engineeringenglish>
      <source>Install780</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Install">Install</translation>
      <oldsource>Install</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_internet_call" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to make an Internet call.</comment>
      <extra-loc-engineeringenglish>Internet call</extra-loc-engineeringenglish>
      <source>Make internet call781</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Make internet call">Make internet call</translation>
      <oldsource>Make internet call</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_43,NOT_402,145</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_mark" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to mark one or more items in a list.</comment>
      <extra-loc-engineeringenglish>Mark</extra-loc-engineeringenglish>
      <source>Mark782</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Mark">Mark</translation>
      <oldsource>Mark</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>167</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_move" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Moves the selected item to another location inside a grid or a list.</comment>
      <extra-loc-engineeringenglish>Move</extra-loc-engineeringenglish>
      <source>Move783</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Move">Move</translation>
      <oldsource>Move</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>184</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_move_to_folder" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Moves an item to a selected folder.</comment>
      <extra-loc-engineeringenglish>Move to folder</extra-loc-engineeringenglish>
      <source>Move to folder784</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Move to folder">Move to folder</translation>
      <oldsource>Move to folder</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>184</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_open" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Opens a highlighted item such as an application, folder, or message</comment>
      <extra-loc-engineeringenglish>Open</extra-loc-engineeringenglish>
      <source>Open785</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Open">Open</translation>
      <oldsource>Open</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>210</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_organise" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to move items and folders.</comment>
      <extra-loc-engineeringenglish>Organise</extra-loc-engineeringenglish>
      <source>Organise786</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Organise">Organise</translation>
      <oldsource>Organise</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>624</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_paste" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to paste the copied or cut data in the clipboard to the selected place.</comment>
      <extra-loc-engineeringenglish>Paste</extra-loc-engineeringenglish>
      <source>Paste787</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Paste">Paste</translation>
      <oldsource>Paste</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>723</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_pause" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Pauses the ongoing action, such as playing an audio or video clip or presentation.</comment>
      <extra-loc-engineeringenglish>Pause</extra-loc-engineeringenglish>
      <source>Pause788</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Pause">Pause</translation>
      <oldsource>Pause</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_play_music" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. For playing music tracks and other audio.</comment>
      <extra-loc-engineeringenglish>Play</extra-loc-engineeringenglish>
      <source>Play789</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Play">Play</translation>
      <oldsource>Play</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_play_video" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. For playing video.</comment>
      <extra-loc-engineeringenglish>Play</extra-loc-engineeringenglish>
      <source>Play790</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Play">Play</translation>
      <oldsource>Play</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_preview_audio" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to preview the focused music track or other audio item.</comment>
      <extra-loc-engineeringenglish>Preview</extra-loc-engineeringenglish>
      <source>Preview791</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Preview">Preview</translation>
      <oldsource>Preview</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_preview_video" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to preview the focused video item.</comment>
      <extra-loc-engineeringenglish>Preview</extra-loc-engineeringenglish>
      <source>Preview792</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Preview">Preview</translation>
      <oldsource>Preview</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_print" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Starts printing of an item (e.g. image).</comment>
      <extra-loc-engineeringenglish>Print</extra-loc-engineeringenglish>
      <source>Print793</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Print">Print</translation>
      <oldsource>Print</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_remove" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Takes something away from a certain list or group, but does not completely erase it from the phone.</comment>
      <extra-loc-engineeringenglish>Remove</extra-loc-engineeringenglish>
      <source>Remove794</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Remove">Remove</translation>
      <oldsource>Remove</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>266</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_rename_item" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows user to rename the selected item (file, folder, music track, image etc.).</comment>
      <extra-loc-engineeringenglish>Rename</extra-loc-engineeringenglish>
      <source>Rename795</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Rename">Rename</translation>
      <oldsource>Rename</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_rename_people" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows user to define a new name for one or more persons.</comment>
      <extra-loc-engineeringenglish>Rename</extra-loc-engineeringenglish>
      <source>Rename796</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Rename">Rename</translation>
      <oldsource>Rename</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_replace" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to replace text.</comment>
      <extra-loc-engineeringenglish>Replace</extra-loc-engineeringenglish>
      <source>Replace797</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Replace">Replace</translation>
      <oldsource>Replace</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_save" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Lets the user store the changes made or new items or entries added.</comment>
      <extra-loc-engineeringenglish>Save</extra-loc-engineeringenglish>
      <source>Save798</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Save">Save</translation>
      <oldsource>Save</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>273</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_save_to_contacts" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Saves the selected item to Contacts.</comment>
      <extra-loc-engineeringenglish>Save to Contacts</extra-loc-engineeringenglish>
      <source>Save to Contacts799</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Save to Contacts">Save to Contacts</translation>
      <oldsource>Save to Contacts</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_70,71,273</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_select" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Lets the user choose the focused item from a list.</comment>
      <extra-loc-engineeringenglish>Select</extra-loc-engineeringenglish>
      <source>Select800</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Select">Select</translation>
      <oldsource>Select</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>280</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_send_item" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Sends the selected item.</comment>
      <extra-loc-engineeringenglish>Send</extra-loc-engineeringenglish>
      <source>Send801</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Send">Send</translation>
      <oldsource>Send</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>281</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_send_message" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to send a message (SMS, MMS, e-mail etc.).</comment>
      <extra-loc-engineeringenglish>Send message</extra-loc-engineeringenglish>
      <source>Send message802</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Send message">Send message</translation>
      <oldsource>Send message</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>281</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_settings" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Opens a view where the user can change the settings of applications, features, and services.</comment>
      <extra-loc-engineeringenglish>Settings</extra-loc-engineeringenglish>
      <source>Settings803</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Settings">Settings</translation>
      <oldsource>Settings</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_290,291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_undo" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Undoes the previous operation or edit.</comment>
      <extra-loc-engineeringenglish>Undo</extra-loc-engineeringenglish>
      <source>Undo804</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Undo">Undo</translation>
      <oldsource>Undo</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_uninstall" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to uninstall files or programs.</comment>
      <extra-loc-engineeringenglish>Uninstall</extra-loc-engineeringenglish>
      <source>Uninstall805</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Uninstall">Uninstall</translation>
      <oldsource>Uninstall</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_unmark" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to select one or more items in a list to be unmarked. </comment>
      <extra-loc-engineeringenglish>Unmark</extra-loc-engineeringenglish>
      <source>Unmark806</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Unmark">Unmark</translation>
      <oldsource>Unmark</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>348</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_unmute" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to unmute a muted phone's microphones.</comment>
      <extra-loc-engineeringenglish>Unmute</extra-loc-engineeringenglish>
      <source>Unmute807</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Unmute">Unmute</translation>
      <oldsource>Unmute</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_video_call" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to make a video call.</comment>
      <extra-loc-engineeringenglish>Video call</extra-loc-engineeringenglish>
      <source>Make video call808</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Make video call">Make video call</translation>
      <oldsource>Make video call</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_43,NOT_402,359</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_voice_call" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to make a voice call.</comment>
      <extra-loc-engineeringenglish>Voice call</extra-loc-engineeringenglish>
      <source>Make voice call809</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Make voice call">Make voice call</translation>
      <oldsource>Make voice call</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_43,NOT_402,370</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_zoom_in" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Increases the size of an image on the display.</comment>
      <extra-loc-engineeringenglish>Zoom in</extra-loc-engineeringenglish>
      <source>Zoom in810</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Zoom in">Zoom in</translation>
      <oldsource>Zoom in</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>396</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_zoom_out" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Decreases the size of an image on the display. </comment>
      <extra-loc-engineeringenglish>Zoom out</extra-loc-engineeringenglish>
      <source>Zoom out811</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="Zoom out">Zoom out</translation>
      <oldsource>Zoom out</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>456</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
  </context>
</TS>