<?xml version="1.0" encoding="utf-8"?>
<TS xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" version="1.0" sourcelanguage="English-GB" language="English-GB_(apac)">
  <extra-loc-extended xsi:type="xsd:boolean">true</extra-loc-extended>
  <defaultcodec />
  <extra-loc-feature xsi:type="xsd:string">common@dfsxx.01</extra-loc-feature>
  <extra-loc-style xsi:type="xsd:string">ts</extra-loc-style>
  <context>
    <name>Prophet</name>
    <message numerus="no" id="txt_common_button_activate_object" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to take something into use (for example, activate a profile or music player Equalizer settings).</comment>
      <extra-loc-engineeringenglish>Activate</extra-loc-engineeringenglish>
      <source>Activate690</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Activate</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>542</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_activate_process" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to start a process (for example, the countdown for the camera self-timer).</comment>
      <extra-loc-engineeringenglish>Activate</extra-loc-engineeringenglish>
      <source>Activate691</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Activate</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>542</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_add" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to add an item, for example adding a song to playlist or a person into a chat group.</comment>
      <extra-loc-engineeringenglish>Add</extra-loc-engineeringenglish>
      <source>Add692</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Add</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_answer" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the dialog. Allows the user to answer an incoming call.</comment>
      <extra-loc-engineeringenglish>Answer</extra-loc-engineeringenglish>
      <source>Answer693</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Answer</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_softkey_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_softkey_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_answer_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to answer an incoming call.</comment>
      <extra-loc-engineeringenglish>Answer</extra-loc-engineeringenglish>
      <source>Answer694</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">English-GB_(apac) #Answer</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_back" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Returns the user to the previous view.</comment>
      <extra-loc-engineeringenglish>Back</extra-loc-engineeringenglish>
      <source>Back695</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Back</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>30</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_call" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. This string only refers to the verb "to call". Allows the user to start a call by pressing the button.</comment>
      <extra-loc-engineeringenglish>Call</extra-loc-engineeringenglish>
      <source>Call696</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Call</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_43,402</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_cancel" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the dialog. Allows the user to cancel the action or process.</comment>
      <extra-loc-engineeringenglish>Cancel</extra-loc-engineeringenglish>
      <source>Cancel697</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">&lt;TR-PLACEHOLDER&gt;</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_softkey_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_softkey_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>54</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_cancel_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to cancel the action or process.</comment>
      <extra-loc-engineeringenglish>Cancel</extra-loc-engineeringenglish>
      <source>Cancel698</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">English-GB_(apac) #Cancel</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_change" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to change the selected item.</comment>
      <extra-loc-engineeringenglish>Change</extra-loc-engineeringenglish>
      <source>Change699</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Change</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_clear" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the dialog. Allows the user to clear text from an editing field.</comment>
      <extra-loc-engineeringenglish>Clear</extra-loc-engineeringenglish>
      <source>Clear700</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Clear</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_softkey_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_softkey_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>60</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_clear_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to clear text from an editing field.</comment>
      <extra-loc-engineeringenglish>Clear</extra-loc-engineeringenglish>
      <source>Clear701</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">English-GB_(apac) #Clear</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_close" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to close e.g. a window.</comment>
      <extra-loc-engineeringenglish>Close</extra-loc-engineeringenglish>
      <source>Close702</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Close</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>62</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_collapse" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to for example collapse a sorted list.</comment>
      <extra-loc-engineeringenglish>Collapse</extra-loc-engineeringenglish>
      <source>Collapse703</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">&lt;TR-PLACEHOLDER&gt;</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_connect" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to connect to a service.</comment>
      <extra-loc-engineeringenglish>Connect</extra-loc-engineeringenglish>
      <source>Connect704</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Connect</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_continue" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Displayed for example when the user is recording or playing a video or audio track or a slideshow and has paused the activity. When the user presses this button the recording or playing will continue.</comment>
      <extra-loc-engineeringenglish>Continue</extra-loc-engineeringenglish>
      <source>Continue705</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Continue</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>72</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_copy" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to copy and add the selected item into the clipboard.</comment>
      <extra-loc-engineeringenglish>Copy</extra-loc-engineeringenglish>
      <source>Copy706</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Copy</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>722</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_deactivate" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to deactivate the focused item.</comment>
      <extra-loc-engineeringenglish>Deactivate</extra-loc-engineeringenglish>
      <source>Deactivate707</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Deactivate</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>403</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_define" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to define a value.</comment>
      <extra-loc-engineeringenglish>Define</extra-loc-engineeringenglish>
      <source>Define708</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Define</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_delete" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the dialog. Allows the user to delete an item. Note that deleting removes the item permanently from memory.</comment>
      <extra-loc-engineeringenglish>Delete</extra-loc-engineeringenglish>
      <source>Delete709</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Delete</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_softkey_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_softkey_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>77</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_delete_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to delete an item. Note that deleting removes the item permanently from memory.</comment>
      <extra-loc-engineeringenglish>Delete</extra-loc-engineeringenglish>
      <source>Delete710</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">English-GB_(apac) #Delete</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_details" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. With this command the user can view the details of the selected item.</comment>
      <extra-loc-engineeringenglish>Details</extra-loc-engineeringenglish>
      <source>Details711</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Details</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>79</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_disable" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to disable the selected item or function.</comment>
      <extra-loc-engineeringenglish>Disable</extra-loc-engineeringenglish>
      <source>Disable712</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Disable</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_disconnect" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to disconnect from an existing connection.</comment>
      <extra-loc-engineeringenglish>Disconnect</extra-loc-engineeringenglish>
      <source>Disconnect713</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Disconnect</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_edit" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to edit an item, for example a filename or a message.</comment>
      <extra-loc-engineeringenglish>Edit</extra-loc-engineeringenglish>
      <source>Edit714</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Edit</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>88</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_enable" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to enable the selected item or function.</comment>
      <extra-loc-engineeringenglish>Enable</extra-loc-engineeringenglish>
      <source>Enable715</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Enable</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_exit" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. With the exit button, the user can close the currently active application and return to the Home screen.</comment>
      <extra-loc-engineeringenglish>Exit</extra-loc-engineeringenglish>
      <source>Exit716</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Exit</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>97</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_expand" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to for example expand a collapsed sorted list.</comment>
      <extra-loc-engineeringenglish>Expand</extra-loc-engineeringenglish>
      <source>Expand717</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Expand</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_find" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to begin a search in the current application or view.</comment>
      <extra-loc-engineeringenglish>Find</extra-loc-engineeringenglish>
      <source>Find718</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Find</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>101</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_finish" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. This button allows the user to finish the operation, for example to confirm and save changed settings.</comment>
      <extra-loc-engineeringenglish>Finish</extra-loc-engineeringenglish>
      <source>Finish719</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Finish</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_handset" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to change the audio (music, a call) from e.g. a loudspeaker to the handset.</comment>
      <extra-loc-engineeringenglish>Handset</extra-loc-engineeringenglish>
      <source>Activate handset720</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Activate handset</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>542,NOT_121,490</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_help" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to open Help.</comment>
      <extra-loc-engineeringenglish>Help</extra-loc-engineeringenglish>
      <source>User guide721</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">User guide</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>758</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_hide" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the dialog. Allows the user to hide an item.</comment>
      <extra-loc-engineeringenglish>Hide</extra-loc-engineeringenglish>
      <source>Hide722</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Hide</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_softkey_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_softkey_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_hide_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to hide an item.</comment>
      <extra-loc-engineeringenglish>Hide</extra-loc-engineeringenglish>
      <source>Hide723</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">English-GB_(apac) #Hide</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_insert" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to insert an item. This can be used for example for inserting a file into a presentation.</comment>
      <extra-loc-engineeringenglish>Insert</extra-loc-engineeringenglish>
      <source>Insert724</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Insert</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>143</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_install" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to install a file or files.</comment>
      <extra-loc-engineeringenglish>Install</extra-loc-engineeringenglish>
      <source>Install725</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Install</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_join" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to join the selected chat group.</comment>
      <extra-loc-engineeringenglish>Join</extra-loc-engineeringenglish>
      <source>Join726</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Join</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_listen" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to listen to for example messages in voice mailbox.</comment>
      <extra-loc-engineeringenglish>Listen</extra-loc-engineeringenglish>
      <source>Listen727</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Listen</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_loudspeaker_off" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to turn the loudspeaker off.</comment>
      <extra-loc-engineeringenglish>Loudsp. off</extra-loc-engineeringenglish>
      <source>Loudspeaker off728</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Loudspeaker off</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>161</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_loudspeaker_on" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to turn the loudspeaker on.</comment>
      <extra-loc-engineeringenglish>Loudsp. on</extra-loc-engineeringenglish>
      <source>Loudspeaker on729</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Loudspeaker on</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>161</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_mark" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to mark an item for further action. For example selecting file to be sent or deleting it.</comment>
      <extra-loc-engineeringenglish>Mark</extra-loc-engineeringenglish>
      <source>Mark730</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Mark</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>167</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_menu" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to open a menu.</comment>
      <extra-loc-engineeringenglish>Menu</extra-loc-engineeringenglish>
      <source>Menu731</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Menu</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>175</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_move" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to move the selected item.</comment>
      <extra-loc-engineeringenglish>Move</extra-loc-engineeringenglish>
      <source>Move732</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Move</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>184</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_mute" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to mute the phone's microphones.</comment>
      <extra-loc-engineeringenglish>Mute</extra-loc-engineeringenglish>
      <source>Mute733</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Mute</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_no" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the dialog. Pressing this button rejects the selected operation.</comment>
      <extra-loc-engineeringenglish>No</extra-loc-engineeringenglish>
      <source>No734</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">No</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_softkey_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_softkey_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_no_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Pressing this button rejects the selected operation.</comment>
      <extra-loc-engineeringenglish>No</extra-loc-engineeringenglish>
      <source>No735</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">English-GB_(apac) #No</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_ok" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the dialog. When this button is pressed, the focused item or operation will be selected or accepted.</comment>
      <extra-loc-engineeringenglish>OK</extra-loc-engineeringenglish>
      <source>OK736</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">OK</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_softkey_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_softkey_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>208</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_ok_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. When this button is pressed, the focused item or operation will be selected or accepted.</comment>
      <extra-loc-engineeringenglish>OK</extra-loc-engineeringenglish>
      <source>OK737</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">English-GB_(apac) #OK</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_open" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to open the selected item; for example, a file.</comment>
      <extra-loc-engineeringenglish>Open</extra-loc-engineeringenglish>
      <source>Open738</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Open</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>210</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_options" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Pressing this button will open the options menu.</comment>
      <extra-loc-engineeringenglish>Options</extra-loc-engineeringenglish>
      <source>Options739</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Options</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>211</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_paste" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to add the contents of clipboard to the selected place.</comment>
      <extra-loc-engineeringenglish>Paste</extra-loc-engineeringenglish>
      <source>Paste740</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Paste</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>723</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_pause" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to pause the current action. For example, pausing a song or a video.</comment>
      <extra-loc-engineeringenglish>Pause</extra-loc-engineeringenglish>
      <source>Pause741</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Pause</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_play_audio" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to play a music track or other audio.</comment>
      <extra-loc-engineeringenglish>Play</extra-loc-engineeringenglish>
      <source>Play742</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Play</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_play_video" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to play video.</comment>
      <extra-loc-engineeringenglish>Play</extra-loc-engineeringenglish>
      <source>Play743</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Play</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_preview_audio" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to preview the focused music track or other audio item.</comment>
      <extra-loc-engineeringenglish>Preview</extra-loc-engineeringenglish>
      <source>Preview744</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Preview</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_preview_video" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to preview the focused video item.</comment>
      <extra-loc-engineeringenglish>Preview</extra-loc-engineeringenglish>
      <source>Preview745</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Preview</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_quit" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Pressing this button will interrupt the current action and return to the previous state or view.</comment>
      <extra-loc-engineeringenglish>Quit</extra-loc-engineeringenglish>
      <source>Quit746</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Quit</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>545</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_read" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to read the message, e-mail etc.</comment>
      <extra-loc-engineeringenglish>Read</extra-loc-engineeringenglish>
      <source>Read747</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Read</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_record_audio" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to record audio (music, speech etc.).</comment>
      <extra-loc-engineeringenglish>Record</extra-loc-engineeringenglish>
      <source>Record748</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Record</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_record_video" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to record video.</comment>
      <extra-loc-engineeringenglish>Record</extra-loc-engineeringenglish>
      <source>Record749</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Record</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_reject" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the dialog. Allows the user to reject the suggested operation.</comment>
      <extra-loc-engineeringenglish>Reject</extra-loc-engineeringenglish>
      <source>Reject750</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Reject</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_softkey_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_softkey_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_263,404</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_reject_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to reject the suggested operation.</comment>
      <extra-loc-engineeringenglish>Reject</extra-loc-engineeringenglish>
      <source>Reject751</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">English-GB_(apac) #Reject</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_remove" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to remove the selected item (e.g. from a playlist). This does not permanently delete the item from memory.</comment>
      <extra-loc-engineeringenglish>Remove</extra-loc-engineeringenglish>
      <source>Remove752</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Remove</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>266</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_replace" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to replace text.</comment>
      <extra-loc-engineeringenglish>Replace</extra-loc-engineeringenglish>
      <source>Replace753</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Replace</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_reply" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to reply to a message (SMS, e-mail etc.)</comment>
      <extra-loc-engineeringenglish>Reply</extra-loc-engineeringenglish>
      <source>Reply754</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Reply</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_reset" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to reset a timer or clock.</comment>
      <extra-loc-engineeringenglish>Reset</extra-loc-engineeringenglish>
      <source>Reset755</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Reset</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_resume" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Pressing this button resumes the interrupted or paused operation.</comment>
      <extra-loc-engineeringenglish>Resume</extra-loc-engineeringenglish>
      <source>Resume756</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">&lt;TR-PLACEHOLDER&gt;</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_retry" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to try an interrupted or failed action or operation again.</comment>
      <extra-loc-engineeringenglish>Retry</extra-loc-engineeringenglish>
      <source>Retry757</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Retry</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_save" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to save e.g. a file or settings.</comment>
      <extra-loc-engineeringenglish>Save</extra-loc-engineeringenglish>
      <source>Save758</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Save</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>273</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_select" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to select an item or option.</comment>
      <extra-loc-engineeringenglish>Select</extra-loc-engineeringenglish>
      <source>Select759</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Select</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>280</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_send" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the dialog. Allows the user to send a message or an item.</comment>
      <extra-loc-engineeringenglish>Send</extra-loc-engineeringenglish>
      <source>Send760</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Send</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_softkey_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_softkey_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>281</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_send_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to send a message or an item.</comment>
      <extra-loc-engineeringenglish>Send</extra-loc-engineeringenglish>
      <source>Send761</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">English-GB_(apac) #Send</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_settings" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Pressing this button opens Settings view.</comment>
      <extra-loc-engineeringenglish>Settings</extra-loc-engineeringenglish>
      <source>Settings762</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Settings</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>290,NOT_291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_show" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Pressing this button shows a hidden item or items.</comment>
      <extra-loc-engineeringenglish>Show</extra-loc-engineeringenglish>
      <source>Show763</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Show</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_start" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to start an operation.</comment>
      <extra-loc-engineeringenglish>Start</extra-loc-engineeringenglish>
      <source>Start764</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Start</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>320</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_stop" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to stop an operation.</comment>
      <extra-loc-engineeringenglish>Stop</extra-loc-engineeringenglish>
      <source>Stop765</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Stop</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>324</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_uninstall" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to uninstall files or programs.</comment>
      <extra-loc-engineeringenglish>Uninstall</extra-loc-engineeringenglish>
      <source>Uninstall766</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">&lt;TR-PLACEHOLDER&gt;</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_unmark" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to unmark marked files.</comment>
      <extra-loc-engineeringenglish>Unmark</extra-loc-engineeringenglish>
      <source>Unmark767</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Unmark</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>348</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_unmute" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Allows the user to unmute a muted phone's microphones.</comment>
      <extra-loc-engineeringenglish>Unmute</extra-loc-engineeringenglish>
      <source>Unmute768</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Unmute</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_yes" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the dialog. Pressing this button confirms the selected operation.</comment>
      <extra-loc-engineeringenglish>Yes</extra-loc-engineeringenglish>
      <source>Yes769</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Yes</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_softkey_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_softkey_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>395</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_button_yes_toolbar" marked="false">
      <extracomment />
      <location />
      <comment>Button. Note! Use this text ID only if there are max. two buttons in the toolbar. Pressing this button confirms the selected operation.</comment>
      <extra-loc-engineeringenglish>Yes</extra-loc-engineeringenglish>
      <source>Yes770</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">English-GB_(apac) #Yes</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_toolbar_tiny_2</extra-loc-layout_id>
      <extra-loc-layout>qtl_toolbar_tiny_2</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>button</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_address" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter (work, home etc.) address.</comment>
      <extra-loc-engineeringenglish>Address:</extra-loc-engineeringenglish>
      <source>Address:771</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Address:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_384</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_bookmark_name" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter bookmark name.</comment>
      <extra-loc-engineeringenglish>Bookmark name:</extra-loc-engineeringenglish>
      <source>Bookmark name:772</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Bookmark name:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>39</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_current_password" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter current password.</comment>
      <extra-loc-engineeringenglish>Current password:</extra-loc-engineeringenglish>
      <source>Current password:773</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Current password:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>223</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_date" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter date.</comment>
      <extra-loc-engineeringenglish>Date:</extra-loc-engineeringenglish>
      <source>Date:774</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Date:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_duration" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to duration.</comment>
      <extra-loc-engineeringenglish>Duration:</extra-loc-engineeringenglish>
      <source>Duration:775</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Duration:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_end_date" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter end date.</comment>
      <extra-loc-engineeringenglish>End date:</extra-loc-engineeringenglish>
      <source>End date:776</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">End date:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_expires" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter expiration date and time.</comment>
      <extra-loc-engineeringenglish>Expires:</extra-loc-engineeringenglish>
      <source>Expires:777</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Expires:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_file_name" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter file name.</comment>
      <extra-loc-engineeringenglish>File name:</extra-loc-engineeringenglish>
      <source>File name:778</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">File name:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_first_name" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter last name (of a person).</comment>
      <extra-loc-engineeringenglish>Last name:</extra-loc-engineeringenglish>
      <source>Last name:779</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Last name:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_folder_name" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter folder name.</comment>
      <extra-loc-engineeringenglish>Folder name:</extra-loc-engineeringenglish>
      <source>Folder name:780</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Folder name:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_from" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter the time from which something is on.</comment>
      <extra-loc-engineeringenglish>From:</extra-loc-engineeringenglish>
      <source>From:781</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">From:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_from_name1" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter a person's (for instance a contact's) name.</comment>
      <extra-loc-engineeringenglish>Name:</extra-loc-engineeringenglish>
      <source>Name:782</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Name:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_from_name2" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter name of a file, folder, playlist etc.</comment>
      <extra-loc-engineeringenglish>Name:</extra-loc-engineeringenglish>
      <source>Name:783</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Name:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_new_name1" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter new name for a person (for instance a contact)</comment>
      <extra-loc-engineeringenglish>New name:</extra-loc-engineeringenglish>
      <source>New name:784</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">New name:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_new_name2" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter new name for a file, folder, playlist etc.</comment>
      <extra-loc-engineeringenglish>New name:</extra-loc-engineeringenglish>
      <source>New name:785</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">New name:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_new_password" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter a new password.</comment>
      <extra-loc-engineeringenglish>New password:</extra-loc-engineeringenglish>
      <source>New password:786</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">New password:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>223</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_password" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter password.</comment>
      <extra-loc-engineeringenglish>Password:</extra-loc-engineeringenglish>
      <source>Password:787</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Password:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>223</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_phone_number" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter phone number.</comment>
      <extra-loc-engineeringenglish>Phone number:</extra-loc-engineeringenglish>
      <source>Phone number:788</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Phone number:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>228</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_time" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter time value (for instance for a timer).</comment>
      <extra-loc-engineeringenglish>Time:</extra-loc-engineeringenglish>
      <source>Time:789</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Time:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_title" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter title for an e.g. album, music track or video.</comment>
      <extra-loc-engineeringenglish>Title:</extra-loc-engineeringenglish>
      <source>Title:790</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Title:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_to" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter the time until which something is on. </comment>
      <extra-loc-engineeringenglish>To:</extra-loc-engineeringenglish>
      <source>To:791</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">To:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_user_id" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter user ID.</comment>
      <extra-loc-engineeringenglish>User ID:</extra-loc-engineeringenglish>
      <source>User ID:792</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">User ID:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_user_name" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter user name.</comment>
      <extra-loc-engineeringenglish>User name:</extra-loc-engineeringenglish>
      <source>User name:793</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">&lt;TR-PLACEHOLDER&gt;</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>356</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_verify_new_password" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to confirm the change of password in the editing field below this text.</comment>
      <extra-loc-engineeringenglish>Verify new password:</extra-loc-engineeringenglish>
      <source>Verify new password:794</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Verify new password:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>223</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_verify_password" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to confirm the password in the editing field below this text.</comment>
      <extra-loc-engineeringenglish>Verify password:</extra-loc-engineeringenglish>
      <source>Verify password:795</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Verify password:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>223</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_dialog_web_address" marked="false">
      <extracomment />
      <location />
      <comment>Input dialog label. Prompts the user to enter web address.</comment>
      <extra-loc-engineeringenglish>Web address:</extra-loc-engineeringenglish>
      <source>Web address:796</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Web address:</lengthvariant>
      </translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_383,384</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>dialog</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_adding" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being added.</comment>
      <extra-loc-engineeringenglish>Adding</extra-loc-engineeringenglish>
      <source>Adding797</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Adding</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_buffering" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when buffering is in progress.</comment>
      <extra-loc-engineeringenglish>Buffering</extra-loc-engineeringenglish>
      <source>Buffering798</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Buffering</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_cancelling" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being cancelled.</comment>
      <extra-loc-engineeringenglish>Cancelling</extra-loc-engineeringenglish>
      <source>Cancelling799</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Cancelling</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>54</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_closing" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being closed.</comment>
      <extra-loc-engineeringenglish>Closing</extra-loc-engineeringenglish>
      <source>Closing800</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Closing</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>62</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_connecting" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when the device is connecting to for example a server, another device etc.</comment>
      <extra-loc-engineeringenglish>Connecting</extra-loc-engineeringenglish>
      <source>Connecting801</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Connecting</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_copying" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being copied.</comment>
      <extra-loc-engineeringenglish>Copying</extra-loc-engineeringenglish>
      <source>Copying802</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Copying</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>722</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_deleting" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being deleted.</comment>
      <extra-loc-engineeringenglish>Deleting</extra-loc-engineeringenglish>
      <source>Deleting803</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Deleting</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>77</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_disconnecting" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when a connection is being terminated.</comment>
      <extra-loc-engineeringenglish>Disconnecting</extra-loc-engineeringenglish>
      <source>Disconnecting804</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Disconnecting</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_initialising" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when at the beginning of synchronisation when the phone is giving the server the starting values.</comment>
      <extra-loc-engineeringenglish>Initialising</extra-loc-engineeringenglish>
      <source>Initialising805</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Initialising</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_inserting" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when an item (e.g. an image into message or a contact into a group) is being inserted.</comment>
      <extra-loc-engineeringenglish>Inserting</extra-loc-engineeringenglish>
      <source>Inserting806</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Inserting</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>143</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_installing" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being installed.</comment>
      <extra-loc-engineeringenglish>Installing</extra-loc-engineeringenglish>
      <source>Installing807</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Installing</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_loading" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being loaded.</comment>
      <extra-loc-engineeringenglish>Loading</extra-loc-engineeringenglish>
      <source>Loading808</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Loading</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_moving" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being moved.</comment>
      <extra-loc-engineeringenglish>Moving</extra-loc-engineeringenglish>
      <source>Moving809</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Moving</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>184</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_opening" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being opened.</comment>
      <extra-loc-engineeringenglish>Opening</extra-loc-engineeringenglish>
      <source>Opening810</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Opening</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>210</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_processing" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being processed.</comment>
      <extra-loc-engineeringenglish>Processing</extra-loc-engineeringenglish>
      <source>Processing811</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Processing</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_registering" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being registered.</comment>
      <extra-loc-engineeringenglish>Registering</extra-loc-engineeringenglish>
      <source>Registering812</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Registering</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_removing" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being removed.</comment>
      <extra-loc-engineeringenglish>Removing</extra-loc-engineeringenglish>
      <source>Removing813</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">&lt;TR-PLACEHOLDER&gt;</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>266</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_requesting" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being requested.</comment>
      <extra-loc-engineeringenglish>Requesting</extra-loc-engineeringenglish>
      <source>Requesting814</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Requesting</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_retrieving" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being retrieved.</comment>
      <extra-loc-engineeringenglish>Retrieving</extra-loc-engineeringenglish>
      <source>Retrieving815</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Retrieving</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>270</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_saving" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being saved.</comment>
      <extra-loc-engineeringenglish>Saving</extra-loc-engineeringenglish>
      <source>Saving816</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Saving</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>273</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_searching" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed during a search operation.</comment>
      <extra-loc-engineeringenglish>Searching</extra-loc-engineeringenglish>
      <source>Searching817</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Searching</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>276</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_info_unistalling" marked="false">
      <extracomment />
      <location />
      <comment>Wait note. Displayed when something is being uninstalled.</comment>
      <extra-loc-engineeringenglish>Uninstalling</extra-loc-engineeringenglish>
      <source>Uninstalling818</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Uninstalling</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri3_large_graphic</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri3_large_graphic</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>info</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_about_application" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. About application. Opens a view where information about the application is given.</comment>
      <extra-loc-engineeringenglish>About application</extra-loc-engineeringenglish>
      <source>About application819</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">About application</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>3,NOT_18,NOT_408</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_activate" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Activates the focused call diverting item or call barring. </comment>
      <extra-loc-engineeringenglish>Activate</extra-loc-engineeringenglish>
      <source>Activate820</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Activate</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>542</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_activate_handsfree" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Switches the call from loudspeaker or handsfree to handset.</comment>
      <extra-loc-engineeringenglish>Activate handset</extra-loc-engineeringenglish>
      <source>Activate handset821</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Activate handset</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>542,NOT_121,490</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_activate_loudspeaker" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Switches the call from handset or handsfree to loudspeaker.</comment>
      <extra-loc-engineeringenglish>Activate loudspeaker</extra-loc-engineeringenglish>
      <source>Activate loudspeaker822</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Activate loudspeaker</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>542,161</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_add_bookmark" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to add a bookmark.</comment>
      <extra-loc-engineeringenglish>Add bookmark</extra-loc-engineeringenglish>
      <source>Save as bookmark823</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Save as bookmark</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>39,273</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_add_detail" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to add a new item (i.e. a piece of information) for e.g. a meeting request or contact.</comment>
      <extra-loc-engineeringenglish>Add detail</extra-loc-engineeringenglish>
      <source>Add detail824</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Add detail</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_add_from_contacts" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Opens Contacts application where the user can select contact information.</comment>
      <extra-loc-engineeringenglish>Add from Contacts</extra-loc-engineeringenglish>
      <source>Add from Contacts825</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Add from Contacts</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_70,71</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_add_image" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allow user to add image from e.g. Photos.</comment>
      <extra-loc-engineeringenglish>Add image</extra-loc-engineeringenglish>
      <source>Add image826</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Add image</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>133</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_add_member" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to add a member to a group.</comment>
      <extra-loc-engineeringenglish>Add member</extra-loc-engineeringenglish>
      <source>Add member827</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Add member</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_add_recipient" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to add a recipient to the current message.</comment>
      <extra-loc-engineeringenglish>Add recipient</extra-loc-engineeringenglish>
      <source>Add recipient828</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Add recipient</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_add_thumbnail" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows to add or change a thumbnail image for e.g. a member, group or memory.</comment>
      <extra-loc-engineeringenglish>Add thumbnail</extra-loc-engineeringenglish>
      <source>Add thumbnail image829</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Add thumbnail image</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_133,336</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_add_to_contacts" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Opens Contacts application where the user can select contact information.</comment>
      <extra-loc-engineeringenglish>Add to Contacts</extra-loc-engineeringenglish>
      <source>Add to Contacts830</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Add to Contacts</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_70,71</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_add_to_folder" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to add an item into a folder.</comment>
      <extra-loc-engineeringenglish>Add to folder</extra-loc-engineeringenglish>
      <source>Add to folder831</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Add to folder</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_additional_details" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to view additional details of the selected item.</comment>
      <extra-loc-engineeringenglish>Additional details</extra-loc-engineeringenglish>
      <source>Additional details832</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Additional details</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>79</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_advanced_settings" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Opens a view where the user can edit advanced settings.</comment>
      <extra-loc-engineeringenglish>Advanced settings</extra-loc-engineeringenglish>
      <source>Advanced settings833</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Advanced settings</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>290,NOT_291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_attachments" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Opens a view where attachments can be added or opened.</comment>
      <extra-loc-engineeringenglish>Attachments</extra-loc-engineeringenglish>
      <source>Attachments834</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Attachments</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>21</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_automatic_find_off" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Switches off the automatic find function.</comment>
      <extra-loc-engineeringenglish>Automatic find off</extra-loc-engineeringenglish>
      <source>Automatic find off835</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Automatic find off</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>101</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_automatic_find_on" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Switches on the automatic find function.</comment>
      <extra-loc-engineeringenglish>Automatic find on</extra-loc-engineeringenglish>
      <source>Automatic find on836</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Automatic find on</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>101</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_call_noun" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. A noun meaning a connection between the caller and the called party or parties; a phone call.</comment>
      <extra-loc-engineeringenglish>Call</extra-loc-engineeringenglish>
      <source>Call837</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Call</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>43,NOT_402</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_call_verb" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. A verb, meaning "to start a phone call".</comment>
      <extra-loc-engineeringenglish>Call</extra-loc-engineeringenglish>
      <source>Call838</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Call</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_43,402</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_cancel_download" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Cancels the ongoing download.</comment>
      <extra-loc-engineeringenglish>Cancel download</extra-loc-engineeringenglish>
      <source>Cancel download839</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Cancel download</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>54,84,NOT_454</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_change" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to change the highlighted setting.</comment>
      <extra-loc-engineeringenglish>Change</extra-loc-engineeringenglish>
      <source>Change840</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Change</translation>
      <oldsource />
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_chat" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to open a chat with the focused contact.</comment>
      <extra-loc-engineeringenglish>Chat</extra-loc-engineeringenglish>
      <source>Chat841</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Chat</translation>
      <oldsource>Chat</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_144</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_connect" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Connects to e.g. a remote drive or the selected network or establishes a Bluetooth connection.</comment>
      <extra-loc-engineeringenglish>Connect</extra-loc-engineeringenglish>
      <source>Connect842</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Connect</translation>
      <oldsource>Connect</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_continue" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Continues the paused or interrupted action, such as playing a video clip, editing the message or setting, etc.</comment>
      <extra-loc-engineeringenglish>Continue</extra-loc-engineeringenglish>
      <source>Continue843</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Continue</translation>
      <oldsource>Continue</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>72</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_copy" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. The selected text is copied and added to the clipboard.</comment>
      <extra-loc-engineeringenglish>Copy</extra-loc-engineeringenglish>
      <source>Copy844</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Copy</translation>
      <oldsource>Copy</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>722</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_copy_to_folder" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Copies the selected item to a folder.</comment>
      <extra-loc-engineeringenglish>Copy to folder</extra-loc-engineeringenglish>
      <source>Copy to folder845</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Copy to folder</translation>
      <oldsource>Copy to folder</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>722</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_create_message" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to create a new message (SMS, MMS, e-mail, etc.).</comment>
      <extra-loc-engineeringenglish>Create message</extra-loc-engineeringenglish>
      <source>Create message846</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Create message</translation>
      <oldsource>Create message</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_cut" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. The selected text is cut and added to the clipboard.</comment>
      <extra-loc-engineeringenglish>Cut</extra-loc-engineeringenglish>
      <source>Cut847</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Cut</translation>
      <oldsource>Cut</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>721</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_deactivate" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Deactivates the focused item.</comment>
      <extra-loc-engineeringenglish>Deactivate</extra-loc-engineeringenglish>
      <source>Deactivate848</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Deactivate</translation>
      <oldsource>Deactivate</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>403</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_deactivate_loudspeaker" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Deactivates the loudspeaker.</comment>
      <extra-loc-engineeringenglish>Deactivate loudspeaker</extra-loc-engineeringenglish>
      <source>Deactivate loudspeaker849</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Deactivate loudspeaker</translation>
      <oldsource>Deactivate loudspeaker</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>403,161</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_delete" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Erases something completely from the phone, list, or memory card, for example. Delete should only be used when something in removed permanently.</comment>
      <extra-loc-engineeringenglish>Delete</extra-loc-engineeringenglish>
      <source>Delete850</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Delete</translation>
      <oldsource>Delete</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>77</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_details" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Opens a view where information about the item is given.</comment>
      <extra-loc-engineeringenglish>Details</extra-loc-engineeringenglish>
      <source>Details851</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Details</translation>
      <oldsource>Details</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>79</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_disable" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to disable the selected item or function.</comment>
      <extra-loc-engineeringenglish>Disable</extra-loc-engineeringenglish>
      <source>Disable852</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Disable</translation>
      <oldsource>Disable</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_disconnect" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Ends the active connection to e.g a remote drive or the selected network or the Bluetooth connection.</comment>
      <extra-loc-engineeringenglish>Disconnect</extra-loc-engineeringenglish>
      <source>Disconnect853</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Disconnect</translation>
      <oldsource>Disconnect</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_edit" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. The user can open a selected item, such as a name or text, for editing.</comment>
      <extra-loc-engineeringenglish>Edit</extra-loc-engineeringenglish>
      <source>Edit854</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Edit</translation>
      <oldsource>Edit</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>88</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_enable" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to enable the selected item or function.</comment>
      <extra-loc-engineeringenglish>Enable</extra-loc-engineeringenglish>
      <source>Enable855</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Enable</translation>
      <oldsource>Enable</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_exit" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. With the exit option, the user can close the currently active application and return to the Home screen.</comment>
      <extra-loc-engineeringenglish>Exit</extra-loc-engineeringenglish>
      <source>Exit856</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Exit</translation>
      <oldsource>Exit</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>97</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_find" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Opens a find pop-up window after the user has selected this option in the Find application.</comment>
      <extra-loc-engineeringenglish>Find</extra-loc-engineeringenglish>
      <source>Find857</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Find</translation>
      <oldsource>Find</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>101</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_fit_to_screen" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Image is sized to fit to the screen.</comment>
      <extra-loc-engineeringenglish>Fit to screen</extra-loc-engineeringenglish>
      <source>Fit to screen858</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Fit to screen</translation>
      <oldsource>Fit to screen</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_forward" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Forwards e.g. a message (SMS, MMS, e-mail) or meeting request to another recipient.</comment>
      <extra-loc-engineeringenglish>Forward</extra-loc-engineeringenglish>
      <source>Forward859</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Forward</translation>
      <oldsource>Forward</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_go_to_web_address" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Opens the defined web address.</comment>
      <extra-loc-engineeringenglish>Go to web address</extra-loc-engineeringenglish>
      <source>Go to web address860</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Go to web address</translation>
      <oldsource>Go to web address</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>114,384</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_insert" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to insert an object such as an image, sound clip, video, recording, number, or symbol to a message, text, or presentation.</comment>
      <extra-loc-engineeringenglish>Insert</extra-loc-engineeringenglish>
      <source>Insert861</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Insert</translation>
      <oldsource>Insert</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>143</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_install" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to install a file or files.</comment>
      <extra-loc-engineeringenglish>Install</extra-loc-engineeringenglish>
      <source>Install862</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Install</translation>
      <oldsource>Install</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_internet_call" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to make an Internet call.</comment>
      <extra-loc-engineeringenglish>Internet call</extra-loc-engineeringenglish>
      <source>Make internet call863</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Make internet call</translation>
      <oldsource>Make internet call</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_43,NOT_402,145</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_mark" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to mark one or more items in a list.</comment>
      <extra-loc-engineeringenglish>Mark</extra-loc-engineeringenglish>
      <source>Mark864</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Mark</translation>
      <oldsource>Mark</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>167</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_move" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Moves the selected item to another location inside a grid or a list.</comment>
      <extra-loc-engineeringenglish>Move</extra-loc-engineeringenglish>
      <source>Move865</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Move</translation>
      <oldsource>Move</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>184</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_move_to_folder" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Moves an item to a selected folder.</comment>
      <extra-loc-engineeringenglish>Move to folder</extra-loc-engineeringenglish>
      <source>Move to folder866</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Move to folder</translation>
      <oldsource>Move to folder</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>184</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_open" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Opens a highlighted item such as an application, folder, or message</comment>
      <extra-loc-engineeringenglish>Open</extra-loc-engineeringenglish>
      <source>Open867</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Open</translation>
      <oldsource>Open</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>210</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_organise" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to move items and folders.</comment>
      <extra-loc-engineeringenglish>Organise</extra-loc-engineeringenglish>
      <source>Organise868</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Organise</translation>
      <oldsource>Organise</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>624</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_paste" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to paste the copied or cut data in the clipboard to the selected place.</comment>
      <extra-loc-engineeringenglish>Paste</extra-loc-engineeringenglish>
      <source>Paste869</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Paste</translation>
      <oldsource>Paste</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>723</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_pause" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Pauses the ongoing action, such as playing an audio or video clip or presentation.</comment>
      <extra-loc-engineeringenglish>Pause</extra-loc-engineeringenglish>
      <source>Pause870</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Pause</translation>
      <oldsource>Pause</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_play_music" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. For playing music tracks and other audio.</comment>
      <extra-loc-engineeringenglish>Play</extra-loc-engineeringenglish>
      <source>Play871</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Play</translation>
      <oldsource>Play</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_play_video" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. For playing video.</comment>
      <extra-loc-engineeringenglish>Play</extra-loc-engineeringenglish>
      <source>Play872</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Play</translation>
      <oldsource>Play</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_preview_audio" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to preview the focused music track or other audio item.</comment>
      <extra-loc-engineeringenglish>Preview</extra-loc-engineeringenglish>
      <source>Preview873</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Preview</translation>
      <oldsource>Preview</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_preview_video" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to preview the focused video item.</comment>
      <extra-loc-engineeringenglish>Preview</extra-loc-engineeringenglish>
      <source>Preview874</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Preview</translation>
      <oldsource>Preview</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_print" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Starts printing of an item (e.g. image).</comment>
      <extra-loc-engineeringenglish>Print</extra-loc-engineeringenglish>
      <source>Print875</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Print</translation>
      <oldsource>Print</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_remove" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Takes something away from a certain list or group, but does not completely erase it from the phone.</comment>
      <extra-loc-engineeringenglish>Remove</extra-loc-engineeringenglish>
      <source>Remove876</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Remove</translation>
      <oldsource>Remove</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>266</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_rename_item" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows user to rename the selected item (file, folder, music track, image etc.).</comment>
      <extra-loc-engineeringenglish>Rename</extra-loc-engineeringenglish>
      <source>Rename877</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Rename</translation>
      <oldsource>Rename</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_rename_people" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows user to define a new name for one or more persons.</comment>
      <extra-loc-engineeringenglish>Rename</extra-loc-engineeringenglish>
      <source>Rename878</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Rename</translation>
      <oldsource>Rename</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_replace" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to replace text.</comment>
      <extra-loc-engineeringenglish>Replace</extra-loc-engineeringenglish>
      <source>Replace879</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Replace</translation>
      <oldsource>Replace</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_save" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Lets the user store the changes made or new items or entries added.</comment>
      <extra-loc-engineeringenglish>Save</extra-loc-engineeringenglish>
      <source>Save880</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Save</translation>
      <oldsource>Save</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>273</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_save_to_contacts" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Saves the selected item to Contacts.</comment>
      <extra-loc-engineeringenglish>Save to Contacts</extra-loc-engineeringenglish>
      <source>Save to Contacts881</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Save to Contacts</translation>
      <oldsource>Save to Contacts</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_70,71,273</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_select" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Lets the user choose the focused item from a list.</comment>
      <extra-loc-engineeringenglish>Select</extra-loc-engineeringenglish>
      <source>Select882</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Select</translation>
      <oldsource>Select</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>280</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_send_item" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Sends the selected item.</comment>
      <extra-loc-engineeringenglish>Send</extra-loc-engineeringenglish>
      <source>Send883</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Send</translation>
      <oldsource>Send</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>281</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_send_message" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to send a message (SMS, MMS, e-mail etc.).</comment>
      <extra-loc-engineeringenglish>Send message</extra-loc-engineeringenglish>
      <source>Send message884</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Send message</translation>
      <oldsource>Send message</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>281</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_settings" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Opens a view where the user can change the settings of applications, features, and services.</comment>
      <extra-loc-engineeringenglish>Settings</extra-loc-engineeringenglish>
      <source>Settings885</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Settings</translation>
      <oldsource>Settings</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_290,291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_undo" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Undoes the previous operation or edit.</comment>
      <extra-loc-engineeringenglish>Undo</extra-loc-engineeringenglish>
      <source>Undo886</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Undo</translation>
      <oldsource>Undo</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_uninstall" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to uninstall files or programs.</comment>
      <extra-loc-engineeringenglish>Uninstall</extra-loc-engineeringenglish>
      <source>Uninstall887</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Uninstall</translation>
      <oldsource>Uninstall</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_unmark" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to select one or more items in a list to be unmarked. </comment>
      <extra-loc-engineeringenglish>Unmark</extra-loc-engineeringenglish>
      <source>Unmark888</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Unmark</translation>
      <oldsource>Unmark</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>348</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_unmute" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to unmute a muted phone's microphones.</comment>
      <extra-loc-engineeringenglish>Unmute</extra-loc-engineeringenglish>
      <source>Unmute889</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Unmute</translation>
      <oldsource>Unmute</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_video_call" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to make a video call.</comment>
      <extra-loc-engineeringenglish>Video call</extra-loc-engineeringenglish>
      <source>Make video call890</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Make video call</translation>
      <oldsource>Make video call</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_43,NOT_402,359</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_voice_call" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Allows the user to make a voice call.</comment>
      <extra-loc-engineeringenglish>Voice call</extra-loc-engineeringenglish>
      <source>Make voice call891</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Make voice call</translation>
      <oldsource>Make voice call</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_43,NOT_402</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_zoom_in" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Increases the size of an image on the display.</comment>
      <extra-loc-engineeringenglish>Zoom in</extra-loc-engineeringenglish>
      <source>Zoom in892</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Zoom in</translation>
      <oldsource>Zoom in</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>396</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_menu_zoom_out" marked="false">
      <extracomment />
      <location />
      <comment>Item specific menu item. Note! Only use this text ID if there are no icons. Decreases the size of an image on the display. </comment>
      <extra-loc-engineeringenglish>Zoom out</extra-loc-engineeringenglish>
      <source>Zoom out893</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Zoom out</translation>
      <oldsource>Zoom out</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_sec</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_sec</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>456</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>menu</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_about_application" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. About application. Opens a view where information about the application is given.</comment>
      <extra-loc-engineeringenglish>About application</extra-loc-engineeringenglish>
      <source>About application894</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">About application</translation>
      <oldsource>About application</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>3</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_activate" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Activates the focused call diverting item or call barring. </comment>
      <extra-loc-engineeringenglish>Activate</extra-loc-engineeringenglish>
      <source>Activate895</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Activate</translation>
      <oldsource>Activate</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>542</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_activate_handsfree" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Switches the call from loudspeaker or handsfree to handset.</comment>
      <extra-loc-engineeringenglish>Activate handset</extra-loc-engineeringenglish>
      <source>Activate handset896</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Activate handset</translation>
      <oldsource>Activate handset</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>542,NOT_121,490</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_activate_loudspeaker" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Switches the call from handset or handsfree to loudspeaker.</comment>
      <extra-loc-engineeringenglish>Activate loudspeaker</extra-loc-engineeringenglish>
      <source>Activate loudspeaker897</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Activate loudspeaker</translation>
      <oldsource>Activate loudspeaker</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>542,161</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_add_bookmark" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to add a bookmark.</comment>
      <extra-loc-engineeringenglish>Add bookmark</extra-loc-engineeringenglish>
      <source>Save as bookmark898</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Save as bookmark</translation>
      <oldsource>Add bookmark</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>39</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_add_detail" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to add a new item (i.e. a piece of information) for e.g. a meeting request or contact.</comment>
      <extra-loc-engineeringenglish>Add detail</extra-loc-engineeringenglish>
      <source>Add detail899</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Add detail</translation>
      <oldsource>Add detail</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_add_from_contacts" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Opens Contacts application where the user can select contact information.</comment>
      <extra-loc-engineeringenglish>Add from Contacts</extra-loc-engineeringenglish>
      <source>Add from Contacts900</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Add from Contacts</translation>
      <oldsource>Add from Contacts</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_70,71</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_add_image" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allow user to add image from e.g. Photos.</comment>
      <extra-loc-engineeringenglish>Add image</extra-loc-engineeringenglish>
      <source>Add image901</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Add image</translation>
      <oldsource>Add image</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>133</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_add_member" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to add a member to a group.</comment>
      <extra-loc-engineeringenglish>Add member</extra-loc-engineeringenglish>
      <source>Add member902</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Add member</translation>
      <oldsource>Add member</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_add_recipient" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to add a recipient to the current message.</comment>
      <extra-loc-engineeringenglish>Add recipient</extra-loc-engineeringenglish>
      <source>Add recipient903</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Add recipient</translation>
      <oldsource>Add recipient</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_add_thumbnail" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows to add or change a thumbnail image for e.g. a member, group or memory.</comment>
      <extra-loc-engineeringenglish>Add thumbnail</extra-loc-engineeringenglish>
      <source>Add thumbnail904</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Add thumbnail</translation>
      <oldsource>Add thumbnail</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>336</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_add_to_contacts" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Opens Contacts application where the user can select contact information.</comment>
      <extra-loc-engineeringenglish>Add to Contacts</extra-loc-engineeringenglish>
      <source>Save to Contacts905</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Save to Contacts</translation>
      <oldsource>Save to Contacts</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_70,71,273</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_add_to_folder" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to add an item into a folder.</comment>
      <extra-loc-engineeringenglish>Add to folder</extra-loc-engineeringenglish>
      <source>Add to folder906</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Add to folder</translation>
      <oldsource>Add to folder</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_additional_details" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to view additional details of the selected item.</comment>
      <extra-loc-engineeringenglish>Additional details</extra-loc-engineeringenglish>
      <source>More info907</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">More info</translation>
      <oldsource>More info</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_advanced_settings" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Opens a view where the user can edit advanced settings.</comment>
      <extra-loc-engineeringenglish>Advanced settings</extra-loc-engineeringenglish>
      <source>Advanced settings908</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Advanced settings</translation>
      <oldsource>Advanced settings</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>290,NOT_291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_attachments" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Opens a view where attachments can be added or opened.</comment>
      <extra-loc-engineeringenglish>Attachments</extra-loc-engineeringenglish>
      <source>Attachments909</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Attachments</translation>
      <oldsource>Attachments</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>21</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_automatic_find_off" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Switches off the automatic find function.</comment>
      <extra-loc-engineeringenglish>Automatic find off</extra-loc-engineeringenglish>
      <source>Automatic find off910</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Automatic find off</translation>
      <oldsource>Automatic find off</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_101</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_automatic_find_on" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Switches on the automatic find function.</comment>
      <extra-loc-engineeringenglish>Automatic find on</extra-loc-engineeringenglish>
      <source>Automatic find on911</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Automatic find on</translation>
      <oldsource>Automatic find on</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_101</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_back" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Returns the user to the previous view.</comment>
      <extra-loc-engineeringenglish>Back</extra-loc-engineeringenglish>
      <source>Back912</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Back</translation>
      <oldsource>Back</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>30</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_call_noun" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. A noun meaning a connection between the caller and the called party or parties; a phone call.</comment>
      <extra-loc-engineeringenglish>Call</extra-loc-engineeringenglish>
      <source>Call913</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Call</translation>
      <oldsource>Call</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>43,NOT_402</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_call_verb" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. A verb, meaning "to start a phone call".</comment>
      <extra-loc-engineeringenglish>Call</extra-loc-engineeringenglish>
      <source>Call914</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Call</translation>
      <oldsource>Call</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_43,402</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_cancel_download" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Cancels the ongoing download.</comment>
      <extra-loc-engineeringenglish>Cancel download</extra-loc-engineeringenglish>
      <source>Cancel download915</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">&lt;TR-PLACEHOLDER&gt;</translation>
      <oldsource>Cancel download</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>54,84,NOT_454</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_change" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to change the highlighted setting.</comment>
      <extra-loc-engineeringenglish>Change</extra-loc-engineeringenglish>
      <source>Change916</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Change</translation>
      <oldsource>Change</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_chat" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to open a chat with the focused contact.</comment>
      <extra-loc-engineeringenglish>Chat</extra-loc-engineeringenglish>
      <source>Chat917</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Chat</translation>
      <oldsource>Chat</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_144</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_connect" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Connects to e.g. a remote drive or the selected network or establishes a Bluetooth connection.</comment>
      <extra-loc-engineeringenglish>Connect</extra-loc-engineeringenglish>
      <source>Connect918</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Connect</translation>
      <oldsource>Connect</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_continue" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Continues the paused or interrupted action, such as playing a video clip, editing the message or setting, etc.</comment>
      <extra-loc-engineeringenglish>Continue</extra-loc-engineeringenglish>
      <source>Continue919</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Continue</translation>
      <oldsource>Continue</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>72</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_copy" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. The selected text is copied and added to the clipboard.</comment>
      <extra-loc-engineeringenglish>Copy</extra-loc-engineeringenglish>
      <source>Copy920</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Copy</translation>
      <oldsource>Copy</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>722</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_copy_to_folder" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Copies the selected item to a folder.</comment>
      <extra-loc-engineeringenglish>Copy to folder</extra-loc-engineeringenglish>
      <source>Copy to folder921</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Copy to folder</translation>
      <oldsource>Copy to folder</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>722</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_create_message" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to create a new message (SMS, MMS, e-mail, etc.).</comment>
      <extra-loc-engineeringenglish>Create message</extra-loc-engineeringenglish>
      <source>Create message922</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Create message</translation>
      <oldsource>Create message</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_cut" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. The selected text is cut and added to the clipboard.</comment>
      <extra-loc-engineeringenglish>Cut</extra-loc-engineeringenglish>
      <source>Cut923</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Cut</translation>
      <oldsource>Cut</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>721</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_deactivate" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Deactivates the focused item.</comment>
      <extra-loc-engineeringenglish>Deactivate</extra-loc-engineeringenglish>
      <source>Deactivate924</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Deactivate</translation>
      <oldsource>Deactivate</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>403</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_deactivate_loudspeaker" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Deactivates the loudspeaker.</comment>
      <extra-loc-engineeringenglish>Deactivate loudspeaker</extra-loc-engineeringenglish>
      <source>Deactivate loudspeaker925</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Deactivate loudspeaker</translation>
      <oldsource>Deactivate loudspeaker</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>403,161</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_delete" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Erases something completely from the phone, list, or memory card, for example. Delete should only be used when something in removed permanently.</comment>
      <extra-loc-engineeringenglish>Delete</extra-loc-engineeringenglish>
      <source>Delete926</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Delete</translation>
      <oldsource>Delete</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>77</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_details" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Opens a view where information about the item is given.</comment>
      <extra-loc-engineeringenglish>Details</extra-loc-engineeringenglish>
      <source>Details927</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Details</translation>
      <oldsource>Details</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>79</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_disable" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to disable the selected item or function.</comment>
      <extra-loc-engineeringenglish>Disable</extra-loc-engineeringenglish>
      <source>Disable928</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Disable</translation>
      <oldsource>Disable</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_disconnect" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Ends the active connection to e.g a remote drive or the selected network or the Bluetooth connection.</comment>
      <extra-loc-engineeringenglish>Disconnect</extra-loc-engineeringenglish>
      <source>Disconnect929</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Disconnect</translation>
      <oldsource>Disconnect</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_edit" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. The user can open a selected item, such as a name or text, for editing.</comment>
      <extra-loc-engineeringenglish>Edit</extra-loc-engineeringenglish>
      <source>Edit930</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Edit</translation>
      <oldsource>Edit</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>88</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_enable" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to enable the selected item or function.</comment>
      <extra-loc-engineeringenglish>Enable</extra-loc-engineeringenglish>
      <source>Enable931</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Enable</translation>
      <oldsource>Enable</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_exit" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. With the exit option, the user can close the currently active application and return to the Home screen.</comment>
      <extra-loc-engineeringenglish>Exit</extra-loc-engineeringenglish>
      <source>Exit932</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Exit</translation>
      <oldsource>Exit</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>97</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_find" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Opens a find pop-up window after the user has selected this option in the Find application.</comment>
      <extra-loc-engineeringenglish>Find</extra-loc-engineeringenglish>
      <source>Find933</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Find</translation>
      <oldsource>Find</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>101</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_fit_to_screen" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Image is sized to fit to the screen.</comment>
      <extra-loc-engineeringenglish>Fit to screen</extra-loc-engineeringenglish>
      <source>Fit to screen934</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Fit to screen</translation>
      <oldsource>Fit to screen</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_forward" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Forwards e.g. a message (SMS, MMS, e-mail) or meeting request to another recipient.</comment>
      <extra-loc-engineeringenglish>Forward</extra-loc-engineeringenglish>
      <source>Forward935</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Forward</translation>
      <oldsource>Forward</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_go_to_web_address" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Opens the defined web address.</comment>
      <extra-loc-engineeringenglish>Go to web address</extra-loc-engineeringenglish>
      <source>Go to web address936</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">&lt;TR-PLACEHOLDER&gt;</translation>
      <oldsource>Go to web address</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>114,384</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_help" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Opens a help dialog.</comment>
      <extra-loc-engineeringenglish>Help</extra-loc-engineeringenglish>
      <source>User guide937</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">User guide</translation>
      <oldsource>User guide</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>758</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_insert" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to insert an object such as an image, sound clip, video, recording, number, or symbol to a message, text, or presentation.</comment>
      <extra-loc-engineeringenglish>Insert</extra-loc-engineeringenglish>
      <source>Insert938</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Insert</translation>
      <oldsource>Insert</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>143</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_install" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to install a file or files.</comment>
      <extra-loc-engineeringenglish>Install</extra-loc-engineeringenglish>
      <source>Install939</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Install</translation>
      <oldsource>Install</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_internet_call" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to make an Internet call.</comment>
      <extra-loc-engineeringenglish>Internet call</extra-loc-engineeringenglish>
      <source>Make internet call940</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Make internet call</translation>
      <oldsource>Make internet call</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_43,NOT_402,145</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_mark" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to mark one or more items in a list.</comment>
      <extra-loc-engineeringenglish>Mark</extra-loc-engineeringenglish>
      <source>Mark941</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Mark</translation>
      <oldsource>Mark</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>167</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_move" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Moves the selected item to another location inside a grid or a list.</comment>
      <extra-loc-engineeringenglish>Move</extra-loc-engineeringenglish>
      <source>Move942</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Move</translation>
      <oldsource>Move</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>184</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_move_to_folder" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Moves an item to a selected folder.</comment>
      <extra-loc-engineeringenglish>Move to folder</extra-loc-engineeringenglish>
      <source>Move to folder943</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Move to folder</translation>
      <oldsource>Move to folder</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>184</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_open" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Opens a highlighted item such as an application, folder, or message</comment>
      <extra-loc-engineeringenglish>Open</extra-loc-engineeringenglish>
      <source>Open944</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Open</translation>
      <oldsource>Open</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>210</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_organise" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to move items and folders.</comment>
      <extra-loc-engineeringenglish>Organise</extra-loc-engineeringenglish>
      <source>Organise945</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Organise</translation>
      <oldsource>Organise</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>624</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_paste" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to paste the copied or cut data in the clipboard to the selected place.</comment>
      <extra-loc-engineeringenglish>Paste</extra-loc-engineeringenglish>
      <source>Paste946</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Paste</translation>
      <oldsource>Paste</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>723</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_pause" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Pauses the ongoing action, such as playing an audio or video clip or presentation.</comment>
      <extra-loc-engineeringenglish>Pause</extra-loc-engineeringenglish>
      <source>Pause947</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Pause</translation>
      <oldsource>Pause</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_play_music" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. For playing music tracks and other audio.</comment>
      <extra-loc-engineeringenglish>Play</extra-loc-engineeringenglish>
      <source>Play948</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Play</translation>
      <oldsource>Play</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_play_video" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. For playing video.</comment>
      <extra-loc-engineeringenglish>Play</extra-loc-engineeringenglish>
      <source>Play949</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Play</translation>
      <oldsource>Play</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_preview_audio" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to preview the focused music track or other audio item.</comment>
      <extra-loc-engineeringenglish>Preview</extra-loc-engineeringenglish>
      <source>Preview950</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Preview</translation>
      <oldsource>Preview</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_preview_video" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to preview the focused video item.</comment>
      <extra-loc-engineeringenglish>Preview</extra-loc-engineeringenglish>
      <source>Preview951</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Preview</translation>
      <oldsource>Preview</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_print" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Starts printing of an item (e.g. image).</comment>
      <extra-loc-engineeringenglish>Print</extra-loc-engineeringenglish>
      <source>Print952</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Print</translation>
      <oldsource>Print</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_remove" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Takes something away from a certain list or group, but does not completely erase it from the phone.</comment>
      <extra-loc-engineeringenglish>Remove</extra-loc-engineeringenglish>
      <source>Remove953</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Remove</translation>
      <oldsource>Remove</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>266</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_rename_item" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows user to rename the selected item (file, folder, music track, image etc.).</comment>
      <extra-loc-engineeringenglish>Rename</extra-loc-engineeringenglish>
      <source>Rename954</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Rename</translation>
      <oldsource>Rename</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_rename_people" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows user to define a new name for one or more persons.</comment>
      <extra-loc-engineeringenglish>Rename</extra-loc-engineeringenglish>
      <source>Rename955</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Rename</translation>
      <oldsource>Rename</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_replace" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to replace text.</comment>
      <extra-loc-engineeringenglish>Replace</extra-loc-engineeringenglish>
      <source>Replace956</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Replace</translation>
      <oldsource>Replace</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_save" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Lets the user store the changes made or new items or entries added.</comment>
      <extra-loc-engineeringenglish>Save</extra-loc-engineeringenglish>
      <source>Save957</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Save</translation>
      <oldsource>Save</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>273</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_save_to_contacts" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Saves the selected item to Contacts.</comment>
      <extra-loc-engineeringenglish>Save to Contacts</extra-loc-engineeringenglish>
      <source>Save to Contacts958</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Save to Contacts</translation>
      <oldsource>Save to Contacts</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_70,71,273</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_select" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Lets the user choose the focused item from a list.</comment>
      <extra-loc-engineeringenglish>Select</extra-loc-engineeringenglish>
      <source>Select959</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Select</translation>
      <oldsource>Select</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>280</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_send_item" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Sends the selected item.</comment>
      <extra-loc-engineeringenglish>Send</extra-loc-engineeringenglish>
      <source>Send960</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Send</translation>
      <oldsource>Send</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>281</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_send_message" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to send a message (SMS, MMS, e-mail etc.).</comment>
      <extra-loc-engineeringenglish>Send message</extra-loc-engineeringenglish>
      <source>Send message961</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Send message</translation>
      <oldsource>Send message</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>281</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_settings" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Opens a view where the user can change the settings of applications, features, and services.</comment>
      <extra-loc-engineeringenglish>Settings</extra-loc-engineeringenglish>
      <source>Settings962</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Settings</translation>
      <oldsource>Settings</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_290,291</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_undo" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Undoes the previous operation or edit.</comment>
      <extra-loc-engineeringenglish>Undo</extra-loc-engineeringenglish>
      <source>Undo963</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Undo</translation>
      <oldsource>Undo</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_uninstall" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to uninstall files or programs.</comment>
      <extra-loc-engineeringenglish>Uninstall</extra-loc-engineeringenglish>
      <source>Uninstall964</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Uninstall</translation>
      <oldsource>Uninstall</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_unmark" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to select one or more items in a list to be unmarked. </comment>
      <extra-loc-engineeringenglish>Unmark</extra-loc-engineeringenglish>
      <source>Unmark965</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Unmark</translation>
      <oldsource>Unmark</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>348</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_unmute" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to unmute a muted phone's microphones.</comment>
      <extra-loc-engineeringenglish>Unmute</extra-loc-engineeringenglish>
      <source>Unmute966</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Unmute</translation>
      <oldsource>Unmute</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms />
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_video_call" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to make a video call.</comment>
      <extra-loc-engineeringenglish>Video call</extra-loc-engineeringenglish>
      <source>Make video call967</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Make video call</translation>
      <oldsource>Make video call</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_43,NOT_402,359</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_voice_call" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Allows the user to make a voice call.</comment>
      <extra-loc-engineeringenglish>Voice call</extra-loc-engineeringenglish>
      <source>Make voice call968</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Make voice call</translation>
      <oldsource>Make voice call</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_43,NOT_402,370</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_zoom_in" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Increases the size of an image on the display.</comment>
      <extra-loc-engineeringenglish>Zoom in</extra-loc-engineeringenglish>
      <source>Zoom in969</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Zoom in</translation>
      <oldsource>Zoom in</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>396</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_opt_zoom_out" marked="false">
      <extracomment />
      <location />
      <comment>Options list item. Note! Only use this text ID if there are no icons. Decreases the size of an image on the display. </comment>
      <extra-loc-engineeringenglish>Zoom out</extra-loc-engineeringenglish>
      <source>Zoom out970</source>
      <translation variants="no" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Zoom out</translation>
      <oldsource>Zoom out</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_menu_pri</extra-loc-layout_id>
      <extra-loc-layout>qtl_menu_pri</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>456</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>opt</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_title_details" marked="false">
      <extracomment />
      <location />
      <comment>Heading. Note! Only use this text ID if there are no icons. For a details popup note.</comment>
      <extra-loc-engineeringenglish>Details:</extra-loc-engineeringenglish>
      <source>Details:971</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Details:</lengthvariant>
      </translation>
      <oldsource>Details:</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>79</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_title_select_address" marked="false">
      <extracomment />
      <location />
      <comment>Heading. Note! Only use this text ID if there are no icons. Allows user to select a (web, work, home etc.) address from the list below this heading.</comment>
      <extra-loc-engineeringenglish>Select address:</extra-loc-engineeringenglish>
      <source>Select address:972</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Select address:</lengthvariant>
      </translation>
      <oldsource>Select address:</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>280,NOT_384</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_title_select_file" marked="false">
      <extracomment />
      <location />
      <comment>Heading. Note! Only use this text ID if there are no icons. Allows user to select a file from the list below this heading.</comment>
      <extra-loc-engineeringenglish>Select file:</extra-loc-engineeringenglish>
      <source>Select file:973</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Select file:</lengthvariant>
      </translation>
      <oldsource>Select file:</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>280</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_title_select_folder" marked="false">
      <extracomment />
      <location />
      <comment>Heading. Note! Only use this text ID if there are no icons. Allows user to select a folder from the list below this heading.</comment>
      <extra-loc-engineeringenglish>Select folder:</extra-loc-engineeringenglish>
      <source>Select folder:974</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Select folder:</lengthvariant>
      </translation>
      <oldsource>Select folder:</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>280</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_title_select_language" marked="false">
      <extracomment />
      <location />
      <comment>Heading. Note! Only use this text ID if there are no icons. Allows user to select a language from the list below this heading.</comment>
      <extra-loc-engineeringenglish>Select language:</extra-loc-engineeringenglish>
      <source>Select language:975</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Select language:</lengthvariant>
      </translation>
      <oldsource>Select language:</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>280</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_title_select_memory" marked="false">
      <extracomment />
      <location />
      <comment>Heading. Note! Only use this text ID if there are no icons. Allows user to select a memory to be used for a particular operation (phone memory, memory card etc.)</comment>
      <extra-loc-engineeringenglish>Select memory:</extra-loc-engineeringenglish>
      <source>Select memory:976</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Select memory:</lengthvariant>
      </translation>
      <oldsource>Select memory:</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_173,280</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_title_select_tone1" marked="false">
      <extracomment />
      <location />
      <comment>Heading. Note! Only use this text ID if there are no icons. Allows user to select a clock alarm tone from the list below this heading.</comment>
      <extra-loc-engineeringenglish>Select tone:</extra-loc-engineeringenglish>
      <source>Select tone:977</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">&lt;TR-PLACEHOLDER&gt;</lengthvariant>
      </translation>
      <oldsource>Select tone:</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_422,280</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_title_select_tone2" marked="false">
      <extracomment />
      <location />
      <comment>Heading. Note! Only use this text ID if there are no icons. Allows user to select a calendar alarm tone from the list below this heading.</comment>
      <extra-loc-engineeringenglish>Select tone:</extra-loc-engineeringenglish>
      <source>Select tone:978</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Select tone:</lengthvariant>
      </translation>
      <oldsource>Select tone:</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>NOT_422,280</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_title_select_tone3" marked="false">
      <extracomment />
      <location />
      <comment>Heading. Note! Only use this text ID if there are no icons. Allows user to select a ringing tone from the list below this heading.</comment>
      <extra-loc-engineeringenglish>Select tone:</extra-loc-engineeringenglish>
      <source>Select tone:979</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Select tone:</lengthvariant>
      </translation>
      <oldsource>Select tone:</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>422,280</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_title_web_address" marked="false">
      <extracomment />
      <location />
      <comment>Heading. Note! Only use this text ID if there are no icons. Allows user to select a web address from the list below this heading.</comment>
      <extra-loc-engineeringenglish>Web address:</extra-loc-engineeringenglish>
      <source>Select web address:980</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Select web address:</lengthvariant>
      </translation>
      <oldsource>Select web address:</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>280,384</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
    <message numerus="no" id="txt_common_title_writing_language" marked="false">
      <extracomment />
      <location />
      <comment>Heading. Note! Only use this text ID if there are no icons. Allows user to select writing language from the list below this heading.</comment>
      <extra-loc-engineeringenglish>Writing language:</extra-loc-engineeringenglish>
      <source>Writing language:981</source>
      <translation variants="yes" testresult="false" keep="false">
        <lengthvariant priority="1" errorid="" changeid="" translatorcomment="" testercomment="" testresult="false" checkmessage="" checkresult="" match="" vendorinternalinformation="" keep="false" originaltranslatorcomment="" originaltestercomment="" originaltranslation="">Writing language:</lengthvariant>
      </translation>
      <oldsource>Writing language:</oldsource>
      <translatorcomment />
      <oldcomment />
      <extra-loc-errorid />
      <extra-loc-changeid />
      <extra-loc-testercomment />
      <extra-loc-layout_id>qtl_dialog_pri_heading</extra-loc-layout_id>
      <extra-loc-layout>qtl_dialog_pri_heading</extra-loc-layout>
      <extra-loc-layoutmetrics />
      <extra-loc-trid />
      <extra-loc-sendoutdate />
      <extra-loc-terms>394</extra-loc-terms>
      <extra-loc-blank>false</extra-loc-blank>
      <extra-loc-positionid>title</extra-loc-positionid>
      <extra-loc-viewid>common</extra-loc-viewid>
      <extra-loc-framework>SDQt</extra-loc-framework>
    </message>
  </context>
</TS>